# This command checks the registry for the WebView2 Runtime installation details.
# It works for all installation types (Evergreen Bootstrapper, Evergreen Standalone, Fixed Version).

$registryPath = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"

if (Test-Path $registryPath) {
    # If the path exists, get the version information from the 'pv' value.
    $version = (Get-ItemProperty -Path $registryPath).pv
    if ($version) {
        Write-Host "WebView2 Runtime is installed. Version: $version" -ForegroundColor Green
        # You can return $true or the version string here in a function.
    } else {
        Write-Host "WebView2 registry key found, but version information is missing. Installation may be corrupt." -ForegroundColor Yellow
    }
} else {
    Write-Host "WebView2 Runtime is NOT installed." -ForegroundColor Red
    # You can return $false here in a function.
}