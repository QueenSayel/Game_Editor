# This script encodes a target file located in the same directory as the script.
# The target file is encoded into Base64 string and copied to clipboard.

# --- INSTRUCTIONS ---
# 1. Place this .ps1 script in a folder.
# 2. Place the 'WebView2Loader.dll' file in the SAME folder.
# 3. Run this script.

# The name of the DLL file we are looking for.
$dllFileName = "citi.ico"

# Check if the script is being run from a file. $PSScriptRoot is only set when
# a script file is executed, not when code is run interactively in the console.
if (-not $PSScriptRoot) {
    Write-Error "This script must be saved as a .ps1 file and run from that file, not interactively in the console."
    Write-Error "It needs to know its own location to find the DLL."
    return # Stop execution
}

# Construct the full path to the DLL by combining the script's directory with the DLL's filename.
$dllPath = Join-Path -Path $PSScriptRoot -ChildPath $dllFileName

# Check if the DLL file actually exists at the expected location.
if (Test-Path $dllPath) {
    try {
        Write-Host "Found DLL at: $dllPath"
        
        # Read the file as a byte array.
        $bytes = [System.IO.File]::ReadAllBytes($dllPath)

        # Convert the bytes to a Base64 string.
        $base64String = [System.Convert]::ToBase64String($bytes)

        # Copy the resulting string to your clipboard.
        $base64String | Set-Clipboard

        Write-Host "Successfully encoded '$dllFileName' to Base64 and copied it to the clipboard." -ForegroundColor Green
    }
    catch {
        Write-Error "An unexpected error occurred during file read or conversion: $_"
    }
}
else {
    # If the file doesn't exist, provide a clear error message.
    Write-Error "Could not find the DLL. Please make sure '$dllFileName' is in the same directory as this script."
    Write-Error "Expected location: $dllPath"
}