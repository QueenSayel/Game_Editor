// MODIFIED a function in files/easter-egg.js

(function() {
    'use strict';

    // --- Configuration ---
    const config = {
        sequence: 'citi',
        imageUrl: 'icons/character.png', 
        speechBubbles: [
            "Co znowu zepsułaś?",
            "Nie spamuj mi tam lewego klika!",
            "A wolumen to masz zrobiony?",
            "Spoko, ale czy na pewno to chciałaś kliknąć?",
            "Ciągle kawusia, a klikać to nie ma komu...",
            "Wrzuciłaś odpowiedź do tamtego alertu?",
            "Ale dlaczego Edge?",
			"Nie lubię Edge, APAC korzysta z Edge",
			"Klikaj bo pójdziesz do RFIów!",
			"Wszystko fajnie, tylko czy tak miało być?",
			"Inwestuj w Labubu",
			"Labubu <3",
			"Stop, zatrzymaj się, poczekaj. Podziwiaj Labubu",
			"YAAAAAAAAAAAS",
			"SLAAAAAAAAAAY",
			"PLS STOPH",
			"Anty-Wixa measures active"
        ],
        speed: 3,
        duration: 12000
    };
	
	let messageQueue = [];

	function shuffleMessages() {
		const shuffled = [...config.speechBubbles];
		for (let i = shuffled.length - 1; i > 0; i--) {
			const j = Math.floor(Math.random() * (i + 1));
			[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
		}
		return shuffled;
	}

    // --- State ---
    let keySequence = [];
    let animationFrameId = null;

    // --- Key Listener ---
    document.addEventListener('keydown', (e) => {
        if (e.key.length > 1) {
            return;
        }
        keySequence.push(e.key.toLowerCase());
        keySequence = keySequence.slice(-config.sequence.length);

        if (keySequence.join('') === config.sequence) {
            triggerEasterEgg();
            keySequence = [];
        }
    });

    /**
     * Checks if the image exists, then creates and animates the character.
     */
    function triggerEasterEgg() {
        if (document.getElementById('easter-egg-container')) {
            return;
        }
        
        const imgCheck = new Image();
        imgCheck.onload = createAndAnimateCharacter;
        imgCheck.onerror = () => {
             console.error(`[EasterEgg] FATAL: Could not load image at path '${config.imageUrl}'.`);
        };
        imgCheck.src = config.imageUrl;
    }

    /**
     * Handles the creation of DOM elements and starts the animation.
     */
    function createAndAnimateCharacter() {
        injectCSS();

        const container = document.createElement('div');
        container.id = 'easter-egg-container';

        const character = document.createElement('img');
        character.id = 'easter-egg-character';
        character.src = config.imageUrl;

        const bubble = document.createElement('div');
        bubble.id = 'easter-egg-bubble';
		if (messageQueue.length === 0) {
			messageQueue = shuffleMessages();
		}

		// Pull the next message from the queue
		bubble.textContent = messageQueue.shift();

        container.appendChild(bubble);
        container.appendChild(character);
        document.body.appendChild(container);

        animate(container);
    }
    
    /**
     * The animation loop.
     * @param {HTMLElement} container - The main container for the character and bubble.
     */
	function animate(container) {
		let currentLeft = parseInt(window.getComputedStyle(container).left, 10);

		// Smooth random vertical starting point (5% to 70%)
		const baseTop = Math.random() * window.innerHeight * 0.65 + window.innerHeight * 0.05;

		// Random wave parameters per animation
		const wave1 = {
			amp: 30 + Math.random() * 30,       // 30–60 px
			freq: 0.01 + Math.random() * 0.02   // lower = smoother
		};
		const wave2 = {
			amp: 10 + Math.random() * 20,       // 10–30 px
			freq: 0.03 + Math.random() * 0.04
		};

		let frame = 0;

		function move() {
			currentLeft += config.speed;

			// Composite smooth wave (no random noise)
			const offsetY =
				Math.sin(frame * wave1.freq) * wave1.amp +
				Math.cos(frame * wave2.freq) * wave2.amp;

			container.style.left = currentLeft + 'px';
			container.style.top = `${baseTop + offsetY}px`;

			frame++;

			if (currentLeft < window.innerWidth) {
				animationFrameId = requestAnimationFrame(move);
			} else {
				cleanup(container);
			}
		}

		const safetyTimeout = setTimeout(() => cleanup(container), config.duration);
		container.dataset.safetyTimeout = safetyTimeout;

		animationFrameId = requestAnimationFrame(move);
	}

    /**
     * Removes the character elements and cancels any pending animations.
     * @param {HTMLElement} container - The main container to remove.
     */
    function cleanup(container) {
        if (container) {
            if (container.dataset.safetyTimeout) {
                clearTimeout(parseInt(container.dataset.safetyTimeout, 10));
            }
            if (container.parentNode) {
                container.parentNode.removeChild(container);
            }
        }
        if (animationFrameId) {
            cancelAnimationFrame(animationFrameId);
            animationFrameId = null;
        }
    }

    /**
     * Injects the necessary CSS for the speech bubble into the document's head.
     */
    function injectCSS() {
        if (document.getElementById('easter-egg-styles')) {
            return;
        }
        const style = document.createElement('style');
        style.id = 'easter-egg-styles';
        style.innerHTML = `
            #easter-egg-container {
                position: fixed;
                top: 25%;
                left: -200px; /* Start off-screen */
                z-index: 99999;
                transition: transform 0.3s ease-out;
            }
            #easter-egg-container:hover {
                transform: scale(1.1);
            }
            #easter-egg-character {
                width: 150px;
                height: auto;
                display: block;
            }
            #easter-egg-bubble {
                position: absolute;
                bottom: 145px; /* Position above the character */
                left: 50%;
                transform: translateX(-50%);
                background-color: #ffffff;
                color: #333;
                padding: 12px 18px;
                border-radius: 20px;
                border: 2px solid #ccc;
                box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                font-size: 14px;
                font-weight: 500;
                width: 180px;
                text-align: center;
            }
            #easter-egg-bubble::after {
                content: '';
                position: absolute;
                bottom: -12px; /* Position the tail */
                left: 50%;
                transform: translateX(-50%);
                border-width: 12px 12px 0;
                border-style: solid;
                border-color: #ffffff transparent transparent transparent;
            }
             #easter-egg-bubble::before {
                content: '';
                position: absolute;
                bottom: -16px; /* Position the border tail */
                left: 50%;
                transform: translateX(-50%);
                border-width: 14px 14px 0;
                border-style: solid;
                border-color: #ccc transparent transparent transparent;
                z-index: -1;
            }
        `;
        document.head.appendChild(style);
    }
})();