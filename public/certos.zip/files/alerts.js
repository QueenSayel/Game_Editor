// alerts.js

// --- DOM Element References ---
const newAlertBtn = document.getElementById('new-alert-btn');
const docxContainer = document.getElementById('docx-container');

// --- State ---
let previousViewHTML = ''; // Stores the view before opening the editor

// --- Event Listener ---
newAlertBtn.addEventListener('click', showNewAlertEditor);

/**
 * Replaces the current item view with an editor to create a new alert.
 */
function showNewAlertEditor() {
	document.getElementById('status').style.display = 'none';
    previousViewHTML = docxContainer.innerHTML;

    // Define the specific dropdown options
    const categories = ["SSI", "275", "283", "320", "295", "10", "44", "62", "Potential Mishandle", "203", "280", "268", "289", "244", "281.2", "238", "281.1", "FRB", "GCD", "128", "MVG|SFT", "525", "491", "LOCAL", "190", "239", "Citi Client", "STRIPE", "332", "Payment type 20"];
    const difficulties = ["easy", "medium", "hard"];

    const categoryOptions = categories.map(c => `<option value="${c}">${c}</option>`).join('');
    const difficultyOptions = difficulties.map(d => `<option value="${d}">${d}</option>`).join('');

    // Inject the new editor HTML, including the 'Creator' field
	const tableTemplate = `
	<table style="width: 100%; border-collapse: collapse;">
	  <tbody>
		<tr>
		  <th style="width: 50%; background-color: #003366; color: white; font-weight: bold; padding: 10px; border: 1px solid #ccc; text-align: center;">Transaction Information</th>
		  <th style="width: 50%; background-color: #003366; color: white; font-weight: bold; padding: 10px; border: 1px solid #ccc; text-align: center;">Match Information</th>
		</tr>
		<tr>
		  <td style="vertical-align: top; padding: 10px; border: 1px solid #ccc;">
			<p>Transaction data goes here</p>
		  </td>
		  <td style="vertical-align: top; padding: 10px; border: 1px solid #ccc;">
			<p>Match data goes here</p>
		  </td>
		</tr>
	  </tbody>
	</table>
	<p><br></p>
	`;

	// Inject the new editor HTML, with the pre-populated table
	docxContainer.innerHTML = `
		<div class="viewer-container" style="padding: 20px; background-color: #fdfdfd;">
			<h3 style="margin-top:0; border-bottom: 1px solid #eee; padding-bottom: 10px;">Create New Alert</h3>
			
			<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; gap: 20px;">
				<!-- Left side: Options -->
				<div style="display: flex; gap: 20px; flex-wrap: wrap;">
					<div>
						<label for="alert-category" style="font-weight: bold; margin-bottom: 5px; display: block;">Category:</label>
						<select id="alert-category" class="filter-select">${categoryOptions}</select>
					</div>
					<div>
						<label for="alert-difficulty" style="font-weight: bold; margin-bottom: 5px; display: block;">Difficulty:</label>
						<select id="alert-difficulty" class="filter-select">${difficultyOptions}</select>
					</div>
					<div>
						<label for="alert-user" style="font-weight: bold; margin-bottom: 5px; display: block;">Creator:</label>
						<input type="text" id="alert-user" class="filter-select" placeholder="Enter username...">
					</div>
				</div>
				<!-- Right side: Actions -->
				<div style="display: flex; gap: 10px; align-self: flex-end;">
					<button id="save-new-alert-btn">Save</button>
					<button id="cancel-new-alert-btn" style="background-color: #6c757d;">Cancel</button>
				</div>
			</div>

			<div class="editor-toolbar">
				<button data-command="bold" title="Bold" class="editor-action-btn">
					<i class="fas fa-bold"></i>
				</button>
				<button data-command="foreColor" data-value="red" title="Red Text" class="editor-action-btn">
					<i class="fas fa-fill-drip"></i>
				</button>
			</div>
			<div class="rich-text-editor" contenteditable="true">${tableTemplate}</div>
		</div>
	`;

    // Add event listeners for the new editor controls
    const editor = docxContainer.querySelector('.rich-text-editor');
    
    docxContainer.querySelector('.editor-toolbar').addEventListener('click', e => {
        const button = e.target.closest('button');
        if (button) {
            document.execCommand(button.dataset.command, false, button.dataset.value || null);
            editor.focus();
        }
    });
    
    // MODIFIED: Calls the new generalized saveAlert function with a null ID
    docxContainer.querySelector('#save-new-alert-btn').addEventListener('click', () => saveAlert(null));
    docxContainer.querySelector('#cancel-new-alert-btn').addEventListener('click', () => {
        if (previousViewHTML) docxContainer.innerHTML = previousViewHTML;
        // Re-render to restore listeners on the original view's buttons
        renderCurrentQuestion();
		document.getElementById('status').style.display = 'flex';
    });
    
    editor.focus();
}

/**
 * NEW: Replaces the current item view with an editor to edit an existing alert.
 * @param {object} alertData - The data for the alert being edited.
 */
function showEditAlertEditor(alertData) {
	document.getElementById('status').style.display = 'none';
    previousViewHTML = docxContainer.innerHTML;

    // Define dropdown options
    const categories = ["SSI", "275", "283", "320", "295", "10", "44", "62", "Potential Mishandle", "203", "280", "268", "289", "244", "281.2", "238", "281.1", "FRB", "GCD", "128", "MVG|SFT", "525", "491", "LOCAL", "190", "239", "Citi Client", "STRIPE", "332", "Payment type 20"];
    const difficulties = ["easy", "medium", "hard"];

    // Pre-select the correct options based on the alert's data
    const categoryOptions = categories.map(c => `<option value="${c}" ${alertData.category === c ? 'selected' : ''}>${c}</option>`).join('');
    const difficultyOptions = difficulties.map(d => `<option value="${d}" ${alertData.difficulty === d ? 'selected' : ''}>${d}</option>`).join('');

    // Inject the editor HTML, prepopulated with data and including a DELETE button
	docxContainer.innerHTML = `
		<div class="viewer-container" style="padding: 20px; background-color: #fdfdfd;">
			<h3 style="margin-top:0; border-bottom: 1px solid #eee; padding-bottom: 10px;">Edit Alert [ID: ${alertData.id}]</h3>
			
			<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; gap: 20px;">
				<!-- Left side: Options -->
				<div style="display: flex; gap: 20px; flex-wrap: wrap;">
					<div>
						<label for="alert-category" style="font-weight: bold; margin-bottom: 5px; display: block;">Category:</label>
						<select id="alert-category" class="filter-select">${categoryOptions}</select>
					</div>
					<div>
						<label for="alert-difficulty" style="font-weight: bold; margin-bottom: 5px; display: block;">Difficulty:</label>
						<select id="alert-difficulty" class="filter-select">${difficultyOptions}</select>
					</div>
					<div>
						<label for="alert-user" style="font-weight: bold; margin-bottom: 5px; display: block;">Creator:</label>
						<input type="text" id="alert-user" class="filter-select" value="${alertData.user || ''}" placeholder="Enter username...">
					</div>
				</div>
				<!-- Right side: Actions -->
				<div style="display: flex; gap: 10px; align-self: flex-end;">
					<button id="save-alert-btn">Save</button>
					<button id="cancel-alert-btn" style="background-color: #6c757d;">Cancel</button>
					<button id="delete-alert-btn" style="background-color: #dc3545;">Delete</button>
				</div>
			</div>

			<div class="editor-toolbar">
				<button data-command="bold" title="Bold" class="editor-action-btn">
					<i class="fas fa-bold"></i>
				</button>
				<button data-command="foreColor" data-value="red" title="Red Text" class="editor-action-btn">
					<i class="fas fa-fill-drip"></i>
				</button>
			</div>
			<div class="rich-text-editor" contenteditable="true">${alertData.content}</div>
		</div>
	`;

    // Add event listeners for the editor controls
    const editor = docxContainer.querySelector('.rich-text-editor');
    
    docxContainer.querySelector('.editor-toolbar').addEventListener('click', e => {
        const button = e.target.closest('button');
        if (button) {
            document.execCommand(button.dataset.command, false, button.dataset.value || null);
            editor.focus();
        }
    });
    
    // Wire up the buttons to the correct functions
    docxContainer.querySelector('#save-alert-btn').addEventListener('click', () => saveAlert(alertData.id));
    docxContainer.querySelector('#delete-alert-btn').addEventListener('click', () => deleteAlert(alertData.id));
    docxContainer.querySelector('#cancel-alert-btn').addEventListener('click', () => {
        if (previousViewHTML) docxContainer.innerHTML = previousViewHTML;
        // Re-render to restore listeners on the original view's buttons
        renderCurrentQuestion();
		document.getElementById('status').style.display = 'flex';
    });
    
    editor.focus();
}

// NEW: Expose the edit function to be called from script.js
window.showEditAlertEditor = showEditAlertEditor;


/**
 * MODIFIED: Saves an alert (new or existing) to the server.
 * @param {string|null} id - The ID of the alert to update, or null to create a new one.
 */
async function saveAlert(id = null) {
    const content = docxContainer.querySelector('.rich-text-editor').innerHTML;
    const category = docxContainer.querySelector('#alert-category').value;
    const difficulty = docxContainer.querySelector('#alert-difficulty').value;
    const user = docxContainer.querySelector('#alert-user').value.trim();
    
    if (!content.trim() || !category || !difficulty || !user) {
        alert('Content, Category, Difficulty, and Creator are required.');
        return;
    }
    
    try {
        const response = await fetch('/save-alert', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                id: id, // Pass the ID for updates, or null for new alerts
                content, 
                category, 
                difficulty, 
                user 
            })
        });

        if (!response.ok) {
            throw new Error(await response.text());
        }
        
        alert('Alert saved successfully! Refreshing data...');
        location.reload();

    } catch (error) {
        console.error('Error saving alert:', error);
        alert(`Error: ${error.message}`);
    }
}

/**
 * NEW: Deletes an alert from the server after confirmation.
 * @param {string} alertId - The ID of the alert to delete.
 */
async function deleteAlert(alertId) {
    if (!confirm(`Are you sure you want to permanently delete this alert [ID: ${alertId}]? This action cannot be undone.`)) {
        return;
    }

    try {
        const response = await fetch('/delete-alert', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: alertId })
        });

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const result = await response.json();
        if (result.status === 'success') {
            alert('Alert deleted successfully. Refreshing data...');
            location.reload();
        } else {
            throw new Error(result.message || 'Failed to delete on server.');
        }

    } catch (error) {
        console.error('Error deleting alert:', error);
        alert(`Error: ${error.message}`);
    }
}