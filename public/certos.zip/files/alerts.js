// alerts.js

// --- DOM Element References ---
const newAlertBtn = document.getElementById('new-alert-btn');
const docxContainer = document.getElementById('docx-container');

// --- State ---
let previousViewHTML = ''; // Stores the view before opening the editor

// --- Event Listener ---
newAlertBtn.addEventListener('click', showNewAlertEditor);

/**
 * Replaces the current item view with an editor to create a new alert.
 */
function showNewAlertEditor() {
	viewerContainer.removeEventListener('wheel', window.handleQuestionSwap);
	document.getElementById('status').style.display = 'none';
    previousViewHTML = docxContainer.innerHTML;

    // Define the specific dropdown options
    const categories = ["SSI", "275", "283", "320", "295", "10", "44", "62", "Potential Mishandle", "203", "280", "268", "289", "244", "281.2", "238", "281.1", "FRB", "GCD", "128", "MVG|SFT", "525", "491", "LOCAL", "190", "239", "Citi Client", "STRIPE", "332", "Payment type 20"];
    const difficulties = ["easy", "medium", "hard"];

    const categoryOptions = categories.map(c => `<option value="${c}">${c}</option>`).join('');
    const difficultyOptions = difficulties.map(d => `<option value="${d}">${d}</option>`).join('');

    // Inject the new editor HTML, including the 'Creator' field
	const tableTemplate = `
	<table style="width: 100%; border-collapse: collapse;">
	  <tbody>
		<tr>
		  <th style="width: 50%; background-color: #003366; color: white; font-weight: bold; padding: 10px; border: 1px solid #ccc; text-align: center;">Transaction Information</th>
		  <th style="width: 50%; background-color: #003366; color: white; font-weight: bold; padding: 10px; border: 1px solid #ccc; text-align: center;">Match Information</th>
		</tr>
		<tr>
		  <td style="vertical-align: top; padding: 10px; border: 1px solid #ccc;">
			<p>Transaction data goes here</p>
		  </td>
		  <td style="vertical-align: top; padding: 10px; border: 1px solid #ccc;">
			<p>Match data goes here</p>
		  </td>
		</tr>
	  </tbody>
	</table>
	<p><br></p>
	`;

	// Inject the new editor HTML, with the pre-populated table
	docxContainer.innerHTML = `
		<div class="viewer-container" style="padding: 20px; background-color: #fdfdfd;">
			<h3 style="margin-top:0; border-bottom: 1px solid #eee; padding-bottom: 10px;">Create New Alert</h3>
			
			<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; gap: 20px;">
				<!-- Left side: Options -->
				<div style="display: flex; gap: 10px; flex-wrap: wrap;">
					<div>
						<label for="alert-category" style="font-weight: bold; margin-bottom: 5px; display: block;">Category:</label>
						<select id="alert-category" class="filter-select">${categoryOptions}</select>
					</div>
					<div>
						<label for="alert-difficulty" style="font-weight: bold; margin-bottom: 5px; display: block;">Difficulty:</label>
						<select id="alert-difficulty" class="filter-select">${difficultyOptions}</select>
					</div>
					<div>
						<label for="alert-user" style="font-weight: bold; margin-bottom: 5px; display: block;">Creator:</label>
						<input type="text" id="alert-user" class="filter-select" value="${window.currentSessionUser || ''}" readonly>
					</div>
				</div>
				<!-- Right side: Actions -->
				<div style="display: flex; gap: 5px; align-self: flex-end;">
					<button id="save-new-alert-btn">Save</button>
					<button id="cancel-new-alert-btn" style="background-color: #6c757d;">Cancel</button>
				</div>
			</div>

			<div class="editor-toolbar">
				<button data-command="bold" title="Bold" class="editor-action-btn">
					<i class="fas fa-bold"></i>
				</button>
				<button data-command="foreColor" data-value="red" title="Red Text" class="editor-action-btn">
					<i class="fas fa-fill-drip"></i>
				</button>
			</div>
			<div class="rich-text-editor" contenteditable="true">${tableTemplate}</div>
		</div>
	`;

    // Add event listeners for the new editor controls
    const editor = docxContainer.querySelector('.rich-text-editor');
    
    docxContainer.querySelector('.editor-toolbar').addEventListener('click', e => {
        const button = e.target.closest('button');
        if (button) {
            document.execCommand(button.dataset.command, false, button.dataset.value || null);
            editor.focus();
        }
    });
    
    // MODIFIED: Calls the new generalized saveAlert function with a null ID
    docxContainer.querySelector('#save-new-alert-btn').addEventListener('click', () => saveAlert(null));
    docxContainer.querySelector('#cancel-new-alert-btn').addEventListener('click', () => {
        if (previousViewHTML) docxContainer.innerHTML = previousViewHTML;
        // Re-render to restore listeners on the original view's buttons
        renderCurrentQuestion();
		document.getElementById('status').style.display = 'flex';
		viewerContainer.addEventListener('wheel', window.handleQuestionSwap);
    });
    
    editor.focus();
}

/**
 * NEW: Replaces the current item view with an editor to edit an existing alert.
 * @param {object} alertData - The data for the alert being edited.
 */
function showEditAlertEditor(alertData) {
	viewerContainer.removeEventListener('wheel', window.handleQuestionSwap);
	document.getElementById('status').style.display = 'none';
    previousViewHTML = docxContainer.innerHTML;

    const categories = ["SSI", "275", "283", "320", "295", "10", "44", "62", "Potential Mishandle", "203", "280", "268", "289", "244", "281.2", "238", "281.1", "FRB", "GCD", "128", "MVG|SFT", "525", "491", "LOCAL", "190", "239", "Citi Client", "STRIPE", "332", "Payment type 20"];
    const difficulties = ["easy", "medium", "hard"];
    const categoryOptions = categories.map(c => `<option value="${c}" ${alertData.category === c ? 'selected' : ''}>${c}</option>`).join('');
    const difficultyOptions = difficulties.map(d => `<option value="${d}" ${alertData.difficulty === d ? 'selected' : ''}>${d}</option>`).join('');

    // --- START MODIFICATION: Conditional button and withdrawal reason UI ---
    const withdrawReintroduceButton = alertData.isWithdrawn
        ? `<button id="reintroduce-alert-btn" style="background-color: #198754;">Reintroduce</button>`
        : `<button id="withdraw-alert-btn" style="background-color: #6c757d;">Withdraw</button>`;

	docxContainer.innerHTML = `
		<div class="viewer-container" style="padding: 20px; background-color: #fdfdfd;">
			<h3 style="margin-top:0; border-bottom: 1px solid #eee; padding-bottom: 10px;">Edit Alert [ID: ${alertData.id}]</h3>
			
			<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; gap: 20px;">
				<div style="display: flex; gap: 10px; flex-wrap: wrap;">
					<div>
						<label for="alert-category" style="font-weight: bold; margin-bottom: 5px; display: block;">Category:</label>
						<select id="alert-category" class="filter-select">${categoryOptions}</select>
					</div>
					<div>
						<label for="alert-difficulty" style="font-weight: bold; margin-bottom: 5px; display: block;">Difficulty:</label>
						<select id="alert-difficulty" class="filter-select">${difficultyOptions}</select>
					</div>
					<div>
						<label for="alert-user" style="font-weight: bold; margin-bottom: 5px; display: block;">Creator:</label>
						<input type="text" id="alert-user" class="filter-select" value="${alertData.user || ''}" readonly>
					</div>
				</div>
				<div style="display: flex; gap: 5px; align-self: flex-end;">
					<button id="save-alert-btn">Save</button>
					<button id="cancel-alert-btn" style="background-color: #6c757d;">Cancel</button>
                    ${withdrawReintroduceButton}
					<button id="delete-alert-btn" style="background-color: #dc3545;">Delete</button>
				</div>
			</div>
			
            <div id="withdrawal-reason-container" style="display: none; margin-top: 20px; margin-bottom: 10px; padding: 15px; border: 1px solid #ffc107; background-color: #fffbeb; border-radius: 5px;">
                <label for="withdrawal-reason" style="font-weight: bold; display: block; margin-bottom: 5px;">Reason for withdrawal:</label>
                <textarea id="withdrawal-reason" style="width: 100%; min-height: 80px; padding: 8px; border-radius: 4px; border: 1px solid #ccc;"></textarea>
                <div style="text-align: right; margin-top: 10px;">
                    <button id="confirm-withdrawal-btn">Confirm</button>
                    <button id="cancel-withdrawal-btn" style="background-color: #6c757d;">Cancel</button>
                </div>
            </div>

			<div class="editor-toolbar">
				<button data-command="bold" title="Bold" class="editor-action-btn"><i class="fas fa-bold"></i></button>
				<button data-command="foreColor" data-value="red" title="Red Text" class="editor-action-btn"><i class="fas fa-fill-drip"></i></button>
			</div>
			<div class="rich-text-editor" contenteditable="true">${alertData.content}</div>
            
		</div>
	`;
    // --- END MODIFICATION ---

    const editor = docxContainer.querySelector('.rich-text-editor');
    
    docxContainer.querySelector('.editor-toolbar').addEventListener('click', e => {
        const button = e.target.closest('button');
        if (button) {
            document.execCommand(button.dataset.command, false, button.dataset.value || null);
            editor.focus();
        }
    });
    
    docxContainer.querySelector('#save-alert-btn').addEventListener('click', () => saveAlert(alertData.id, {}, 'edit'));
    docxContainer.querySelector('#delete-alert-btn').addEventListener('click', () => deleteAlert(alertData.id));
    docxContainer.querySelector('#cancel-alert-btn').addEventListener('click', () => {
        if (previousViewHTML) docxContainer.innerHTML = previousViewHTML;
        renderCurrentQuestion();
		document.getElementById('status').style.display = 'flex';
		viewerContainer.addEventListener('wheel', window.handleQuestionSwap);
    });

    // --- START MODIFICATION: Add event listeners for new buttons ---
    const withdrawBtn = docxContainer.querySelector('#withdraw-alert-btn');
    const reintroduceBtn = docxContainer.querySelector('#reintroduce-alert-btn');
    const reasonContainer = docxContainer.querySelector('#withdrawal-reason-container');

    if (withdrawBtn) {
        withdrawBtn.addEventListener('click', () => {
            reasonContainer.style.display = 'block';
        });

        docxContainer.querySelector('#cancel-withdrawal-btn').addEventListener('click', () => {
            reasonContainer.style.display = 'none';
        });

        docxContainer.querySelector('#confirm-withdrawal-btn').addEventListener('click', () => {
            const reason = docxContainer.querySelector('#withdrawal-reason').value.trim();
            if (!reason) {
                alert('A reason for withdrawal is required.');
                return;
            }
            saveAlert(alertData.id, { isWithdrawn: true, withdrawalReason: reason }, 'withdraw');
        });
    }

    if (reintroduceBtn) {
        reintroduceBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to reintroduce this alert? This will clear its withdrawal status.')) {
                saveAlert(alertData.id, { isWithdrawn: false, withdrawalReason: '' }, 'reintroduce');
            }
        });
    }
    // --- END MODIFICATION ---
    
    editor.focus();
}

// NEW: Expose the edit function to be called from script.js
window.showEditAlertEditor = showEditAlertEditor;


/**
 * MODIFIED: Saves an alert (new or existing) to the server.
 * @param {string|null} id - The ID of the alert to update, or null to create a new one.
 * @param {object} [overrideState={}] - Optional state for withdrawal/reintroduction.
 */
async function saveAlert(id = null, overrideState = {}, actionType = 'edit') {
    const saveBtn = docxContainer.querySelector('#save-new-alert-btn') || docxContainer.querySelector('#save-alert-btn');
    const content = docxContainer.querySelector('.rich-text-editor').innerHTML;
    const category = docxContainer.querySelector('#alert-category').value;
    const difficulty = docxContainer.querySelector('#alert-difficulty').value;
    const user = docxContainer.querySelector('#alert-user').value.trim();
    
    if (!content.trim() || !category || !difficulty || !user) {
        alert('Content, Category, Difficulty, and Creator are required.');
        return;
    }
    
    if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.textContent = 'Saving...';
        saveBtn.classList.add('disabled-button');
    }

    // --- START MODIFICATION ---
    const currentAlert = id ? window.metadataStore.find(a => a.id === id) : {};
    
    const payload = { 
        id: id,
        content, 
        category, 
        difficulty, 
        user,
        isWithdrawn: overrideState.isWithdrawn !== undefined ? overrideState.isWithdrawn : (currentAlert.isWithdrawn || false),
        withdrawalReason: overrideState.withdrawalReason !== undefined ? overrideState.withdrawalReason : (currentAlert.withdrawalReason || ''),
		actionType: actionType,
		editor: window.currentSessionUser
    };
    // --- END MODIFICATION ---

    try {
        const response = await fetch('/save-alert', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            throw new Error(await response.text());
        }
        
        const savedAlert = await response.json();
        
        window.updateLocalDataStore(savedAlert);
        window.applyAllFilters();
        window.navigateToAlertById(savedAlert.id);

        document.getElementById('status').style.display = 'flex';
		viewerContainer.addEventListener('wheel', window.handleQuestionSwap);
    } catch (error) {
        console.error('Error saving alert:', error);
        alert(`Error: ${error.message}`);
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.textContent = 'Save';
            saveBtn.classList.remove('disabled-button');
        }
    }
}

/**
 * NEW: Deletes an alert from the server after confirmation.
 * @param {string} alertId - The ID of the alert to delete.
 */
async function deleteAlert(alertId) {
    if (!confirm(`Are you sure you want to permanently delete this alert [ID: ${alertId}]? This action cannot be undone.`)) {
        return;
    }

	try {
		const response = await fetch('/delete-alert', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ 
				id: alertId,
				user: window.currentSessionUser // <<< ADD THIS LINE
			})
		});

        if (!response.ok) {
            throw new Error(await response.text());
        }

        const result = await response.json();
        if (result.status === 'success') {
            // 1. Remove the alert from local data store and selection
            window.removeAlertFromLocalStore(alertId);

            // 2. Re-apply filters which will re-render the view
            window.applyAllFilters();
            
            // 3. Restore the main status bar
            document.getElementById('status').style.display = 'flex';
			viewerContainer.addEventListener('wheel', window.handleQuestionSwap);
            alert('Alert deleted successfully.');
			
        } else {
            throw new Error(result.message || 'Failed to delete on server.');
        }

    } catch (error) {
        console.error('Error deleting alert:', error);
        alert(`Error: ${error.message}`);
    }
}