// files/activity-log.js

(function() {
    'use strict';
    // Encapsulate all logic in an IIFE to avoid polluting the global scope.

    let lastLogState = ''; // Stores the stringified version of the last log data
    const POLLING_INTERVAL = 5000; // Poll every 5 seconds
    let statusDiv = null; // We will store a reference to the status div
    let isInitialLoad = true; // --- NEW: Flag to prevent displaying messages on first poll ---
    let messageQueue = []; // --- NEW: Queue to manage displaying multiple messages ---
    let isDisplayingMessage = false; // --- NEW: Flag to prevent messages from overlapping ---

    /**
     * Processes the message queue, displaying one message at a time.
     */
    function processMessageQueue() {
        if (isDisplayingMessage || messageQueue.length === 0) {
            return; // Don't show a new message if one is already active or queue is empty
        }

        isDisplayingMessage = true;
        const message = messageQueue.shift(); // Get the next message from the queue

        if (!statusDiv) {
            isDisplayingMessage = false;
            return; // Exit if the status div isn't found
        }

        // 1. Create the new element
        const messageElement = document.createElement('div');
        messageElement.className = 'temporary-status-message';
        messageElement.textContent = message;

        // 2. Append it to the status div
        statusDiv.appendChild(messageElement);

        // 3. Force a reflow and then fade it in
        setTimeout(() => {
            messageElement.classList.add('visible');
        }, 10);

        // 4. Set a timer to fade it out
        setTimeout(() => {
            messageElement.classList.remove('visible');

            // After the fade-out is complete, remove the element and process the next message
            messageElement.addEventListener('transitionend', () => {
                messageElement.remove();
                isDisplayingMessage = false; // Free up the display for the next message
                processMessageQueue(); // Check if there are more messages to show
            });

        }, 2500); // Message stays visible for 2.5 seconds
    }

    /**
     * Adds a message to the queue and starts processing if not already active.
     * @param {string} message - The text to display.
     */
    function queueMessage(message) {
        messageQueue.push(message);
        processMessageQueue();
    }


    /**
     * Fetches the latest log data from the server and handles new entries.
     */
    async function pollForActivity() {
        try {
            const response = await fetch('/get-log');
            if (!response.ok) {
                if (pollForActivity.lastErrorStatus !== response.status) {
                     console.error(`[Activity Log] Failed to fetch log data. Status: ${response.status}`);
                     pollForActivity.lastErrorStatus = response.status;
                }
                return;
            }
            pollForActivity.lastErrorStatus = null;

            const data = await response.json();
            const currentState = JSON.stringify(data);

            // --- MODIFIED LOGIC HERE ---
            if (currentState !== lastLogState) {
                // If it's the first time we're loading the log, just set the state and exit.
                // This "syncs" the client without showing old messages.
                if (isInitialLoad) {
                    lastLogState = currentState;
                    isInitialLoad = false;
                    return;
                }

                // If it's not the initial load, we can compare and show new messages.
                const previousLog = lastLogState ? JSON.parse(lastLogState) : [];
                const newEntryCount = data.length - previousLog.length;

                if (newEntryCount > 0) {
                    const newMessages = data.slice(-newEntryCount);
                    
                    newMessages.forEach(log => {
                        const date = new Date(log.timestamp);
                        const formattedTime = date.toLocaleTimeString();
                        
                        // Log to console (as before)
                        console.log(`%c[Activity Log] ${formattedTime}: ${log.message}`, 'color: #0d6efd; font-weight: bold;');
                        
                        // --- MODIFIED: Format exam generation messages for display ---
                        let displayMessage = log.message;
                        const examGenRegex = /^(\S+) generated exam .* for examinee (\S+)$/;
                        if (examGenRegex.test(displayMessage)) {
                            displayMessage = displayMessage.replace(examGenRegex, '$1 generated exam for $2');
                        }
                        queueMessage(displayMessage);
                    });
                }

                lastLogState = currentState;
            }
        } catch (error) {
            console.error('[Activity Log] Error during polling:', error);
        }
    }

    /**
     * Initializes the polling mechanism.
     */
    function init() {
        statusDiv = document.getElementById('status');
        if (!statusDiv) {
            console.warn('[Activity Log] Could not find the #status div. Temporary messages will be disabled.');
        }

        console.log("Activity Log polling started. Open the developer console to view messages.");
        pollForActivity(); // Initial poll to sync state
        setInterval(pollForActivity, POLLING_INTERVAL);
    }

    // Start the system once the page's DOM is ready.
    document.addEventListener('DOMContentLoaded', init);

})();