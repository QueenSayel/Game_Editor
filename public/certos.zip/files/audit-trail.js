// files/audit-trail.js
(function() {
    'use strict';

    const modal = document.getElementById('audit-trail-modal');
    const viewBtn = document.getElementById('view-audit-trail');
    const closeBtn = document.getElementById('close-audit-trail-modal');
    const tableHeader = document.querySelector('#audit-trail-table thead');
    const tableBody = document.querySelector('#audit-trail-table tbody');
    const paginationContainer = document.getElementById('audit-trail-pagination');

    const ENTRIES_PER_PAGE = 50;
    let currentAuditEntries = [];
    let currentSortColumn = 'timestamp';
    let currentSortDirection = 'desc';

    async function fetchAuditData(page = 1) {
        try {
            tableBody.innerHTML = '<tr><td colspan="2" style="text-align:center; padding: 20px;">Loading...</td></tr>';

            const response = await fetch(`/get-audit-trail?page=${page}&limit=${ENTRIES_PER_PAGE}`);
            if (!response.ok) {
                throw new Error(`Server error: ${response.statusText}`);
            }
            const data = await response.json();
            
            currentAuditEntries = data.entries; // Store the fetched data
            sortAndRender(); // Initial sort and render
            renderPagination(data.total, page);

        } catch (error) {
            console.error('Failed to fetch audit trail:', error);
            tableBody.innerHTML = `<tr><td colspan="2" style="color:red; text-align:center; padding: 20px;">Error loading data.</td></tr>`;
        }
    }
    
    function sortAndRender() {
        // Sort the stored data based on the current state
        currentAuditEntries.sort((a, b) => {
            const valA = a[currentSortColumn];
            const valB = b[currentSortColumn];
            let comparison = 0;

            if (currentSortColumn === 'timestamp') {
                comparison = new Date(valA) - new Date(valB);
            } else {
                comparison = (valA || '').localeCompare(valB || '');
            }
            
            return comparison * (currentSortDirection === 'asc' ? 1 : -1);
        });
        
        renderAuditTable(currentAuditEntries);
    }


    function renderAuditTable(entries) {
        tableBody.innerHTML = ''; // Clear previous content
        
        // Update header sort indicators
        document.querySelectorAll('#audit-trail-table th[data-sort-by]').forEach(th => {
            th.classList.remove('sorted-asc', 'sorted-desc');
            if (th.dataset.sortBy === currentSortColumn) {
                th.classList.add(currentSortDirection === 'asc' ? 'sorted-asc' : 'sorted-desc');
            }
        });

        if (!entries || entries.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="2" style="text-align:center; padding: 20px;">No audit records found for this page.</td></tr>';
            return;
        }

        const fragment = document.createDocumentFragment();
        for (const entry of entries) {
            const tr = document.createElement('tr');
            const date = new Date(entry.timestamp);
            const formattedTimestamp = `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;

            tr.innerHTML = `
                <td>${formattedTimestamp}</td>
                <td>${entry.message}</td>
            `;
            fragment.appendChild(tr);
        }
        tableBody.appendChild(fragment);
    }

    function renderPagination(total, currentPage) {
        paginationContainer.innerHTML = '';
        if (total <= ENTRIES_PER_PAGE) return;

        const totalPages = Math.ceil(total / ENTRIES_PER_PAGE);

        const prevBtn = document.createElement('button');
        prevBtn.textContent = 'Previous';
        prevBtn.disabled = currentPage === 1;
        prevBtn.onclick = () => fetchAuditData(currentPage - 1);

        const nextBtn = document.createElement('button');
        nextBtn.textContent = 'Next';
        nextBtn.disabled = currentPage === totalPages;
        nextBtn.onclick = () => fetchAuditData(currentPage + 1);

        const status = document.createElement('span');
        status.textContent = `Page ${currentPage} of ${totalPages} (${total} records)`;
        status.style.margin = '0 15px';

        paginationContainer.append(prevBtn, status, nextBtn);
    }
    
    function handleSort(e) {
        const newSortColumn = e.target.dataset.sortBy;
        if (!newSortColumn) return;

        if (currentSortColumn === newSortColumn) {
            currentSortDirection = currentSortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            currentSortColumn = newSortColumn;
            currentSortDirection = 'asc'; // Default to ascending for new columns
        }
        sortAndRender();
    }

    function showModal() {
        modal.style.display = 'block';
        fetchAuditData(1);
    }

    function hideModal() {
        modal.style.display = 'none';
        tableBody.innerHTML = '';
        paginationContainer.innerHTML = '';
        currentAuditEntries = []; // Clear data on close
    }
    
    viewBtn.addEventListener('click', showModal);
    closeBtn.addEventListener('click', hideModal);
    tableHeader.addEventListener('click', handleSort);
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            hideModal();
        }
    });

})();