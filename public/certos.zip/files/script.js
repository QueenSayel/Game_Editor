//script.js
  
  // Add this function to generate the summary
function generateSelectionSummary() {
  const summary = {
    // --- MODIFIED: Use selectedAlertIDs ---
    total: selectedAlertIDs.size,
    categories: {},
    difficulties: {}
  };

  // --- MODIFIED: Iterate over alert IDs and find metadata ---
  selectedAlertIDs.forEach(alertId => {
    const meta = metadataStore.find(m => m.id === alertId);
    if (meta) {
      // Count categories (logic remains the same)
      summary.categories[meta.category] = 
        (summary.categories[meta.category] || 0) + 1;
      
      // Count difficulties (logic remains the same)
      summary.difficulties[meta.difficulty] = 
        (summary.difficulties[meta.difficulty] || 0) + 1;
    }
  });

  return summary;
}

// Function to display the summary
function displaySelectionSummary() {
  const summary = generateSelectionSummary();
  const container = document.getElementById('randomise-status-container');
  
  // Create category progress bars
  let categoryHtml = '';
  Object.entries(summary.categories).forEach(([category, count]) => {
    // Determine color based on category
    let barColor = '#4caf50';
    if (category.includes('Financial')) barColor = '#2196f3';
    if (category.includes('Operational')) barColor = '#ff9800';
    if (category.includes('Compliance')) barColor = '#9c27b0';
    if (category.includes('Strategic')) barColor = '#00bcd4';
    
    const percentage = Math.round((count / summary.total) * 100);
    
    categoryHtml += `
      <div style="margin-bottom: 12px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
          <span style="font-weight: 500;">${category}</span>
          <span style="font-weight: 700;">${count} <small style="opacity: 0.7;">(${percentage}%)</small></span>
        </div>
        <div style="
          height: 10px;
          background: #e0e0e0;
          border-radius: 5px;
          overflow: hidden;
        ">
          <div style="
            height: 100%;
            width: ${percentage}%;
            background: ${barColor};
            border-radius: 5px;
          "></div>
        </div>
      </div>
    `;
  });
  
  // Create difficulty bars
  let difficultyHtml = '';
  Object.entries(summary.difficulties).forEach(([difficulty, count]) => {
    // Determine color based on difficulty
    let barColor = '#4caf50';
    if (difficulty === 'medium') barColor = '#ff9800';
    if (difficulty === 'hard') barColor = '#f44336';
    if (difficulty === 'easy') barColor = '#2196f3';
    
    const percentage = Math.round((count / summary.total) * 100);
    
    difficultyHtml += `
      <div style="margin-bottom: 12px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
          <span style="font-weight: 500;">${difficulty}</span>
          <span style="font-weight: 700;">${count} <small style="opacity: 0.7;">(${percentage}%)</small></span>
        </div>
        <div style="
          height: 10px;
          background: #e0e0e0;
          border-radius: 5px;
          overflow: hidden;
        ">
          <div style="
            height: 100%;
            width: ${percentage}%;
            background: ${barColor};
            border-radius: 5px;
          "></div>
        </div>
      </div>
    `;
  });
  
  // Main summary HTML
  let html = `
    <div style="
      margin-top: 20px;
      padding: 20px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
      border: 1px solid #eaeaea;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    ">
      <div style="
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        padding-bottom: 15px;
        border-bottom: 1px solid #f0f0f0;
      ">
        <h4 style="margin: 0; font-size: 1.25rem; color: #2c3e50; font-weight: 600;">
          Summary
        </h4>
        <div style="
          background: #4e73df;
          color: white;
          border-radius: 16px;
          padding: 5px 15px;
          font-weight: 600;
          font-size: 1.1rem;
        ">
          ${summary.total} Questions
        </div>
      </div>
      
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px;">
        <div>
          <h5 style="
            margin-top: 0;
            margin-bottom: 15px;
            color: #5a5c69;
            font-size: 1rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          ">
            Categories
          </h5>
          <div>
            ${categoryHtml}
          </div>
        </div>
        
        <div>
          <h5 style="
            margin-top: 0;
            margin-bottom: 15px;
            color: #5a5c69;
            font-size: 1rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          ">
            Difficulty
          </h5>
          <div>
            ${difficultyHtml}
          </div>
        </div>
      </div>
    </div>
  `;
  
  container.innerHTML += html;
}
  
  const sentinel = document.getElementById('filters-sentinel');
  const filters = document.getElementById('filters');

  const observer = new IntersectionObserver(
    ([entry]) => {
      if (!entry.isIntersecting) {
        filters.classList.add('filters-shadow');
      } else {
        filters.classList.remove('filters-shadow');
      }
    },
    { threshold: 0 }
  );

  observer.observe(sentinel);

document.getElementById("scroll-to-top").addEventListener("click", function () {
    const activeTabButton = document.querySelector('.tab-button.active');
    if (!activeTabButton) return;
  
    const tabId = activeTabButton.dataset.tab;
  
    // Case 1: Active tab is an Assessment or Historical tab
    if (window.assessmentTabStates && window.assessmentTabStates[tabId]) {
      const state = window.assessmentTabStates[tabId];
      state.currentQuestionIndex = 0;
  
      // Call the correct render function based on tab type
      if (activeTabButton.textContent.includes('(Archival)')) {
        renderHistoricalQuestion(tabId);
      } else {
        renderAssessmentQuestion(tabId);
      }
      return;
    }
  
    // Case 2: Active tab is the main "Alerts" tab
    if (tabId === 'alerts' && window.filteredMetadata && window.filteredMetadata.length > 0) {
      currentQuestionIndex = 0;
      renderCurrentQuestion();
      return;
    }
  
    // Fallback for any other tab type
    window.scrollTo({ top: 0, behavior: 'auto' });
});

  // Function to toggle the visibility of the console viewer
  function toggleConsoleViewer() {
    const box = document.getElementById('console-log-box');
    box.style.display = box.style.display === 'none' ? 'block' : 'none';
  }

  (function interceptConsole() {
    const logBox = document.getElementById("console-log-box");
    const methods = ["log", "warn", "error", "info"];
    methods.forEach(method => {
      const original = console[method];
      console[method] = function(...args) {
        // Keep native behavior
        original.apply(console, args);

        // Format message
        const message = args.map(arg => {
          try {
            return typeof arg === "object" ? JSON.stringify(arg) : String(arg);
          } catch {
            return "[unserializable]";
          }
        }).join(" ");

        // Log to box
        if (logBox) {
          logBox.value += `[${method}] ${message}\n`;
          logBox.scrollTop = logBox.scrollHeight;
        }
      };
    });
  })();

	window.assessmentTabStates = {};
	window.metadataStore = [];
	window.examDetails = [];

	// --- NEW: Globals for Virtualization ---
	let currentQuestionIndex = 0; // Tracks the current question
	let isThrottled = false;
	window.filteredMetadata = []; // Will store the currently visible set of questions after filtering.
	window.unsavedAnswers = {};
	const docxContainer = document.getElementById('docx-container');
    const statusDiv = document.getElementById('status');
	const viewerContainer = document.getElementById('viewer-container');
    const applyFiltersBtn = document.getElementById('apply-filters-btn');
    const filterStatusDiv = document.getElementById('filter-status');
	const randomiseBtn = document.getElementById('randomise-btn');
	const randomiseModal = document.getElementById('randomise-modal');
	const conditionsContainer = document.getElementById('conditions-container');
	const modal = document.getElementById('exam-modal');
	const span = document.getElementsByClassName('close')[0];
	let examPreviewWindow = null;
	randomiseBtn.addEventListener('click', showRandomiseModal);
	
	function showRandomiseModal() {
	randomiseModal.style.display = 'block';
	populateConditionOptions();
	}
	
	function closeRandomiseModal() {
	randomiseModal.style.display = 'none';
	}
	
	function showExamModal() {
		modal.style.display = 'block';
		refreshExamList();
	}
	
	function populateConditionOptions() {
	  // Clone existing category and difficulty options
	  const categoryOptions = document.getElementById('category-filter').cloneNode(true);
	  const difficultyOptions = document.getElementById('difficulty-filter').cloneNode(true);
	  
	  // Store references for later use
	  window.randomiseCategories = categoryOptions;
	  window.randomiseDifficulties = difficultyOptions;
	}	

	// Condition creation functions
	document.getElementById('add-category-condition').addEventListener('click', () => {
	  createConditionRow('category');
	});

	document.getElementById('add-difficulty-condition').addEventListener('click', () => {
	  createConditionRow('difficulty');
	});

	function createConditionRow(type) {
	  const row = document.createElement('div');
	  row.className = 'condition-row';
	  
	  const select = document.createElement('select');
	  select.className = `condition-${type}-select`;
	  select.innerHTML = type === 'category' 
		? window.randomiseCategories.innerHTML 
		: window.randomiseDifficulties.innerHTML;

	const operatorSelect = document.createElement('select');
	operatorSelect.innerHTML = `
		<option value=">">More Than</option>
		<option value="=">Exactly</option>
		<option value="<">Less Than</option>
	`;



	  const valueInput = document.createElement('input');
	  valueInput.type = 'number';
	  valueInput.min = '1';
	  valueInput.value = '1';

	  const removeBtn = document.createElement('button');
	  removeBtn.textContent = '×';
	  removeBtn.className = 'remove-condition';
	  removeBtn.onclick = () => row.remove();

	  row.append(
		select,
		operatorSelect,
		valueInput,
		removeBtn
	  );

	  conditionsContainer.appendChild(row);
	}

span.onclick = () => modal.style.display = 'none';
window.onclick = (event) => {
    if (event.target === modal) modal.style.display = 'none';
}
document.querySelector('.validate-btn').addEventListener('click', handleValidation);
window.handleValidation = handleValidation;
function handleValidation(e) {
    const isRevalidation = e.target.classList.contains('btn-revalidate');
    e.preventDefault();
    clearStatusMessage();
    document.querySelector('.analytics-btn').disabled = true;
    const questionCount = parseInt(document.getElementById('question-count').value, 10);
    const totalQuestions = metadataStore.length;
    let validationFailed = false;

    console.group("Question Randomizer Run");
    console.log(`Total questions requested: ${questionCount}`);

    // 1. Collect all conditions (this part remains the same)
    const conditions = Array.from(document.querySelectorAll('.condition-row')).map(row => {
        const typeSelect = row.querySelector('select:first-child');
        const operator = row.querySelector('select:nth-child(2)').value;
        const value = parseInt(row.querySelector('input').value, 10);
        
        return {
            type: typeSelect.className.includes('category') ? 'category' : 'difficulty',
            field: typeSelect.value,
            operator,
            required: value
        };
    });

    console.log("Conditions:", conditions);

    // 2. Handle case with no conditions
    if (conditions.length === 0) {
        try {
            if (questionCount > totalQuestions) {
                showStatusMessage(
                    `Requested ${questionCount} questions but only ${totalQuestions} available`,
                    true
                );
                console.groupEnd();
                return;
            }
            
            // --- MODIFIED: Select from all alerts and add by ID ---
            selectedAlertIDs.clear();
            const allAlerts = shuffleArray([...metadataStore]);
            const selected = allAlerts.slice(0, questionCount);
            selected.forEach(alert => selectedAlertIDs.add(alert.id));
            
            // --- MODIFIED: Log detailed selection info using IDs ---
            const selectionDetails = Array.from(selectedAlertIDs).map(alertId => {
                const meta = metadataStore.find(m => m.id === alertId);
                return { id: meta.id, category: meta.category, difficulty: meta.difficulty };
            }).sort((a, b) => a.id.localeCompare(b.id));
            
            console.log("Final selected questions:");
            console.table(selectionDetails);
            console.log(`Total selected: ${selectionDetails.length}`);
            console.groupEnd();
            
            updateSelectedCount();
            document.querySelector('.analytics-btn').disabled = false;
            displaySelectionSummary();
			document.getElementById('view-selected-btn').click();
            return;
        } catch (err) {
            showStatusMessage(`Selection error: ${err.message}`);
            console.groupEnd();
            return;
        }
    }

    // --- Steps 3 to 8 for validation remain mostly the same ---
    const exactConditions = conditions.filter(c => c.operator === '=');
    const rangeConditions = conditions.filter(c => c.operator !== '=');

    exactConditions.forEach(condition => {
        const available = metadataStore.filter(meta => 
            meta[condition.type] === condition.field
        ).length;
        if (available < condition.required) {
            showStatusMessage(`Not enough ${condition.type} "${condition.field}" questions. Required: ${condition.required}, Available: ${available}`);
            validationFailed = true;
        }
    });

    if (questionCount > totalQuestions) {
        showStatusMessage(`Requested ${questionCount} questions but only ${totalQuestions} available`);
        validationFailed = true;
    }

    const totalExactRequired = exactConditions.reduce((sum, c) => sum + c.required, 0);
    const remainingSlots = questionCount - totalExactRequired;
    if (remainingSlots < 0) {
        showStatusMessage(`Exact conditions require ${totalExactRequired} questions but total requested is only ${questionCount}`);
        validationFailed = true;
    }

    const totalRangeMinimum = rangeConditions.reduce((sum, cond) => (cond.operator === '>') ? sum + (cond.required + 1) : sum, 0);
    if (totalRangeMinimum > remainingSlots) {
        showStatusMessage(`Range conditions require minimum ${totalRangeMinimum} questions but only ${remainingSlots} available after exact conditions`);
        validationFailed = true;
    }

    rangeConditions.forEach(condition => {
        const available = metadataStore.filter(meta => meta[condition.type] === condition.field).length;
        let isValid = (condition.operator === '>') ? (available > condition.required) : (condition.operator === '<') ? (available < condition.required) : true;
        if (!isValid) {
            showStatusMessage(`${condition.type} "${condition.field}" condition failed: ${available} available vs ${condition.operator} ${condition.required} required`);
            validationFailed = true;
        }
    });

    if (validationFailed) {
        console.groupEnd();
        return;
    }

    // 9. Perform selection using alert IDs
    try {
        // --- MODIFIED: Use selectedAlertIDs ---
        selectedAlertIDs.clear();

        // Phase 1: Select exact requirements first
        exactConditions.forEach(condition => {
            const candidates = metadataStore.filter(meta => meta[condition.type] === condition.field);
            const selected = shuffleArray(candidates).slice(0, condition.required);
            // --- MODIFIED: Add by ID ---
            selected.forEach(q => selectedAlertIDs.add(q.id));
        });

        const excludedFields = new Set(exactConditions.map(c => c.field));

        // Phase 2: Fill remaining slots
        const remainingNeeded = questionCount - selectedAlertIDs.size;
        if (remainingNeeded > 0) {
            // --- MODIFIED: Filter available candidates using IDs ---
            let availableCandidates = metadataStore.filter(meta => {
                if (selectedAlertIDs.has(meta.id)) return false; // Check if already selected by ID
                if (excludedFields.has(meta.category) || excludedFields.has(meta.difficulty)) return false;
                return true;
            });

            const selected = shuffleArray(availableCandidates).slice(0, remainingNeeded);
            // --- MODIFIED: Add by ID ---
            selected.forEach(q => selectedAlertIDs.add(q.id));
        }

        // --- MODIFIED: Log detailed selection info using IDs ---
        const finalSelectionDetails = Array.from(selectedAlertIDs).map(alertId => {
            const meta = metadataStore.find(m => m.id === alertId);
            return { id: meta.id, category: meta.category, difficulty: meta.difficulty };
        }).sort((a, b) => a.id.localeCompare(b.id));
        
        console.log("Final selected questions:");
        console.table(finalSelectionDetails);
        console.log(`Total selected: ${finalSelectionDetails.length}`);
        
        if (selectedAlertIDs.size < questionCount) {
             showStatusMessage(
                `Could not meet the total of ${questionCount} questions with the given constraints. Only selected ${selectedAlertIDs.size}.`,
                true
            );
        }

        console.groupEnd();

        updateSelectedCount();
        document.querySelector('.analytics-btn').disabled = false;
        displaySelectionSummary();
		document.getElementById('view-selected-btn').click();
    } catch (err) {
        showStatusMessage(`Selection error: ${err.message}`);
        console.error("Selection failed with error:", err);
        console.groupEnd();
    }
}

// Helper function
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// Helper functions
function getConditionLimit(condition) {
    switch(condition.operator) {
        case '>': return Infinity;
        case '=': return condition.required;
        case '<': return condition.required - 1;
        default: return 0;
    }
}

function updateButtonStates() {
    const pageElement = document.querySelector('#docx-container section.docx');
    if (!pageElement) return;

    const itemData = window.filteredMetadata[currentQuestionIndex];
    if (!itemData) return;

    const addBtn = pageElement.querySelector('.add-question-btn');
    const removeBtn = pageElement.querySelector('.remove-question-btn');
    
    if (!addBtn || !removeBtn) return;

    // Check if the current alert's ID is in the set
    if (selectedAlertIDs.has(itemData.id)) {
        addBtn.style.display = 'none';
        removeBtn.style.display = 'inline-block';
    } else {
        addBtn.style.display = 'inline-block';
        removeBtn.style.display = 'none';
    }
}

function showStatusMessage(message, isError = true) {
  const container = document.getElementById('randomise-status-container');

  // Create a new status div
  const statusDiv = document.createElement('div');
  statusDiv.className = `alert ${isError ? 'alert-error' : ''}`;
  statusDiv.style.display = 'flex';
  statusDiv.style.marginBottom = '10px';
  statusDiv.style.padding = '10px';
  statusDiv.style.borderRadius = '4px';

  const statusText = document.createElement('span');
  statusText.className = 'status-text';
  statusText.textContent = message;

  statusDiv.appendChild(statusText);
  container.appendChild(statusDiv);

}

function clearStatusMessage() {
  const container = document.getElementById('randomise-status-container');
  if (container) {
    container.innerHTML = '';
  }
}
let examDetails = [];
// Exam list functionality
async function refreshExamList() {
    const listDiv = document.getElementById('exam-list');

    try {
        listDiv.innerHTML = `
            <div class="exam-item" style="justify-content: left; flex-direction: row; align-items: center;">
                <img src="icons/loading.svg" class="loading-spinner" style="width: 40px; height: 40px;" alt="Loading">
                <div style="margin-top: 2px; color: #555;">Loading exams...</div>
            </div>
        `;

        // Fetch exam details (the source of truth) and analytics status.
        // We no longer need to fetch the file list from the disk.
        const [detailsResponse, analyticsResponse] = await Promise.all([
            fetch('/list-exam-details'),
            fetch('/get-analytics-exam-ids')
        ]);

        if (!detailsResponse.ok) {
            throw new Error('Failed to load exam details');
        }

        // Get the data
		let allExamDetails = await detailsResponse.json();
		const analyticsExamStatus = analyticsResponse.ok ? await analyticsResponse.json() : {};

		// First, ensure the data is an array. This makes the code robust.
		if (!Array.isArray(allExamDetails)) {
			allExamDetails = allExamDetails ? [allExamDetails] : [];
		}

		// NOW, assign the guaranteed-to-be-an-array value to both the window and module scope.
		window.examDetails = examDetails = allExamDetails;

        // Sort exams by timestamp with a robust parser, so newest appear first
        examDetails.sort((a, b) => {
            const parseDate = (timestamp) => {
                if (!timestamp) return 0;
                let dt = new Date(timestamp.replace(' ', 'T')); // Handles "yyyy-MM-dd HH:mm:ss"
                if (!isNaN(dt)) return dt.getTime();
                if (timestamp.includes('.') && timestamp.includes(':')) { // Handles "dd.MM.yyyy HH:mm:ss"
                    const parts = timestamp.split(' ');
                    const dateParts = parts[0].split('.');
                    const timeParts = parts[1].split(':');
                    dt = new Date(dateParts[2], dateParts[1] - 1, dateParts[0], timeParts[0], timeParts[1], timeParts[2] || 0);
                    if (!isNaN(dt)) return dt.getTime();
                }
                return 0;
            };
            return parseDate(b.Timestamp) - parseDate(a.Timestamp);
        });

        if (examDetails.length > 0) {
            // Iterate over every exam record from the database
            const renderedHTML = examDetails.map(detail => {
                // Skip any malformed records
                if (!detail || !detail.PDFFile || !detail.ExamID) return '';

                // CORRECT: Use the unique ExamID for analytics lookup (case-insensitive)
                const examIdKey = detail.ExamID.trim().toLowerCase();
                const hasAnalytics = analyticsExamStatus.hasOwnProperty(examIdKey);
                const examStatus = analyticsExamStatus[examIdKey] || '';

                // Build status badges based on the correct lookup
                let statusBadges = '';
                if (hasAnalytics) {
                    statusBadges += `<span class="status-badge assessed" style="display: inline-block; margin-bottom: 10px; margin-right: 5px;">Assessed</span>`;
                    if (examStatus === 'passed') {
                        statusBadges += `<span class="status-badge passed" style="display: inline-block; margin-bottom: 10px;">Passed</span>`;
                    } else if (examStatus === 'failed') {
                        statusBadges += `<span class="status-badge failed" style="display: inline-block; margin-bottom: 10px;">Failed</span>`;
                    } else if (examStatus === 'mishandle') {
                        statusBadges += `<span class="status-badge mishandle" style="display: inline-block; margin-bottom: 10px;">Mishandle</span>`;
                    }
                } else {
                    statusBadges = `<span class="status-badge pending" style="display: inline-block; margin-bottom: 10px;">Pending Assessment</span>`;
                }

                // Add data-exam-id to the parent div to uniquely identify it later
                return `
                    <div class="exam-item" data-exam-id="${detail.ExamID}" data-pdf-file="${detail.PDFFile}">
                        <div>
                            <a href="/${encodeURIComponent(detail.PDFFile)}" target="_blank" style="display: block; margin-bottom: 5px;">${detail.PDFFile}</a>
                            ${statusBadges}
                            <div class="exam-details">
                                <div>Creation Date: ${detail.Timestamp || 'No date recorded'}</div>
                                ${detail.Examiner ? `<div>Examiner: ${detail.Examiner}</div>` : ''}
                                ${detail.Examinee ? `<div>Examinee: ${detail.Examinee}</div>` : ''}
                                ${detail.Comment ? `<div>Comment: ${detail.Comment}</div>` : ''}
                                ${detail.Questions ? `<div>Questions: ${detail.Questions}</div>` : ''}
                            </div>
                            <div class="dropdown">
                                <button class="dropdown-toggle" type="button">⋮</button>
                                <div class="dropdown-menu">
								    <div class="dropdown-item clone-option">
										Clone
									</div>
                                    <div class="dropdown-item load-option ${detail.Questions ? '' : 'disabled'}">
                                        Select questions
                                    </div>
									<div class="dropdown-item print-pdf-option ${detail.Questions ? '' : 'disabled'}">
										Legacy print
									</div>
									<div class="dropdown-item mail-option" ${detail.Examinee ? '' : 'disabled'}>
										Mail exam
									</div>
                                    <div class="dropdown-item assess-option" ${hasAnalytics ? 'disabled' : ''}>
                                        Assess
                                    </div>
                                    <div class="dropdown-item answers-option ${hasAnalytics ? '' : 'disabled'}">
                                        Load answers
                                    </div>
                                    <div class="dropdown-item download-option ${hasAnalytics ? '' : 'disabled'}">
                                        Download report
                                    </div>
                                    <div class="dropdown-item retake-option ${hasAnalytics ? '' : 'disabled'}">
                                        Retake
                                    </div>
									<div class="dropdown-item generate-code-option">
										Single-use code
									</div>
									<div class="dropdown-item delete-option" style="color: #dc3545;">
										Delete
									</div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');

            listDiv.innerHTML = renderedHTML;
        } else {
            listDiv.innerHTML = '<div class="exam-item">No exams generated yet</div>';
        }
    } catch (err) {
        console.error('Error loading exams:', err);
        listDiv.innerHTML = '<div class="exam-item">Error loading exam list</div>';
    }
}

// Add this code to your existing JavaScript
document.addEventListener('click', function(e) {
    // Close dropdowns when clicking outside
    if (!e.target.closest('.dropdown')) {
        document.querySelectorAll('.dropdown-menu').forEach(menu => {
            menu.classList.remove('show');
        });
    }
});


document.addEventListener('click', async function(e) {
	// Handle dropdown toggle
    if (e.target.classList.contains('dropdown-toggle')) {
        e.stopPropagation();
        const button = e.target;
        const menu = button.closest('.dropdown').querySelector('.dropdown-menu');


        const isAlreadyOpen = menu.classList.contains('show');


        document.querySelectorAll('.dropdown-menu.show').forEach(m => m.classList.remove('show'));


        if (!isAlreadyOpen) {

            const rect = button.getBoundingClientRect();

            menu.style.top = `${rect.bottom - 10}px`;

            menu.style.left = 'auto';
            menu.style.right = `${window.innerWidth - rect.right - 5}px`;
            
            menu.classList.add('show');
        }
    }
    // Handle load option
    else if (e.target.classList.contains('load-option')) {
        e.preventDefault();
        if (e.target.hasAttribute('disabled')) return;

        const examItem = e.target.closest('.exam-item');
        const uniqueExamId = examItem.dataset.examId; // CORRECT: Get the unique ID
        const examDetail = examDetails.find(d => d.ExamID === uniqueExamId);

	if (examDetail?.Questions) {
		// 1. Clear the correct set
		selectedAlertIDs.clear(); 

		// 2. Get the array of alert IDs from the exam record
		const questionsArray = (examDetail.Questions || '').split(',').map(q => q.trim());

		// 3. Add each alert ID directly to our new set
		questionsArray.forEach(questionId => {
			if (questionId) { // Ensure we don't add empty strings
				selectedAlertIDs.add(questionId);
			}
		});

		// 4. Update the UI
		updateSelectedCount();
		// We no longer need updateButtonStates() here as it only affects the single visible question.
		
		closeExamDetailsModal(); // Close the main exam details modal if open
		modal.style.display = 'none'; // Close the exam list modal
		document.getElementById('view-selected-btn').click();
	}
        e.target.closest('.dropdown-menu').classList.remove('show');
    }
	// Handle mail option
	else if (e.target.classList.contains('mail-option')) {
		e.preventDefault();
		if (e.target.classList.contains('disabled') || e.target.hasAttribute('disabled')) return;

		const mailOption = e.target;
		const examItem = mailOption.closest('.exam-item');
		const uniqueExamId = examItem.dataset.examId;
		const originalText = mailOption.textContent;

		if (!uniqueExamId) {
			alert('Could not find Exam ID for this item.');
			return;
		}
		
		// Show loading state and prevent multiple clicks
		mailOption.textContent = 'Preparing...';
		mailOption.classList.add('disabled');
		
		try {
			// Call our new server endpoint
			const response = await fetch('/mail-exam', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ examId: uniqueExamId })
			});

			if (!response.ok) {
				const errorText = await response.text();
				throw new Error(errorText || `Server responded with status ${response.status}`);
			}

			// Success! The server handled it.
			// The user just needs to check their Outlook window.
			
		} catch (error) {
			console.error('Mailing exam failed:', error);
			alert(`Failed to prepare email: ${error.message}`);
		} finally {
			// Restore button state
			mailOption.textContent = originalText;
			mailOption.classList.remove('disabled');
		}

		e.target.closest('.dropdown-menu').classList.remove('show');
	}
    // Handle assess option
    else if (e.target.classList.contains('assess-option')) {
        e.preventDefault();
        if (e.target.hasAttribute('disabled')) return;

        const examItem = e.target.closest('.exam-item');
        const uniqueExamId = examItem.dataset.examId;
        const examDetail = examDetails.find(d => d.ExamID === uniqueExamId);

        if (examDetail?.Questions) {
            const questionsArray = Array.isArray(examDetail.Questions) 
                ? examDetail.Questions 
                : (() => {
                    try { return JSON.parse(examDetail.Questions || '[]'); } 
                    catch { return (examDetail.Questions || '').split(',').map(q => q.trim()); }
                })();
            document.getElementById('exam-modal').style.display = 'none';
			createAssessTab(examDetail, questionsArray);
        }
        e.target.closest('.dropdown-menu').classList.remove('show');
    }
    // Handle clone option
    else if (e.target.classList.contains('clone-option')) {
        e.preventDefault();
        const examItem = e.target.closest('.exam-item');
        const uniqueExamId = examItem.dataset.examId;
        const examDetail = examDetails.find(d => d.ExamID === uniqueExamId);

        if (examDetail) {
            cloneExam(examDetail);
        }
        e.target.closest('.dropdown-menu').classList.remove('show');
    }
    // Handle Print PDF option
    else if (e.target.classList.contains('print-pdf-option')) {
        e.preventDefault();
        if (e.target.classList.contains('disabled')) return;

        const examItem = e.target.closest('.exam-item');
        const uniqueExamId = examItem.dataset.examId;
        const examDetail = window.examDetails.find(d => d.ExamID === uniqueExamId);

        if (examDetail) {
            const originalText = e.target.textContent;
            try {
                e.target.textContent = 'Printing...';
                e.target.classList.add('disabled');
                // Call the function that will do the heavy lifting
                await generateExamPDF(examDetail);
            } catch (error) {
                console.error('PDF Generation Error:', error);
                alert('Failed to generate PDF. Please check the console for more details.');
            } finally {
                // Restore the button's state
                e.target.textContent = originalText;
                e.target.classList.remove('disabled');
            }
        }

        e.target.closest('.dropdown-menu').classList.remove('show');
    }
    // Handle retake option
    else if (e.target.classList.contains('retake-option')) {
        e.preventDefault();
        if (!e.target.hasAttribute('disabled')) {
            const examItem = e.target.closest('.exam-item');
            const examName = examItem.querySelector('a').textContent;
            console.log('Retake clicked for:', examName);
        }
        e.target.closest('.dropdown-menu').classList.remove('show');
    }
	else if (e.target.classList.contains('delete-option')) {
		e.preventDefault();
		
		const examItem = e.target.closest('.exam-item');
		const examId = examItem.dataset.examId;
		const pdfFile = examItem.dataset.pdfFile;
		
		if (!examId) {
			alert('Could not identify the exam to delete.');
			return;
		}

		const modal = document.getElementById('delete-exam-modal');
		modal.dataset.examId = examId;
		modal.dataset.pdfFile = pdfFile;
		
		// Reset toggles to unchecked state
		document.getElementById('delete-toggle-file').checked = false;
		document.getElementById('delete-toggle-exam').checked = false;
		document.getElementById('delete-toggle-analytics').checked = false;

		modal.style.display = 'block';
		e.target.closest('.dropdown-menu').classList.remove('show');
	}
    // Close all dropdowns when clicking outside
    else {
        document.querySelectorAll('.dropdown-menu').forEach(menu => {
            menu.classList.remove('show');
        });
    }
});

const deleteModal = document.getElementById('delete-exam-modal');
const closeDeleteModalBtn = document.getElementById('close-delete-modal');
const cancelDeleteBtn = document.getElementById('cancel-delete-btn');
const confirmDeleteBtn = document.getElementById('confirm-delete-btn');

function closeDeleteModal() {
    if(deleteModal) deleteModal.style.display = 'none';
}

if(closeDeleteModalBtn) closeDeleteModalBtn.addEventListener('click', closeDeleteModal);
if(cancelDeleteBtn) cancelDeleteBtn.addEventListener('click', closeDeleteModal);

if(confirmDeleteBtn) {
    confirmDeleteBtn.addEventListener('click', async () => {
        const examId = deleteModal.dataset.examId;
        const pdfFile = deleteModal.dataset.pdfFile;

        const deleteFile = document.getElementById('delete-toggle-file').checked;
        const deleteExamRecord = document.getElementById('delete-toggle-exam').checked;
        const deleteAnalytics = document.getElementById('delete-toggle-analytics').checked;

        if (!deleteFile && !deleteExamRecord && !deleteAnalytics) {
            alert('Please select at least one deletion action.');
            return;
        }

        confirmDeleteBtn.textContent = 'Deleting...';
        confirmDeleteBtn.disabled = true;

        try {
            const response = await fetch('/delete-exam-data', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    examId,
                    pdfFile,
                    deleteFile,
                    deleteExamRecord,
                    deleteAnalytics
                })
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText || 'Server responded with an error.');
            }

            const result = await response.json();
            alert(result.message || 'Deletion successful!');
            
            closeDeleteModal();
            await refreshExamList();

        } catch (error) {
            console.error('Deletion failed:', error);
            alert(`Deletion failed: ${error.message}`);
        } finally {
            confirmDeleteBtn.textContent = 'Confirm Delete';
            confirmDeleteBtn.disabled = false;
        }
    });
}

function cloneExam(examDetail) {
    // Open the exam modal with prefilled values
    document.getElementById('examiner').value = examDetail.Examiner || '';
    document.getElementById('examinee').value = ''; // Clear examinee for new exam
    document.getElementById('exam-comment').value = examDetail.Comment || '';
    
    // Store exam detail for later use
    window.cloneSource = examDetail;
    
    // Show the modal
    showExamDetailsModal();
}

function showResultsModal(results, totalPoints, possiblePoints, percentage, passed, hasMishandle, currentExamDetail, tabId, isHistorical = false) {
    window.currentExamDetail = currentExamDetail || {};
    const modal = document.getElementById('results-modal');
    const content = document.getElementById('results-content');
    modal.dataset.assessmentTabId = tabId;
    
    let examiner = currentExamDetail?.Examiner || 'N/A';
    let examinee = currentExamDetail?.Examinee || 'N/A';

    // Get comments from the state object
    const state = window.assessmentTabStates[tabId];
    const comments = state ? state.questionIDs.map(qId => state.assessmentData[qId]?.comment || 'N/A') : [];

    const categoryTotals = results.reduce((acc, result) => {
        acc.input += result.inputType ? 1 : 0;
        acc.list += result.listEntry ? 1 : 0;
        acc.rationale += result.rationale ? 1 : 0;
        acc.disposition += result.disposition ? 1 : 0;
        return acc;
    }, { input: 0, list: 0, rationale: 0, disposition: 0 });

    const totalQuestions = results.length;
    const categoryPercentages = {
        input: totalQuestions > 0 ? Math.round((categoryTotals.input / totalQuestions) * 100) : 0,
        list: totalQuestions > 0 ? Math.round((categoryTotals.list / totalQuestions) * 100) : 0,
        rationale: totalQuestions > 0 ? Math.round((categoryTotals.rationale / totalQuestions) * 100) : 0,
        disposition: totalQuestions > 0 ? Math.round((categoryTotals.disposition / totalQuestions) * 100) : 0
    };

    let html = `
    <div class="result-summary" style="margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
            <div>
                <h4 style="color: ${passed ? '#28a745' : '#dc3545'}; margin: 0;">
                    ${passed ? 'PASSED' : 'FAILED'} (${percentage}%)
                </h4>
                ${hasMishandle ? '<p style="color: #dc3545; margin: 5px 0 0 0;">Test failed due to a mishandle</p>' : ''}
            </div>
            <div style="text-align: right;">
                <div><strong>Examiner:</strong> ${examiner}</div>
                <div><strong>Examinee:</strong> ${examinee}</div>
            </div>
        </div>
        
        <p style="margin: 10px 0;">Total Score: ${totalPoints}/${possiblePoints} points</p>
        
        <div style="margin: 15px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px;">
                <div style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); text-align: center; border: 1px solid #eee;">
                    <div style="font-size: 1.1em; color: #2c3e50; margin-bottom: 8px; font-weight: 500;">Input type</div>
                    <div style="font-weight: bold; font-size: 1.3em; color: #27ae60;">${categoryTotals.input}/${totalQuestions}</div>
                    <div style="color: #7f8c8d; font-size: 0.9em; margin-top: 4px;">(${categoryPercentages.input}%)</div>
                </div>
                <div style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); text-align: center; border: 1px solid #eee;">
                    <div style="font-size: 1.1em; color: #2c3e50; margin-bottom: 8px; font-weight: 500;">List Entry type</div>
                    <div style="font-weight: bold; font-size: 1.3em; color: #2980b9;">${categoryTotals.list}/${totalQuestions}</div>
                    <div style="color: #7f8c8d; font-size: 0.9em; margin-top: 4px;">(${categoryPercentages.list}%)</div>
                </div>
                <div style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); text-align: center; border: 1px solid #eee;">
                    <div style="font-size: 1.1em; color: #2c3e50; margin-bottom: 8px; font-weight: 500;">Rationale</div>
                    <div style="font-weight: bold; font-size: 1.3em; color: #8e44ad;">${categoryTotals.rationale}/${totalQuestions}</div>
                    <div style="color: #7f8c8d; font-size: 0.9em; margin-top: 4px;">(${categoryPercentages.rationale}%)</div>
                </div>
                <div style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); text-align: center; border: 1px solid #eee;">
                    <div style="font-size: 1.1em; color: #2c3e50; margin-bottom: 8px; font-weight: 500;">Disposition</div>
                    <div style="font-weight: bold; font-size: 1.3em; color: #e67e22;">${categoryTotals.disposition}/${totalQuestions}</div>
                    <div style="color: #7f8c8d; font-size: 0.9em; margin-top: 4px;">(${categoryPercentages.disposition}%)</div>
                </div>
            </div>
        </div>
    </div>
    <table style="width: 100%; border-collapse: collapse;"><thead>
    <tr style="background-color: #f2f2f2;">
        <th style="padding: 8px; border: 1px solid #ddd;">Question # and ID</th>
        <th style="padding: 8px; border: 1px solid #ddd;">Input type</th>
        <th style="padding: 8px; border: 1px solid #ddd;">List Entry type</th>
        <th style="padding: 8px; border: 1px solid #ddd;">Rationale</th>
        <th style="padding: 8px; border: 1px solid #ddd;">Disposition</th>
        <th style="padding: 8px; border: 1px solid #ddd;">Mishandle</th>
        <th style="padding: 8px; border: 1px solid #ddd;">Points</th>
    </tr></thead><tbody>
    `;

    results.forEach((result, index) => {
        const questionId = state ? state.questionIDs[index] : 'N/A';
        const comment = comments[index] || 'N/A';

        html += `
            <tr>
                <td style="padding: 8px; border: 1px solid #ddd;">${result.question}, ID: ${questionId}</td>
                <td style="padding: 8px; border: 1px solid #ddd; text-align: center; color: ${result.inputType ? 'inherit' : '#dc3545'}">${result.inputType ? '✓' : '✗'}</td>
                <td style="padding: 8px; border: 1px solid #ddd; text-align: center; color: ${result.listEntry ? 'inherit' : '#dc3545'}">${result.listEntry ? '✓' : '✗'}</td>
                <td style="padding: 8px; border: 1px solid #ddd; text-align: center; color: ${result.rationale ? 'inherit' : '#dc3545'}">${result.rationale ? '✓' : '✗'}</td>
                <td style="padding: 8px; border: 1px solid #ddd; text-align: center; color: ${result.disposition ? 'inherit' : '#dc3545'}">${result.disposition ? '✓' : '✗'}</td>				
                <td style="padding: 8px; border: 1px solid #ddd; text-align: center; color: ${result.mishandle ? '#dc3545' : '#28a745'}">${result.mishandle ? '✓' : '✗'}</td>
                <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${result.points}/4</td>
            </tr>
            <tr><td colspan="7" style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa;"><strong>Comments:</strong> ${comment}</td></tr>
        `;
    });

    html += `</tbody></table>`;
    content.innerHTML = html;
    modal.style.display = 'block';
    modal.querySelector('.close').onclick = () => modal.style.display = 'none';
    window.onclick = (event) => { if (event.target === modal) modal.style.display = 'none'; };
    
    const printBtn = document.getElementById('print-results-btn');
    if (printBtn) {
        printBtn.style.display = isHistorical ? 'none' : 'inline-block';
    }
}

async function createAssessTab(examDetail, questionIDs) {
    const formatDate = (timestamp) => {
      if (!timestamp) return 'Unknown Date';
      try {
        if (typeof timestamp === 'string' && timestamp.includes('.')) {
          const [datePart, timePart] = timestamp.split(' ');
          const [day, month, year] = datePart.split('.').map(Number);
          return `${day.toString().padStart(2, '0')}.${month.toString().padStart(2, '0')}.${year.toString().slice(-2)}`;
        } else {
          const date = new Date(timestamp);
          return isNaN(date) ? 'Unknown Date' : 
            `${date.getDate().toString().padStart(2, '0')}.${(date.getMonth()+1).toString().padStart(2, '0')}.${(date.getFullYear() % 100).toString().padStart(2, '0')}`;
        }
      } catch {
        return 'Unknown Date';
      }
    };

    const examinee = examDetail.Examinee || 'Unknown Examinee';
    const date = formatDate(examDetail.Timestamp);
    const tabName = `${examinee} | ${date}`;
    const sanitizedTabName = tabName.replace(/[^a-z0-9]/gi, '-').toLowerCase();
    const uniqueTabId = `${sanitizedTabName}-${Date.now()}`;

    const pageNumbers = questionIDs.map(id => {
        const index = metadataStore.findIndex(meta => meta.id === id);
        return index !== -1 ? index + 1 : null;
    }).filter(page => page !== null);

    window.assessmentTabStates[uniqueTabId] = {
        examDetail: examDetail,
        questionIDs: questionIDs,
        pageNumbers: pageNumbers,
        currentQuestionIndex: 0,
		popOutWindow: null,
        assessmentData: questionIDs.reduce((acc, id) => {
            acc[id] = { inputType: false, listEntry: false, rationale: false, disposition: false, mishandle: false, isChecked: false, comment: window.unsavedAnswers[id] || '' };
            return acc;
        }, {})
    };
	
    try {
        const response = await fetch(`/get-exam-response?examId=${examDetail.ExamID}`);
        if (response.ok) {
            const savedData = await response.json();
            // Check if the server returned a non-empty object with our string
            if (savedData && savedData.ResponseString) {
                const parsedResponse = JSON.parse(savedData.ResponseString);
                window.assessmentTabStates[uniqueTabId].examineeResponses = parsedResponse.answers;
            }
        }
    } catch (error) {
        console.error("Could not fetch saved examinee response:", error);
    }

    const tabButton = document.createElement('button');
    tabButton.className = 'tab-button';
    tabButton.innerHTML = `${tabName}<span class="close-tab" onclick="removeTab('${uniqueTabId}')">×</span>`;
    tabButton.dataset.tab = uniqueTabId;

    const tabContent = document.createElement('div');
    tabContent.id = `${uniqueTabId}-tab`;
    tabContent.className = 'content-tab assess-tab';

    const viewerContainer = document.createElement('div');
    viewerContainer.className = 'viewer-container';
    viewerContainer.style.cssText = 'background-color: #fff; padding: 20px; border: 1px solid #ccc; box-shadow: 0 2px 5px rgba(0,0,0,0.1);';

    const statusDiv = document.createElement('div');
    statusDiv.id = `status-${uniqueTabId}`;
    statusDiv.className = 'assessment-status';

    const docxContainer = document.createElement('div');
    docxContainer.className = 'docx-container';
    docxContainer.style.cssText = 'background-color: #fff; min-height: 400px; line-height: 1.6;';
    
    // *** START: SIMPLIFIED PAGINATION ***
    const footer = document.createElement('div');
    footer.className = 'assessment-footer';
    const paginationControls = document.createElement('div');
    paginationControls.className = 'pagination-controls';

    const state = window.assessmentTabStates[uniqueTabId];

    pageNumbers.forEach((pn, index) => {
        const btn = document.createElement('button');
        btn.className = 'page-jump-btn';
        btn.textContent = index + 1;
        btn.onclick = () => {
            state.currentQuestionIndex = index;
            renderAssessmentQuestion(uniqueTabId);
        };
        paginationControls.appendChild(btn);
    });
    // *** END: SIMPLIFIED PAGINATION ***

    const resultsBtn = document.createElement('button');
    resultsBtn.className = 'results-btn';
    resultsBtn.textContent = 'Results';
    resultsBtn.onclick = () => checkAllAssessmentsComplete(examDetail, uniqueTabId);
	
    const loadResponseBtn = document.createElement('button');
    loadResponseBtn.className = 'load-response-btn';
    loadResponseBtn.textContent = 'Load Response';
    loadResponseBtn.onclick = () => handleLoadExamineeResponse(uniqueTabId);
	
	const popOutBtn = document.createElement('button');
    popOutBtn.className = 'pop-out-btn';
    popOutBtn.textContent = 'Pop-out';
    popOutBtn.onclick = () => handlePopOut(uniqueTabId);
    
    footer.append(paginationControls, popOutBtn, loadResponseBtn, resultsBtn);
    
    docxContainer.append(statusDiv);
    viewerContainer.append(docxContainer);
    tabContent.append(viewerContainer, footer);
    
    viewerContainer.addEventListener('wheel', (event) => {
        if (!event.shiftKey) return;
        event.preventDefault();
        const state = window.assessmentTabStates[uniqueTabId];
        if (isThrottled || !state) return;
        isThrottled = true;
        setTimeout(() => { isThrottled = false; }, 300);

        if (event.deltaY > 0 && state.currentQuestionIndex < state.pageNumbers.length - 1) {
            state.currentQuestionIndex++;
            renderAssessmentQuestion(uniqueTabId);
        } else if (event.deltaY < 0 && state.currentQuestionIndex > 0) {
            state.currentQuestionIndex--;
            renderAssessmentQuestion(uniqueTabId);
        }
    });

    const tabsContainer = document.getElementById('tabs');
    const mainContentArea = document.querySelector('#alerts-tab').parentNode;
    tabsContainer.appendChild(tabButton);
    mainContentArea.appendChild(tabContent);

    document.querySelectorAll('.tab-button').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.content-tab').forEach(t => t.style.display = 'none');
    tabButton.classList.add('active');
    tabContent.style.display = 'block';

    renderAssessmentQuestion(uniqueTabId);
}

function renderAssessmentQuestion(tabId) {
    const state = window.assessmentTabStates[tabId];
    if (!state) return;

    const { currentQuestionIndex, pageNumbers, questionIDs, assessmentData } = state;
    const pageNumber = pageNumbers[currentQuestionIndex];
    const questionId = questionIDs[currentQuestionIndex];

    // <<< FIX 1: Get the alert data directly from the metadataStore using the ID >>>
    const alertData = window.metadataStore.find(meta => meta.id === questionId);

    const docxContainer = document.querySelector(`#${tabId}-tab .docx-container`);
    if (!docxContainer) return;
    
    const statusDiv = docxContainer.querySelector(`#status-${tabId}`);
    docxContainer.innerHTML = ''; 
    if (statusDiv) docxContainer.appendChild(statusDiv);

    // Safety check if an alert from an old exam was deleted from the main alerts.json
    if (!alertData) {
        docxContainer.innerHTML += `<p style="color: red; padding: 20px;">Error: Could not find content for Alert ID: ${questionId}. It may have been deleted.</p>`;
        return;
    }

    // <<< FIX 2: Dynamically build the question and answer sections >>>
    // Create the main question container
    const sectionClone = document.createElement('section');
    sectionClone.className = 'docx';
    sectionClone.style.position = 'relative';
    // Create the article for the alert's content
    const questionArticle = document.createElement('article');
    questionArticle.innerHTML = alertData.content;

    // Create the container for the saved answer/rationale
    const answerContainer = document.createElement('div');
    answerContainer.className = 'answer-container';
    answerContainer.style.display = 'none'; // Initially hidden
    const savedAnswerHtml = window.unsavedAnswers[questionId] 
        ? window.unsavedAnswers[questionId] 
        : '<p><i>No rationale was saved for this alert.</i></p>';
    answerContainer.innerHTML = `<h4 style="margin-top:0;">Correct Rationale</h4><div>${savedAnswerHtml}</div>`;
    
    sectionClone.appendChild(questionArticle);
    // --- End of new dynamic build section
    
    // The assessment controls logic below this point is mostly correct and can remain.
    // We are just replacing how the question content is generated.

    const assessmentControls = document.createElement('div');
    assessmentControls.className = 'assessment-controls';
    assessmentControls.style.display = 'block';

    const checkboxGrid = document.createElement('div');
    checkboxGrid.style.cssText = `display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 10px; margin-bottom: 15px;`;
    const controlIdPrefix = `${tabId}-q${currentQuestionIndex}`;

    ['Input Type', 'List Entry', 'Rationale', 'Disposition', 'Mishandle'].forEach(label => {
        const camelCaseKey = label.split(' ').map((word, index) => 
            index === 0 ? word.toLowerCase() : word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
        ).join('');
        
        const labelId = label.toLowerCase().replace(' ', '-');
        
        const controlGroup = document.createElement('div');
        controlGroup.className = 'control-group';
        const switchContainer = document.createElement('label');
        switchContainer.className = 'switch';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = `${controlIdPrefix}-${labelId}`;
        checkbox.checked = state.assessmentData[questionId]?.[camelCaseKey] || false;
        checkbox.disabled = state.isFinalized || false;

        checkbox.onchange = (e) => {
            state.assessmentData[questionId][camelCaseKey] = e.target.checked;

            if (e.target.checked && (label === 'Rationale' || label === 'Mishandle')) {
                const otherLabel = label === 'Rationale' ? 'mishandle' : 'rationale';
                const otherCheckbox = document.getElementById(`${controlIdPrefix}-${otherLabel}`);
                
                if (otherCheckbox && otherCheckbox.checked) {
                    otherCheckbox.checked = false;
                    otherCheckbox.dispatchEvent(new Event('change')); 
                }
            }
        };

        const slider = document.createElement('span');
        slider.className = 'slider';
        if (label === 'Mishandle') slider.classList.add('slider-mishandle');
        const labelElement = document.createElement('span');
        labelElement.className = 'control-label';
        labelElement.textContent = label;

        switchContainer.append(checkbox, slider);
        controlGroup.append(switchContainer, labelElement);
        checkboxGrid.appendChild(controlGroup);
    });

    const commentContainer = document.createElement('div');
    const commentLabel = document.createElement('label');
    commentLabel.textContent = 'Comments:';
    commentLabel.className = 'comment-label';
    const commentTextarea = document.createElement('textarea');
    commentTextarea.className = 'assessment-comments';
    commentTextarea.value = state.assessmentData[questionId]?.comment || '';
    commentTextarea.oninput = (e) => state.assessmentData[questionId].comment = e.target.value;
    commentTextarea.disabled = state.isFinalized || false;
    commentContainer.append(commentLabel, commentTextarea);
    
    const checkedControlGroup = document.createElement('div');
    checkedControlGroup.className = 'control-group';
    checkedControlGroup.style.cssText = 'margin-top: 15px; padding-top: 15px; border-top: 1px solid #eee;';
    const checkedSwitchContainer = document.createElement('label');
    checkedSwitchContainer.className = 'switch';
    const checkedCheckbox = document.createElement('input');
    checkedCheckbox.type = 'checkbox';
    checkedCheckbox.checked = state.assessmentData[questionId]?.isChecked || false;
    checkedCheckbox.disabled = state.isFinalized || false;
    checkedCheckbox.onchange = (e) => state.assessmentData[questionId].isChecked = e.target.checked;
    const checkedSlider = document.createElement('span');
    checkedSlider.className = 'slider';
    const checkedLabel = document.createElement('span');
    checkedLabel.className = 'control-label';
    checkedLabel.textContent = 'Checked';
    checkedLabel.style.marginLeft = '10px';
    checkedSwitchContainer.append(checkedCheckbox, checkedSlider);
    checkedControlGroup.append(checkedSwitchContainer, checkedLabel);
    
    assessmentControls.append(checkboxGrid, commentContainer, checkedControlGroup);
    
    const placeholderWrapper = sectionClone.querySelector('.page-btn')?.parentNode;
    const buttonGroup = document.createElement('div');
    buttonGroup.style.cssText = `position: absolute; top: 10px; left: 10px; z-index: 900; display: flex; gap: 6px; align-items: center;`;

	const showBtn = document.createElement('button');
	showBtn.className = 'show-btn';
	showBtn.style.cssText = `padding: 4px 8px; min-width: 60px; color: white; border: none; border-radius: 4px; cursor: pointer;`;

	// --- NEW LOGIC: Check for an active pop-out window ---
	// We check if the popOutWindow object exists for this tab AND if the user hasn't closed it.
	const isPopOutActive = state.popOutWindow && !state.popOutWindow.closed;

	if (isPopOutActive) {
		// If pop-out is active, hide the article in the main tab by default.
		questionArticle.style.display = 'none';
		showBtn.textContent = 'Show';
		showBtn.style.backgroundColor = '#007bff';
	} else {
		// Otherwise, show the article in the main tab by default.
		questionArticle.style.display = 'block';
		showBtn.textContent = 'Hide';
		showBtn.style.backgroundColor = '#6c757d';
	}

	// The onclick handler now correctly toggles from the initial state we just set.
	showBtn.onclick = () => {
		const isVisible = questionArticle.style.display !== 'none';
		questionArticle.style.display = isVisible ? 'none' : 'block';
		showBtn.textContent = isVisible ? 'Show' : 'Hide';
		showBtn.style.backgroundColor = isVisible ? '#007bff' : '#6c757d';
	};

    const gradeBtn = document.createElement('button');
    gradeBtn.className = 'grade-btn';
    gradeBtn.textContent = 'Hide';
    gradeBtn.style.cssText = `padding: 4px 8px; min-width: 60px; background-color: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer;`;
    gradeBtn.onclick = () => {
        const isVisible = assessmentControls.style.display === 'block';
        assessmentControls.style.display = isVisible ? 'none' : 'block';
        gradeBtn.textContent = isVisible ? 'Grade' : 'Hide';
        gradeBtn.style.backgroundColor = isVisible ? '#17a2b8' : '#6c757d';
    };

    const metaSpan = document.createElement('span');
    metaSpan.style.cssText = `font-size: 0.9em; color: #666; margin-left: 10px; vertical-align: middle;`;
    // <<< FIX 3: Use the robust alertData object for metadata >>>
    const questionMeta = alertData;
    metaSpan.textContent = `#${currentQuestionIndex + 1} [${questionMeta.category} | ${questionMeta.difficulty} | ID: ${questionMeta.id}]`;

    buttonGroup.append(showBtn, gradeBtn, metaSpan);
    // Prepend the new button group to the question section
    sectionClone.prepend(buttonGroup);
    
    const answerBtn = document.createElement('button');
    answerBtn.className = 'answer-btn';
    answerBtn.textContent = 'Answer';
    answerBtn.style.cssText = `position: absolute; top: 10px; right: 10px; padding: 4px 8px; min-width: 60px; background-color: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; z-index: 900;`;
    sectionClone.appendChild(answerBtn);

    if (answerBtn && answerContainer) {
        answerBtn.onclick = () => {
            const isVisible = answerContainer.style.display === 'block';
            answerContainer.style.display = isVisible ? 'none' : 'block';
            answerBtn.textContent = isVisible ? 'Answer' : 'Hide';
            answerBtn.style.backgroundColor = isVisible ? '#007bff' : '#6c757d';
        };
    }
    
    // Located at the end of the renderAssessmentQuestion function

    docxContainer.append(sectionClone, answerContainer);

    // START MODIFICATION
    // Check for and render the loaded examinee response
    if (state.examineeResponses) {
        const questionId = questionIDs[currentQuestionIndex];
        const examineeAnswer = state.examineeResponses[questionId];

        const examineeResponseContainer = document.createElement('div');
        examineeResponseContainer.className = 'examinee-response-container';

        if (examineeAnswer) {
            examineeResponseContainer.innerHTML = `
                <h4>Examinee's Response</h4>
                <div class="response-grid">
                    <div><strong>Input Type:</strong> ${examineeAnswer.inputType || 'N/A'}</div>
                    <div><strong>List Entry:</strong> ${examineeAnswer.listEntryType || 'N/A'}</div>
                    <div><strong>Disposition:</strong> ${examineeAnswer.disposition || 'N/A'}</div>
                </div>
                <div class="response-rationale">
                    <strong>Rationale:</strong>
                    <pre>${examineeAnswer.rationale || 'No rationale provided.'}</pre>
                </div>
            `;
        } else {
            examineeResponseContainer.innerHTML = `<h4>Examinee's Response</h4><p>No response was recorded for this specific alert.</p>`;
        }
        docxContainer.appendChild(examineeResponseContainer);
    }
    // END MODIFICATION

    docxContainer.appendChild(assessmentControls);
    
    if (statusDiv) {
        if (state.isFinalized) {
            statusDiv.innerHTML = `Assessed alert ${currentQuestionIndex + 1} of ${pageNumbers.length} <span class="status-badge finalized">Read-only</span>`;
        } else {
            statusDiv.textContent = `Assessing alert ${currentQuestionIndex + 1} of ${pageNumbers.length}`;
        }
    }

    const footer = document.querySelector(`#${tabId}-tab .assessment-footer`);
    if (footer) {
        const numberButtons = footer.querySelectorAll('.page-jump-btn');
        numberButtons.forEach((btn, index) => {
            const qIdForBtn = questionIDs[index];
            const isChecked = state.assessmentData[qIdForBtn]?.isChecked || false;
            
            btn.classList.toggle('active', index === currentQuestionIndex);
            btn.classList.toggle('checked', isChecked);
        });
    }
	updatePopOutContent(tabId);
}

function disableAssessmentTab(tabId) {
    const tabContent = document.getElementById(`${tabId}-tab`);
    if (!tabContent) return;

    // Disable only assessment controls (toggles and text boxes)
    const controls = tabContent.querySelectorAll('input[type="checkbox"], textarea');
    controls.forEach(control => {
        control.disabled = true;
        control.style.opacity = '0.7';
        control.style.cursor = 'not-allowed';
    });

    // Update the status div to show a finalized badge
	const statusDiv = tabContent.querySelector(`#status-${tabId}`);
	const state = window.assessmentTabStates[tabId];

	if (statusDiv && state) {
        // Get the current question details from the state object
        const { currentQuestionIndex, pageNumbers } = state;
		// Construct and set the full, correct status message, replacing the old one
		statusDiv.innerHTML = `Assessed question ${currentQuestionIndex + 1} of ${pageNumbers.length} <span class="status-badge finalized">Read-only</span>`;
	}
}

window.removeTab = function(tabId) {
  // Find the tab button to check if it's an assessment tab
  const tabButton = document.querySelector(`.tab-button[data-tab="${tabId}"]`);
  if (!tabButton) return;

  // Check if this is an assessment tab (contains "assess" in the class)
  const tabContent = document.getElementById(`${tabId}-tab`);
  const isAssessmentTab = tabContent && tabContent.classList.contains('assess-tab');

  if (isAssessmentTab) {
    // Show confirmation dialog for assessment tabs
    const confirmClose = confirm("Are you sure you want to close this assessment? Any unsaved changes will be lost.");
    if (!confirmClose) return;
  }

  if (window.assessmentTabStates && window.assessmentTabStates[tabId]) {
    const state = window.assessmentTabStates[tabId];
    if (state.popOutInterval) {
        clearInterval(state.popOutInterval);
    }
    if (state.popOutWindow && !state.popOutWindow.closed) {
        state.popOutWindow.close(); // Also close the pop-out if the main tab is closed
    }
	delete window.assessmentTabStates[tabId];
  }

  const wasActive = tabButton.classList.contains('active');
  tabButton.remove();

  if (tabContent) tabContent.remove();

  if (wasActive) {
    // 1. Always check for alerts tab first
    const alertsTab = document.querySelector('.tab-button[data-tab="alerts"]');
    const alertsContent = document.getElementById('alerts-tab');
    
    if (alertsTab && alertsContent) {
      // Remove active class from all tabs
      document.querySelectorAll('.tab-button').forEach(b => b.classList.remove('active'));
      // Hide all content tabs
      document.querySelectorAll('.content-tab').forEach(t => t.style.display = 'none');
      
      // Activate alerts tab
      alertsTab.classList.add('active');
      alertsContent.style.display = 'block';
    }
    else {
      // 2. Fallback with null checks
      const firstRemainingTab = document.querySelector('.tab-button');
      const firstContent = document.getElementById(
        firstRemainingTab?.dataset?.tab ? 
        `${firstRemainingTab.dataset.tab}-tab` : 
        null
      );

      if (firstRemainingTab && firstContent) {
        document.querySelectorAll('.tab-button').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.content-tab').forEach(t => t.style.display = 'none');
        
        firstRemainingTab.classList.add('active');
        firstContent.style.display = 'block';
      }
    }
  }
};

function checkAllAssessmentsComplete(currentExamDetail, tabId) {
    const state = window.assessmentTabStates[tabId];
    if (!state) return;

    const isFinalized = state.isFinalized || false;
    const uncheckedSections = [];
    
    // Check if all questions have been marked as "Checked"
    for(let i = 0; i < state.questionIDs.length; i++) {
        const qId = state.questionIDs[i];
        if (!state.assessmentData[qId].isChecked) {
            uncheckedSections.push(i + 1);
        }
    }

    if (!isFinalized && uncheckedSections.length > 0) {
        alert(`The following questions need to be marked as checked: ${uncheckedSections.join(', ')}`);
        return;
    }

    // Calculate results from state object
    let totalPoints = 0;
    let hasMishandle = false;
    const results = state.questionIDs.map((qId, index) => {
        const data = state.assessmentData[qId];
        const points = (data.inputType ? 1 : 0) + (data.listEntry ? 1 : 0) + (data.rationale ? 1 : 0) + (data.disposition ? 1 : 0);
        totalPoints += points;
        if (data.mishandle) hasMishandle = true;
        
        return {
            question: index + 1,
            inputType: data.inputType,
            listEntry: data.listEntry,
            rationale: data.rationale,
            disposition: data.disposition,
            mishandle: data.mishandle,
            points: points
        };
    });

    const possiblePoints = state.questionIDs.length * 4;
    const percentage = possiblePoints > 0 ? Math.round((totalPoints / possiblePoints) * 100) : 0;
    const passed = !hasMishandle && percentage >= 80;

    showResultsModal(results, totalPoints, possiblePoints, percentage, passed, hasMishandle, currentExamDetail, tabId, isFinalized);
}

    let filtersInitialized = false;
	let selectedPages = new Set();
	let selectedAlertIDs = new Set();
	let openAnswerBoxes = new Set();
	const selectedStatusSpan = document.getElementById('selected-status');
	function updateSelectedCount() {
	selectedStatusSpan.textContent = `${selectedAlertIDs.size} alerts selected`;
	}

async function initializeApplication() {
  try {
    statusDiv.firstElementChild.innerHTML = `
      <div style="display: flex; align-items: center; gap: 10px;">
        <img src="icons/loading.svg" class="loading-spinner" style="width: 40px; height: 40px;" alt="Loading">
        <div style="color: #555;">Loading alerts...</div>
      </div>
    `;
    
	const response = await fetch('/list-alerts');
	if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

	// 1. Read the response as plain text first
	let responseText = await response.text();

	// 2. Check for and remove the BOM character if it exists at the start of the text
	if (responseText.charCodeAt(0) === 0xFEFF) {
		responseText = responseText.substring(1);
	}

	// 3. Manually parse the cleaned text into JSON
	const alertsData = JSON.parse(responseText);
    
    // Sort by most recently updated
    alertsData.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    window.metadataStore = alertsData; // The unified store now holds all alerts

    await loadSavedAnswers();
    initializeQuestionViewer();

  } catch (err) {
    statusDiv.textContent = `Error initializing application: ${err.message}`;
    console.error(err);
  }
}
window.addEventListener('load', initializeApplication);

// In script.js

// REPLACE the entire existing 'docxContainer.addEventListener' with this corrected version:
docxContainer.addEventListener('click', (e) => {
    // --- Save button logic remains the same, it doesn't need 'itemData' ---
    if (e.target.closest('.save-answer-btn')) {
        const saveBtn = e.target.closest('.save-answer-btn');
        handleSaveAnswer(saveBtn);
        return;
    }

    // <<< FIX STARTS HERE: Define itemData using the global state >>>
    // Get the data for the currently displayed question from our global state variables.
    const itemData = window.filteredMetadata[currentQuestionIndex];
    // If for some reason there's no item (e.g., empty filter), do nothing.
    if (!itemData) {
        return;
    }
    // <<< FIX ENDS HERE >>>

    // The rest of the logic now works because `itemData` is defined.

    const pageElement = e.target.closest('section.docx');
    // If the click wasn't inside the main question section, exit.
    if (!pageElement) return;

    const pageNumber = parseInt(pageElement.dataset.page, 10);

    // Handle 'Add'/'Remove' buttons
    if (e.target.closest('.add-question-btn')) {
        selectedAlertIDs.add(itemData.id); // This will now work
        updateSelectedCount();
        updateButtonStates();
        return;
    }
    if (e.target.closest('.remove-question-btn')) {
        selectedAlertIDs.delete(itemData.id); // This will now work
        updateSelectedCount();
        updateButtonStates();
        return;
    }

    // Handle 'Edit' button
    if (e.target.closest('.edit-alert-btn')) {
        window.showEditAlertEditor(itemData);
        return;
    }

    // Handle 'Answer' button
    if (e.target.closest('.answer-btn')) {
        const answerContainer = pageElement.nextElementSibling;
        if (answerContainer?.classList.contains('answer-container')) {
            // Toggle the state and re-render to apply changes
            openAnswerBoxes.has(pageNumber) ? openAnswerBoxes.delete(pageNumber) : openAnswerBoxes.add(pageNumber);
            renderCurrentQuestion();
        }
        return;
    }
});

// FIX: New listener to track user input in textareas
docxContainer.addEventListener('input', (e) => {
    const textarea = e.target;
    if (textarea.classList.contains('answer-textarea')) {
        const questionId = textarea.dataset.questionId;
        // Update our state object as the user types
        window.unsavedAnswers[questionId] = textarea.value;
    }
});


async function handleSaveAnswer(saveBtn) {
    const questionId = saveBtn.dataset.questionId;
    const answerContainer = saveBtn.closest('.answer-container');
    const spinner = answerContainer.querySelector('.save-spinner');
    const textarea = answerContainer.querySelector('.answer-textarea');
    const originalButtonText = saveBtn.textContent;

    try {
        saveBtn.disabled = true;
        spinner.style.display = 'inline-block';

        const response = await fetch('/save-answer', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                questionId: questionId,
                answerText: textarea.value
            })
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(errorText || 'Failed to save answer');
        }
        
        spinner.style.display = 'none';
        saveBtn.textContent = 'Done';
        
        setTimeout(() => {
            saveBtn.textContent = originalButtonText;
            saveBtn.disabled = false;
        }, 1500);

    } catch (err) {
        console.error('Save error:', err);
        alert('Error saving answer: ' + err.message);
        spinner.style.display = 'none';
        saveBtn.textContent = originalButtonText;
        saveBtn.disabled = false;
    }
}

function initializeQuestionViewer() {
  docxContainer.innerHTML = ''; // Clear the container

  // Initially, filtered data is all data
  window.filteredMetadata = metadataStore.map((meta, index) => ({ ...meta, originalIndex: index }));
  
  // Set up filters (now that metadata is ready)
  if (!filtersInitialized) {
    setupFilters();
    filtersInitialized = true;
  }
  
  // Set up the WHEEL listener for swapping questions
  viewerContainer.addEventListener('wheel', handleQuestionSwap);

  // Perform the initial render of the first question
  renderCurrentQuestion();
  
  statusDiv.firstElementChild.textContent = 'Alerts ready. Use filters above or scroll to navigate questions.';
}

function renderCurrentQuestion() {
  docxContainer.innerHTML = '';
  if (!window.filteredMetadata || window.filteredMetadata.length === 0) {
      docxContainer.innerHTML = '<p>No items match the current filter.</p>';
      updateFilteredPageCount();
      return;
  }
  const itemData = window.filteredMetadata[currentQuestionIndex];
  if (!itemData) return;

  const pageNumber = window.metadataStore.findIndex(q => q.id === itemData.id) + 1;
  
  const pageElement = document.createElement('section');
  pageElement.className = 'docx'; // Re-use class for styling
  pageElement.dataset.page = pageNumber;
  pageElement.innerHTML = `<article>${itemData.content}</article>`;
  
  const buttonWrapper = document.createElement('div');
  buttonWrapper.style.cssText = `position: absolute; top: 10px; left: 10px; z-index: 999; display: flex; gap: 6px; align-items: center;`;
	buttonWrapper.innerHTML = `
		<button class="page-btn add-question-btn" style="padding: 4px 8px; background-color: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer;">Add</button>
		<button class="page-btn remove-question-btn" style="padding: 4px 8px; background-color: #dc3545; color: white; border: none; border-radius: 4px; cursor: pointer; display: none;">Remove</button>
		<button class="page-btn edit-alert-btn" style="padding: 4px 8px; background-color: rgb(23, 162, 184); color: white; border: none; border-radius: 4px; cursor: pointer;">Edit</button>
		<span class="question-meta-span" style="font-size: 0.9em; color: #666; margin-left: 10px; vertical-align: middle;">[${itemData.category} | ${itemData.difficulty} | ${itemData.id} | ${itemData.user || 'N/A'} | ${itemData.date || 'N/A'}]</span>
	`;

  const answerBtn = document.createElement('button');
  answerBtn.textContent = 'Answer';
  answerBtn.className = 'page-btn answer-btn';
  answerBtn.style.cssText = `position: absolute; top: 10px; right: 10px; padding: 4px 8px; min-width: 60px; background-color: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; z-index: 900;`;
  
  pageElement.style.position = 'relative';
  pageElement.prepend(buttonWrapper);
  pageElement.appendChild(answerBtn);
  
  const answerContainer = createAnswerContainer(pageElement);
  const isVisible = openAnswerBoxes.has(pageNumber);
  answerContainer.style.display = isVisible ? 'block' : 'none';
  answerBtn.textContent = isVisible ? 'Hide' : 'Answer';
  
  const textarea = answerContainer.querySelector('.answer-textarea');
  if (textarea) textarea.value = window.unsavedAnswers[itemData.id] || '';

  docxContainer.append(pageElement, answerContainer);
  updateFilteredPageCount();
  updateButtonStates();
}

// ADD THIS NEW FUNCTION
function handleQuestionSwap(event) {
  if (!event.shiftKey) return;
  event.preventDefault();

  if (isThrottled) return;
  isThrottled = true;

  // --- NEW: Close the answer box of the current question before swapping ---
  const currentItemData = window.filteredMetadata[currentQuestionIndex];
  if (currentItemData) {
      const originalIndexOfCurrent = currentItemData.originalIndex;
      const pageNumberOfCurrent = originalIndexOfCurrent + 1;
      // If the current question's answer is open, remove it from the set.
      if (openAnswerBoxes.has(pageNumberOfCurrent)) {
          openAnswerBoxes.delete(pageNumberOfCurrent);
      }
  }
  // --- END OF NEW CODE ---

  setTimeout(() => { isThrottled = false; }, 300);

  const numFiltered = window.filteredMetadata.length;
  if (numFiltered <= 1) return;

  if (event.deltaY > 0) {
    if (currentQuestionIndex < numFiltered - 1) {
      currentQuestionIndex++;
      renderCurrentQuestion();
    }
  } else {
    if (currentQuestionIndex > 0) {
      currentQuestionIndex--;
      renderCurrentQuestion();
    }
  }
}

// Create rationale container
function createAnswerContainer(page) {
    const answerContainer = document.createElement('div');
    answerContainer.className = 'answer-container';
    
    const pageNumber = parseInt(page.dataset.page, 10);
    const questionId = metadataStore[pageNumber - 1].id;

    const textarea = document.createElement('textarea');
    textarea.placeholder = 'Enter your answer here...';
    // Add class and data-attribute for event delegation
    textarea.className = 'answer-textarea';
    textarea.dataset.questionId = questionId;
    
    // Set initial value from our state object
    textarea.value = window.unsavedAnswers[questionId] || '';
  
    textarea.style.cssText = `
      width: 100%; margin-bottom: 10px; padding: 8px; border: 1px solid #ddd;
      border-radius: 4px; min-height: 150px; white-space: pre-wrap;
    `;

    const saveContainer = document.createElement('div');
    saveContainer.style.cssText = 'display: flex; align-items: center; gap: 10px;';

    const saveBtn = document.createElement('button');
    saveBtn.textContent = 'Save';
    // Add class and data-attribute for event delegation
    saveBtn.className = 'save-answer-btn';
    saveBtn.dataset.questionId = questionId;
    saveBtn.style.cssText = `
      padding: 6px 12px; background-color: #28a745; color: white;
      border: none; border-radius: 4px; cursor: pointer;
    `;

    const spinner = document.createElement('img');
    spinner.src = 'icons/loading.svg';
    spinner.className = 'save-spinner';
    spinner.style.display = 'none';
    spinner.style.width = '25px';
    
    // NO event listener here anymore. It will be handled by the parent.

    saveContainer.append(saveBtn, spinner);
    answerContainer.append(textarea, saveContainer);

    return answerContainer;
}

async function loadSavedAnswers() {
  try {
    const response = await fetch('/get-answers');
    if (!response.ok) {
        // Log the actual server error for better debugging
        const errorText = await response.text();
        console.error("Server error fetching answers:", errorText);
        throw new Error('Failed to fetch answers');
    }
    
    const savedAnswers = await response.json();
    if (!Array.isArray(savedAnswers)) {
        console.warn("Received non-array response for answers:", savedAnswers);
        return [];
    }

    // Populate the state object with answers from the server
    savedAnswers.forEach(answer => {
        window.unsavedAnswers[answer.QuestionID] = answer.AnswerText;
    });

    console.log(`Loaded ${savedAnswers.length} saved answers into state.`);
    return savedAnswers; // Still return for the initial render logic if needed

  } catch (err) {
    console.error('Error loading answers:', err);
    // This is a non-critical error for the UI, so we return an empty array.
    return []; 
  }
}

function setupFilters() {
    // Keep the logic for categories, difficulties, and users the same.
    const categories = new Set(metadataStore.map(meta => meta.category).filter(Boolean));
    const difficulties = new Set(metadataStore.map(meta => meta.difficulty).filter(Boolean));
    const users = new Set(metadataStore.map(meta => meta.user).filter(Boolean));

    populateFilter('category-filter', Array.from(categories).sort());
    populateFilter('difficulty-filter', Array.from(difficulties).sort());
    populateFilter('user-filter', Array.from(users).sort());

    // --- NEW, ROBUST DATE SORTING LOGIC ---

    // 1. Get all unique, non-empty date strings from the metadata.
    const dateValues = new Set(metadataStore.map(meta => meta.date).filter(Boolean));

    // 2. Create a helper function to reliably parse "DD.MM.YYYY" strings.
    const parseDateString = (dmyString) => {
        const parts = dmyString.split('.');
        if (parts.length === 3) {
            // new Date(year, monthIndex, day) - month is 0-indexed in JavaScript!
            const [day, month, year] = parts.map(Number);
            return new Date(year, month - 1, day);
        }
        // Fallback for any other potential formats
        return new Date(dmyString);
    };

    // 3. Convert the Set to an Array and sort it using our custom parser.
    const sortedDates = Array.from(dateValues).sort((a, b) => {
        // We sort in descending order (b - a) so the newest dates appear first.
        return parseDateString(b) - parseDateString(a);
    });

    // 4. Populate the filter with the correctly sorted date strings.
    populateFilter('date-filter', sortedDates);
}

    function resetFilters() {
      const pluralMap = {
        category: 'Categories',
        difficulty: 'Difficulties',
        user: 'Users',
        date: 'Dates'
      };

      ['category', 'difficulty', 'user', 'date'].forEach(type => {
        const select = document.getElementById(`${type}-filter`);
        const label = pluralMap[type] || (type.charAt(0).toUpperCase() + type.slice(1) + 's');
        select.innerHTML = `<option value="">All ${label}</option>`;
      });
    }

    function populateFilter(id, values) {
      const select = document.getElementById(id);
      Array.from(values).sort().forEach(value => {
        if (!value) return;
        const option = document.createElement('option');
        option.value = value;
        option.textContent = value;
        select.appendChild(option);
      });
    }

function updateFilteredPageCount() {
  const total = window.filteredMetadata.length;
  if (total === 0) {
    filterStatusDiv.textContent = `0 questions displayed`;
  } else {
    filterStatusDiv.textContent = `Alert ${currentQuestionIndex + 1} of ${total}`;
  }
}

// --- MODIFIED: Filter logic now manipulates data, not DOM ---
applyFiltersBtn.addEventListener('click', () => {
  const filters = {
    category: document.getElementById('category-filter').value,
    difficulty: document.getElementById('difficulty-filter').value,
    user: document.getElementById('user-filter').value,
    date: document.getElementById('date-filter').value
  };

  // Filter the full metadataStore and store the result
  window.filteredMetadata = metadataStore
    .map((meta, index) => ({ ...meta, originalIndex: index })) // Keep track of original index
    .filter(meta => {
      return Object.entries(filters).every(([key, val]) => {
        return !val || meta[key] === val;
      });
    });

  // Reset scroll position and update the virtual view
	currentQuestionIndex = 0;
	renderCurrentQuestion();
});

document.getElementById('view-selected-btn').addEventListener('click', () => {
    // <<< FIX HERE: Filter by checking if the alert's ID is in our selectedAlertIDs set
    window.filteredMetadata = metadataStore
        .map((meta, index) => ({ ...meta, originalIndex: index })) // This map is still useful
        .filter(meta => selectedAlertIDs.has(meta.id));

    // Reset the view to the first selected question
    currentQuestionIndex = 0;
    renderCurrentQuestion();
});

document.getElementById('generate-exam-btn').addEventListener('click', () => {
    if (selectedAlertIDs.size === 0) {
        alert('Please select at least one alert before generating the exam.');
        return;
    }
    showExamDetailsModal();
});

let examDetailsModal = document.getElementById('exam-details-modal');

function showExamDetailsModal() {
    examDetailsModal.style.display = 'block';
}

function closeExamDetailsModal() {
    examDetailsModal.style.display = 'none';
}

document.getElementById('exam-details-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const loadingOverlay = document.getElementById('loading-overlay');
    const generateBtn = document.querySelector('#exam-details-form button[type="submit"]');

    try {
        // Show loading state
        loadingOverlay.style.display = 'flex';
        generateBtn.disabled = true;

        const examiner = document.getElementById('examiner').value.trim();
        const examinee = document.getElementById('examinee').value.trim();
        const expirationDate = document.getElementById('exam-expiration-date').value;
        if (!examiner || !examinee) {
            alert('Please fill in all mandatory fields (Examiner and Examinee)');
            return;
        }

        // Check if we're cloning
		if (window.cloneSource) {
			// We are cloning. We will use the /generate-exam endpoint
			// with the questions from our source exam.

			// 1. Get the alert IDs from the source exam's "Questions" string.
			// This safely handles the comma-separated string format.
			const sourceQuestionIDs = (window.cloneSource.Questions || '')
				.split(',')
				.map(q => q.trim())
				.filter(q => q); // Filter out any empty strings

			if (sourceQuestionIDs.length === 0) {
				throw new Error("The source exam has no questions to clone.");
			}

			// 2. Call the standard '/generate-exam' endpoint with the cloned questions.
			const response = await fetch('/generate-exam', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					alertIDs: sourceQuestionIDs, // Use the questions from the source exam
					examiner: examiner,          // Use the new examiner from the form
					examinee: examinee,          // Use the new examinee from the form
					comment: document.getElementById('exam-comment').value.trim(),
					expirationDate: expirationDate
				})
			});

			if (!response.ok) {
				throw new Error(await response.text());
			}

			// 3. Success! Close the modal and show the updated exam list.
			closeExamDetailsModal();
			showExamModal();
			window.cloneSource = null; // IMPORTANT: Reset the cloning state
        } else {
            // Original generate exam code
            // 1. Create an array from the Set. This preserves the selection order.
            const orderedPages = Array.from(selectedPages);

            // 2. Map over this ORDERED array to get the question IDs in the correct sequence.
            const questionIDs = orderedPages.map(pageNumber => {
                // metadataStore is 0-indexed, page numbers are 1-indexed.
                const meta = metadataStore[pageNumber - 1];
                return meta ? meta.id : 'N/A';
            });

			const response = await fetch('/generate-exam', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					alertIDs: Array.from(selectedAlertIDs),
					examiner: examiner,
					examinee: examinee,
					comment: document.getElementById('exam-comment').value.trim(),
					expirationDate: expirationDate
				})
			});

            if (!response.ok) throw new Error(await response.text());

            closeExamDetailsModal();
            showExamModal();
        }

    } catch (err) {
        console.error('Operation failed:', err);
        alert('Operation failed: ' + err.message);
    } finally {
        // Reset UI state
        loadingOverlay.style.display = 'none';
        generateBtn.disabled = false;
    }
});

// refresh button handler
document.getElementById('refresh-exams').addEventListener('click', refreshExamList);

document.getElementById('view-exams-btn').addEventListener('click', () => {
    showExamModal();
});

document.getElementById('maintenance-btn').addEventListener('click', selectUnansweredQuestions);

async function selectUnansweredQuestions() {
    try {
        // Clear current selection
        selectedPages.clear();
        
        // Get all saved answers with array validation
        const response = await fetch('/get-answers');
        const data = await response.json();
        const answers = Array.isArray(data) ? data : [];

        // Get all pages and their answer containers
        const pages = docxContainer.querySelectorAll('section.docx');
        
        pages.forEach(page => {
            const pageNumber = parseInt(page.dataset.page, 10);
            const questionId = metadataStore[pageNumber - 1].id;
            
            // Check if answer exists for this question
            const hasAnswer = answers.some(answer => answer.QuestionID === questionId);
            
            // Get the answer container
            const answerContainer = page.nextElementSibling;
            
            if (answerContainer?.classList?.contains('answer-container')) {
                const textarea = answerContainer.querySelector('textarea');
                // Select if no answer in storage or textarea is empty
                if (!hasAnswer || textarea.value.trim() === '') {
                    selectedPages.add(pageNumber);
                }
            }
        });

        updateSelectedCount();
        updateButtonStates();
        alert(`Selected ${selectedPages.size} questions without answers`);
        
    } catch (err) {
        console.error('Error selecting unanswered questions:', err);
        alert('Error finding unanswered questions: ' + err.message);
    }
}

// Deselect function
document.getElementById('deselect-btn').addEventListener('click', deselectAllQuestions);

function deselectAllQuestions() {
    selectedAlertIDs.clear();
    updateSelectedCount();
    updateButtonStates();
	document.getElementById('apply-filters-btn').click();
}

// Replace existing tab switching code with this:
document.getElementById('tabs').addEventListener('click', (e) => {
  const button = e.target.closest('.tab-button');
  if (!button) return;

  // Remove active class from all buttons and tabs
  document.querySelectorAll('.tab-button').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.content-tab').forEach(tab => {
    if (tab) tab.style.display = 'none'; // Add null check here
  });

  // Add active class to clicked button and corresponding tab
  button.classList.add('active');
  const tabId = button.dataset.tab;
  
  // Add safety checks for content element
  const contentTab = document.getElementById(`${tabId}-tab`);
  if (contentTab) {
    contentTab.style.display = 'block';
  } else {
    console.error(`Could not find tab content for: ${tabId}`);
    // Fallback to alerts tab if available
    const alertsTab = document.getElementById('alerts-tab');
    if (alertsTab) {
      document.querySelector('.tab-button[data-tab="alerts"]')?.classList.add('active');
      alertsTab.style.display = 'block';
    }
  }
});

async function handleLoadExamineeResponse(tabId) {
    const state = window.assessmentTabStates[tabId];
    if (!state) return;

    const responseString = prompt("Please paste the examinee's full response string:");
    if (!responseString) return;

    try {
        const data = JSON.parse(responseString);
        if (!data.examId || data.examId !== state.examDetail.ExamID) {
            throw new Error(`Exam ID mismatch or invalid format.`);
        }

        // --- START MODIFICATION: Save to server ---
        const saveResponse = await fetch('/save-exam-response', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                examId: state.examDetail.ExamID,
                responseString: responseString
            })
        });

        if (!saveResponse.ok) {
            throw new Error('Failed to save the response to the server.');
        }
        // --- END MODIFICATION ---

        state.examineeResponses = data.answers;
        alert("Examinee response loaded successfully and saved to the server.");
        renderAssessmentQuestion(tabId);

    } catch (error) {
        console.error("Error loading examinee response:", error);
        alert(`Failed to load response: ${error.message}`);
    }
}

function handlePopOut(tabId) {
    const state = window.assessmentTabStates[tabId];
    if (!state) return;

    // --- NEW: Clear any existing checker before creating a new one ---
    if (state.popOutInterval) {
        clearInterval(state.popOutInterval);
    }
    // --- END NEW ---

    const windowFeatures = 'menubar=no,location=no,resizable=yes,scrollbars=yes,status=no,width=800,height=700';

    if (state.popOutWindow && !state.popOutWindow.closed) {
        state.popOutWindow.focus();
    } else {
        state.popOutWindow = window.open('', `popout_${tabId}`, windowFeatures);
        
        state.popOutWindow.document.head.innerHTML = `
            <title>Assessment Viewer</title>
            <style>
                body { font-family: sans-serif; margin: 0; padding: 25px; background-color: #fdfdfd; }
                .docx { border: 1px solid #ccc; padding: 20pt !important; background-color: white; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
                .docx img { max-width: 100%; height: auto; }
            </style>
        `;
        state.popOutWindow.document.body.innerHTML = '<div>Loading question...</div>';

        // --- NEW: Start a checker to see when the window is closed ---
        state.popOutInterval = setInterval(() => {
            if (state.popOutWindow && state.popOutWindow.closed) {
                // The window has been closed by the user.
                clearInterval(state.popOutInterval); // Stop the checker
                state.popOutInterval = null; // Clean up the ID
                
                // Re-render the main tab to show the question content again.
                // We only do this if the current active tab is the one we're checking.
                const activeTabButton = document.querySelector('.tab-button.active');
                if (activeTabButton && activeTabButton.dataset.tab === tabId) {
                   renderAssessmentQuestion(tabId);
                }
            }
        }, 500); // Check every half-second
        // --- END NEW ---
    }

    renderAssessmentQuestion(tabId);
}

function updatePopOutContent(tabId) {
    const state = window.assessmentTabStates[tabId];
    if (!state || !state.popOutWindow || state.popOutWindow.closed) {
        return;
    }

    const questionId = state.questionIDs[state.currentQuestionIndex];
    const alertData = window.metadataStore.find(meta => meta.id === questionId);

    if (alertData) {
        state.popOutWindow.document.body.innerHTML = `<div class="docx">${alertData.content}</div>`;
    } else {
        state.popOutWindow.document.body.innerHTML = `<p>Error: Could not find content for Alert ID: ${questionId}.</p>`;
    }
}

const overrideModal = document.getElementById('override-code-modal');
const closeOverrideModalBtn = document.getElementById('close-override-modal');
const generateCodeBtn = document.getElementById('generate-override-code-btn');
const copyCodeBtn = document.getElementById('copy-override-code-btn');
const codeResultContainer = document.getElementById('override-code-result-container');
const codeResultTextarea = document.getElementById('override-code-result');

// Show the modal when the dropdown option is clicked
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('generate-code-option')) {
        e.preventDefault();
        const examItem = e.target.closest('.exam-item');
        const examId = examItem.dataset.examId;
        
        document.getElementById('override-exam-id').value = examId;
        codeResultContainer.style.display = 'none'; // Hide previous result
        codeResultTextarea.value = '';
        overrideModal.style.display = 'block';

        e.target.closest('.dropdown-menu').classList.remove('show');
    }
});

closeOverrideModalBtn.onclick = () => {
    overrideModal.style.display = 'none';
};

generateCodeBtn.addEventListener('click', async () => {
    const examId = document.getElementById('override-exam-id').value;
    const action = document.getElementById('override-action-select').value;
    const value = parseInt(document.getElementById('override-value-input').value, 10);

    if (!examId || !action || !value || value <= 0) {
        alert('Invalid input. Please ensure all fields are set correctly.');
        return;
    }

    try {
        generateCodeBtn.textContent = 'Generating...';
        generateCodeBtn.disabled = true;

        const response = await fetch('/generate-override-code', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ examId, action, value })
        });

        if (!response.ok) {
            throw new Error('Server failed to generate the code.');
        }

        const result = await response.json();
        codeResultTextarea.value = result.code;
        codeResultContainer.style.display = 'block';

    } catch (error) {
        alert(`Error: ${error.message}`);
    } finally {
        generateCodeBtn.textContent = 'Generate Code';
        generateCodeBtn.disabled = false;
    }
});

copyCodeBtn.addEventListener('click', () => {
    codeResultTextarea.select();
    document.execCommand('copy');
    copyCodeBtn.textContent = 'Copied!';
    setTimeout(() => { copyCodeBtn.textContent = 'Copy to Clipboard'; }, 2000);
});

// Replace the entire existing generateExamPDF function with this one.

// Replace the entire existing generateExamPDF function with this one.

async function generateExamPDF(examDetail) {
    if (examPreviewWindow && !examPreviewWindow.closed) {
        alert("An exam preview is already open. Please close the existing preview window before opening a new one.");
        examPreviewWindow.focus();
        return;
    }

    if (!window.jspdf) {
        alert("PDF generation library jsPDF is not loaded. Please contact support.");
        return;
    }

    const questionIDs = (examDetail.Questions || '').split(',').map(id => id.trim()).filter(Boolean);
    if (questionIDs.length === 0) {
        alert("This exam contains no questions to print.");
        return;
    }

    examPreviewWindow = window.open('', 'examPreviewWindow', 'width=1200,height=800,resizable=yes,scrollbars=yes');
    if (!examPreviewWindow) {
        alert("Could not open a new tab. Please check your browser's pop-up blocker settings.");
        examPreviewWindow = null;
        return;
    }
    
    const controller = new AbortController();

    examPreviewWindow.onbeforeunload = () => {
        controller.abort();
        examPreviewWindow = null;
    };

    try {
        examPreviewWindow.document.write('<!DOCTYPE html><html><head><title>Loading Exam...</title></head><body><p>Please wait, preparing your exam preview...</p></body></html>');
        const headContent = `
            <meta charset="UTF-8">
            <title>Exam Preview - ${examDetail.Examinee || 'N/A'}</title>
            <style>
                body { font-family: 'DejaVuSans', sans-serif; line-height: 1.6; color: #333; background-color: #f0f0f0; margin: 0; padding-top: 80px; }
                
                /* --- MODIFICATION START --- */
                .print-controls { 
                    position: fixed; top: 0; left: 0; width: 100%; box-sizing: border-box; /* Added box-sizing */
                    background: #fff; padding: 15px 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.15); 
                    display: flex; align-items: center; 
                    justify-content: space-between; /* This is the key fix */
                    z-index: 1000; 
                }
                .controls-left { /* New style for the left-side wrapper */
                    display: flex;
                    align-items: center;
                    gap: 15px;
                }
                /* --- MODIFICATION END --- */

                .print-controls button { padding: 10px 20px; font-size: 16px; font-weight: bold; color: #fff; background-color: #0d6efd; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.2s; }
                .print-controls button:hover { background-color: #0b5ed7; }
                .print-controls button:disabled { background-color: #6c757d; cursor: not-allowed; }
                .print-controls .info { color: #555; }
                
                .format-toggle { display: flex; align-items: center; gap: 5px; background: #e9ecef; border-radius: 5px; padding: 5px; }
                .format-toggle label { padding: 5px 10px; cursor: pointer; border-radius: 3px; font-size: 14px; user-select: none;}
                .format-toggle input[type="radio"] { display: none; }
                .format-toggle input[type="radio"]:checked + label { background: #fff; color: #0d6efd; font-weight: bold; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
                
                #page-container-for-pdf { max-width: 14in; margin: 20px auto; padding: 40px; background-color: #fff; border: 1px solid #ddd; }
                .exam-header { border-bottom: 2px solid #333; padding-bottom: 15px; margin-bottom: 30px; }
                .exam-header h1 { margin: 0; font-size: 28px; }
                .question-block { page-break-inside: avoid; padding-top: 15px; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px dashed #ccc; }
                .question-block:last-child { border-bottom: none; }
                .question-block h3 { margin-top: 0; font-size: 18px; color: #444; }
                .docx img { max-width: 100%; height: auto; }
            </style>
        `;

        // --- MODIFICATION: The HTML structure of the controls is changed here ---
        let bodyContent = `
            <div class="print-controls">
                <div class="controls-left">
                    <button id="generate-btn">Generate</button>
                    <span class="info">Ready</span>
                </div>
                <div class="format-toggle">
                    <input type="radio" id="format-pdf" name="format" value="pdf" checked>
                    <label for="format-pdf">PDF</label>
                    <input type="radio" id="format-html" name="format" value="html">
                    <label for="format-html">HTML</label>
                </div>
            </div>
            <div id="page-container-for-pdf">
                <div class="exam-header"><h1>Certification Exam</h1></div>`;
        questionIDs.forEach((qId, index) => {
            const alertData = window.metadataStore.find(meta => meta.id === qId);
            bodyContent += `
                <div class="question-block">
                    <h3>Alert #${index + 1} [ID: ${qId}]</h3>
                    <div class="docx">${alertData ? alertData.content : '<p style="color: red;">Content for this question could not be found.</p>'}</div>
                </div>`;
        });
        bodyContent += `</div>`;
        const fullHtml = `<!DOCTYPE html><html lang="en"><head>${headContent}</head><body>${bodyContent}</body></html>`;

        examPreviewWindow.document.open();
        examPreviewWindow.document.write(fullHtml);
        examPreviewWindow.document.close();

        setTimeout(() => {
            let printButton = examPreviewWindow?.document.getElementById('generate-btn');
            let contentToPrint = examPreviewWindow?.document.getElementById('page-container-for-pdf');

            const cleanupAndClose = () => {
                if (examPreviewWindow && !examPreviewWindow.closed) {
                    examPreviewWindow.onbeforeunload = null;
                    examPreviewWindow.close();
                }
                controller.abort();
                printButton = null;
                contentToPrint = null;
                examPreviewWindow = null;
            };

            if (!printButton || !contentToPrint) {
                console.error("Could not find control elements in the new tab.");
                cleanupAndClose();
                return;
            }

            printButton.addEventListener('click', async () => {
                const selectedFormat = examPreviewWindow.document.querySelector('input[name="format"]:checked').value;
                const infoSpan = examPreviewWindow.document.querySelector('.print-controls .info');
                printButton.textContent = 'Working...';
                printButton.disabled = true;

                if (selectedFormat === 'html') {
                    await generateExamHTML(examDetail, examPreviewWindow, infoSpan, cleanupAndClose);
                } else {
                    // --- Original PDF Generation Logic (no changes needed here) ---
                    infoSpan.textContent = 'Step 1/4: Initialising...';
                    await new Promise(resolve => setTimeout(resolve, 50));

                    try {
                        const { jsPDF } = window.jspdf;
                        const contentWidthPX = contentToPrint.scrollWidth;
                        const contentHeightPX = contentToPrint.scrollHeight;
                        const margin = 15;
                        const pdfPageWidth = contentWidthPX + (margin * 2);
                        const pdfPageHeight = contentHeightPX + (margin * 2);

                        const doc = new jsPDF({
                            orientation: pdfPageWidth > pdfPageHeight ? 'landscape' : 'portrait',
                            unit: 'px',
                            format: [pdfPageWidth, pdfPageHeight]
                        });

                        doc.addFont('/files/DejaVuSans.ttf', 'DejaVuSans', 'normal');
                        doc.setFont('DejaVuSans');
                        
                        infoSpan.textContent = 'Step 2/4: Rendering...';
                        await new Promise(resolve => setTimeout(resolve, 50));

                        await doc.html(contentToPrint, {
                            x: margin,
                            y: margin,
                            width: contentWidthPX,
                            windowWidth: contentWidthPX,
                            fontFaces: [{
                                family: 'DejaVuSans', style: 'normal', weight: 'normal',
                                src: [{ url: '/files/DejaVuSans.ttf', format: 'truetype' }]
                            }]
                        });

                        infoSpan.textContent = 'Step 3/4: Compiling...';
                        await new Promise(resolve => setTimeout(resolve, 50));

                        const today = new Date();
                        const formattedDate = [
                            String(today.getDate()).padStart(2, '0'),
                            String(today.getMonth() + 1).padStart(2, '0'),
                            String(today.getFullYear()).slice(-2)
                        ].join('.');
                        const safeExaminee = (examDetail.Examinee || "unknown_user").toLowerCase().replace(/[^a-z0-9]/g, '');
                        const fileName = `cert.practical.exam_${safeExaminee}_${formattedDate}.pdf`;
                        
                        doc.save(fileName);
                        infoSpan.textContent = 'Step 4/4: Closing...';
                    } catch (err) {
                        console.error("PDF generation failed:", err);
                        infoSpan.textContent = 'Error! PDF generation failed. Check the console.';
                    } finally {
                        setTimeout(cleanupAndClose, 2000);
                    }
                }
            }, { signal: controller.signal });

        }, 500);

    } catch (err) {
        console.error("Failed to create exam preview:", err);
        alert("An error occurred while preparing the exam preview. Please check the console.");
        if (examPreviewWindow && !examPreviewWindow.closed) {
            examPreviewWindow.close();
            examPreviewWindow = null;
        }
    }
}

async function generateExamHTML(examDetail, previewWindow, infoSpan, cleanupCallback) {
    try {
        infoSpan.textContent = 'Step 1/2: Preparing HTML...';
        await new Promise(resolve => setTimeout(resolve, 50));

        // Get the HTML content of the exam container, excluding the print controls.
        const contentToSave = previewWindow.document.getElementById('page-container-for-pdf').outerHTML;
        
        // Define a self-contained style block for the saved HTML file.
        const savedPageHead = `
            <meta charset="UTF-8">
            <title>Exam - ${examDetail.Examinee || 'N/A'}</title>
            <style>
                body { font-family: sans-serif; line-height: 1.6; color: #333; background-color: #f0f0f0; margin: 0; padding: 20px; }
                #page-container-for-pdf { max-width: 14in; margin: 20px auto; padding: 40px; background-color: #fff; border: 1px solid #ddd; }
                .exam-header { border-bottom: 2px solid #333; padding-bottom: 15px; margin-bottom: 30px; }
                .exam-header h1 { margin: 0; font-size: 28px; }
                .question-block { page-break-inside: avoid; padding-top: 15px; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px dashed #ccc; }
                .question-block:last-child { border-bottom: none; }
                .question-block h3 { margin-top: 0; font-size: 18px; color: #444; }
                .docx img { max-width: 100%; height: auto; }
            </style>
        `;
        // Combine into a full HTML document string.
        const fullHtml = `<!DOCTYPE html><html lang="en"><head>${savedPageHead}</head><body>${contentToSave}</body></html>`;

        // Create a filename.
        const today = new Date();
        const formattedDate = [
            String(today.getDate()).padStart(2, '0'),
            String(today.getMonth() + 1).padStart(2, '0'),
            String(today.getFullYear()).slice(-2)
        ].join('.');
        const safeExaminee = (examDetail.Examinee || "unknown_user").toLowerCase().replace(/[^a-z0-9]/g, '');
        const fileName = `cert.practical.exam_${safeExaminee}_${formattedDate}.html`;

        // Create a Blob and trigger the download.
        const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = fileName;
        document.body.appendChild(link); // Required for Firefox compatibility
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href); // Clean up the object URL

        infoSpan.textContent = 'Step 2/2: Closing...';
        
    } catch (err) {
        console.error("HTML file generation failed:", err);
        infoSpan.textContent = 'Error! HTML generation failed. Check the console.';
    } finally {
        // Ensure the cleanup function is called to close the preview window.
        if (typeof cleanupCallback === 'function') {
            setTimeout(cleanupCallback, 2000);
        }
    }
}

function applyAllFilters() {
  const filters = {
    category: document.getElementById('category-filter').value,
    difficulty: document.getElementById('difficulty-filter').value,
    user: document.getElementById('user-filter').value,
    date: document.getElementById('date-filter').value
  };
  const searchTerm = document.getElementById('search-box').value.toLowerCase().trim();

  window.filteredMetadata = metadataStore
    .map((meta, index) => ({ ...meta, originalIndex: index }))
    .filter(meta => {
      // 1. Check dropdown filters first
      const dropdownsMatch = Object.entries(filters).every(([key, val]) => {
        return !val || meta[key] === val;
      });

      if (!dropdownsMatch) {
        return false; // If it doesn't match dropdowns, no need to search
      }

      // 2. If dropdowns match, then check the search term
      if (searchTerm === '') {
        return true; // If search is empty, it's a match
      }

      // Create a text version of the alert's content, stripping HTML tags
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = meta.content;
      const contentText = (tempDiv.textContent || tempDiv.innerText || '').toLowerCase();

      // Combine all searchable metadata fields into one string
      const metadataText = [
        meta.id || '',
        meta.category || '',
        meta.difficulty || '',
        meta.user || '',
        meta.date || ''
      ].join(' ').toLowerCase();
      
      // Return true if the search term is in the metadata OR the content
      return metadataText.includes(searchTerm) || contentText.includes(searchTerm);
    });

  // Reset view to the first item and re-render
  currentQuestionIndex = 0;
  renderCurrentQuestion();
}


document.getElementById('search-box').addEventListener('input', applyAllFilters);
applyFiltersBtn.addEventListener('click', applyAllFilters);

document.getElementById('clear-filters-btn').addEventListener('click', () => {

  document.getElementById('category-filter').value = '';
  document.getElementById('difficulty-filter').value = '';
  document.getElementById('user-filter').value = '';
  document.getElementById('date-filter').value = '';
  document.getElementById('search-box').value = '';

  applyAllFilters();
});