<#
.SYNOPSIS
    Secure Exam App Launcher with a persistent 90-minute timer.
.DESCRIPTION
    This script is a template for generating self-contained PowerShell exam launchers.
    The exam content is encrypted and decrypted at runtime to prevent casual inspection.
#>

# --- 1. DECRYPTION BLOCK: Decrypts the exam payload at runtime ---
# These variables contain the encrypted exam and the necessary keys for decryption.
# They are intentionally given innocuous names.
$payload = @'
<!-- ENCRYPTED_HTML_HERE -->
'@
$integrityVector = "<!-- IV_HERE -->"
$systemEntropy = "<!-- KEY_HERE -->"

$examHTML = '' # This variable will hold the decrypted HTML content.

try {
    # Create an AES cryptography object
    $aes = New-Object System.Security.Cryptography.AesManaged
    $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7

    # Convert the Base64 key and IV back to byte arrays
    $aes.Key = [System.Convert]::FromBase64String($systemEntropy)
    $aes.IV = [System.Convert]::FromBase64String($integrityVector)

    # Create a decryptor
    $decryptor = $aes.CreateDecryptor($aes.Key, $aes.IV)

    # Convert the Base64 payload string to a byte array
    $encryptedBytes = [System.Convert]::FromBase64String($payload)

    # Decrypt the bytes
    $decryptedBytes = $decryptor.TransformFinalBlock($encryptedBytes, 0, $encryptedBytes.Length)
    
    # Dispose of the crypto objects
    $decryptor.Dispose()
    $aes.Dispose()

    # Convert the decrypted bytes back into a readable HTML string
    $examHTML = [System.Text.Encoding]::UTF8.GetString($decryptedBytes)

} catch {
    Write-Host "FATAL ERROR: Could not decrypt the exam payload. The file may be corrupt." -ForegroundColor Red
    Write-Host "Error details: $($_.Exception.Message)"
    Read-Host "Press ENTER to exit."
    exit 1
}

# If decryption fails, $examHTML will be empty, and the server will fail to start correctly.

# --- 2. SCRIPT LOGIC: Start a PERSISTENT server, launch Edge, and manage state ---
$port = 8089 
$url = "http://localhost:$port/"
# Extract the examId from the decrypted HTML to use in file paths and keys.
# This avoids having to pass it around as a separate variable.
$examId = "<!-- EXAM_ID_RAW_HERE -->"

# Define a secure, non-obvious path for the progress file.
$progressDir = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) "CertOSExam"
if (-not (Test-Path $progressDir)) { New-Item -ItemType Directory -Path $progressDir | Out-Null }
$progressFilePath = Join-Path $progressDir "$($examId).dat"

# --- Helper functions for encryption/decryption of the progress file ---
# We use one of the existing unique values (the original IV) as a salt to derive a key,
# ensuring the progress file's encryption is unique to this specific exam instance.
function Get-ProgressCryptoKeys {
    param($salt, $keyMaterial)
    $hmac = New-Object System.Security.Cryptography.HMACSHA256
    $hmac.Key = [System.Text.Encoding]::UTF8.GetBytes($salt)
    $hashBytes = $hmac.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($keyMaterial))
    # Split the 32-byte hash into a 16-byte key and a 16-byte IV for AES-128.
    $key = $hashBytes[0..15]; $iv = $hashBytes[16..31]
    $hmac.Dispose()
    return @{ Key = $key; IV = $iv }
}

function Encrypt-Progress {
    param($stringData, [byte[]]$key, [byte[]]$iv)
    $aes = New-Object System.Security.Cryptography.AesManaged; $aes.Mode = 'CBC'; $aes.Padding = 'PKCS7'; $aes.Key = $key; $aes.IV = $iv
    $encryptor = $aes.CreateEncryptor()
    $clearTextBytes = [System.Text.Encoding]::UTF8.GetBytes($stringData)
    $encryptedBytes = $encryptor.TransformFinalBlock($clearTextBytes, 0, $clearTextBytes.Length)
    $aes.Dispose()
    return [System.Convert]::ToBase64String($encryptedBytes)
}

function Decrypt-Progress {
    param($base64String, [byte[]]$key, [byte[]]$iv)
    $aes = New-Object System.Security.Cryptography.AesManaged; $aes.Mode = 'CBC'; $aes.Padding = 'PKCS7'; $aes.Key = $key; $aes.IV = $iv
    $decryptor = $aes.CreateDecryptor()
    $encryptedBytes = [System.Convert]::FromBase64String($base64String)
    $decryptedBytes = $decryptor.TransformFinalBlock($encryptedBytes, 0, $encryptedBytes.Length)
    $aes.Dispose()
    return [System.Text.Encoding]::UTF8.GetString($decryptedBytes)
}

# --- PRE-FLIGHT CHECK (ROBUST FILE-LOCK METHOD) ---
# This method uses a PID file as a mutex. It is reliable in all execution environments,
# including those where the console window title is not available.
$lockFilePath = Join-Path $progressDir "$($examId).lock"
$expirationDateString = "<!-- EXPIRATION_DATE_HERE -->"

if (-not [string]::IsNullOrWhiteSpace($expirationDateString) -and $expirationDateString -notlike "<!--*-->") {
    try {
        # Compare today's date (ignoring time) with the expiration date
        $currentDate = (Get-Date).Date
        $expirationDate = [datetime]::ParseExact($expirationDateString, 'yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)

        if ($currentDate -ge $expirationDate) {
            # 1. Inform the user clearly.
            Add-Type -AssemblyName System.Windows.Forms
            [System.Windows.Forms.MessageBox]::Show(
                "This exam has expired and can no longer be accessed. This file will now be removed.", 
                "Exam Expired", 
                [System.Windows.Forms.MessageBoxButtons]::OK, 
                [System.Windows.Forms.MessageBoxIcon]::Stop
            )

            # 2. Kill any other running instance of this same exam to release file locks.
            if (Test-Path $lockFilePath) {
                $oldPid = Get-Content $lockFilePath -ErrorAction SilentlyContinue
                if ($oldPid -and (Get-Process -Id $oldPid -ErrorAction SilentlyContinue)) {
                    Stop-Process -Id $oldPid -Force -ErrorAction SilentlyContinue
                    Start-Sleep -Milliseconds 500 # Give OS a moment to release handles
                }
            }

			# 3. Signal the parent batch file to self-destruct.
			# We exit with a special code (99). The parent .bat script is designed
			# to catch this code and will handle the deletion after this process terminates.
			exit 99
        }
    } catch {
        Write-Warning "Could not parse the expiration date '$expirationDateString'. Ignoring expiration check. Error: $($_.Exception.Message)"
    }
}

Write-Host "Performing pre-flight checks..." -ForegroundColor Gray

if (Test-Path $lockFilePath) {
    $oldPid = Get-Content $lockFilePath -ErrorAction SilentlyContinue

    if ($oldPid) {
        # Check if the process from the lock file is actually still running.
        $oldProcess = Get-Process -Id $oldPid -ErrorAction SilentlyContinue
        
        if ($oldProcess) {
            # The process is still alive. This is an active session. Terminate it.
            Write-Host "An existing exam session (PID: $oldPid) was found via lock file." -ForegroundColor Yellow
            Write-Host "Terminating the old session to start a new one..." -ForegroundColor Yellow
            
            try {
                Stop-Process -Id $oldPid -Force -ErrorAction Stop
                # Give the OS a moment to fully release all resources, especially the network port.
                Start-Sleep -Milliseconds 800
                Write-Host "Previous session terminated successfully." -ForegroundColor Green
            } catch {
                Write-Warning "Failed to terminate process PID $oldPid. It may require manual closure. Error: $($_.Exception.Message)"
            }
        } else {
            # The process is NOT running. The lock file is stale.
            Write-Warning "Found a stale lock file for a non-existent process (PID: $oldPid). Cleaning up."
        }
    }
    # Clean up the old/stale lock file regardless before creating our new one.
    Remove-Item $lockFilePath -Force -ErrorAction SilentlyContinue
}

# Create a new lock file for this current instance.
try {
    Set-Content -Path $lockFilePath -Value $PID -ErrorAction Stop
    Write-Host "Lock file created for this session (PID: $PID)." -ForegroundColor Green
} catch {
    Write-Host "FATAL: Could not create the lock file at '$lockFilePath'." -ForegroundColor Red
    Write-Host "Please check folder permissions. Error: $($_.Exception.Message)"
    Read-Host "Press ENTER to exit."
    exit 1
}
# --- End of Pre-Flight Check ---

# --- Main Server ---
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($url)

# This variable will hold our background monitoring job.
$monitorJob = $null

try {
    # --- START: New Watchdog Job ---
    # Get the Process ID of this current script. The job will need it to shut us down.
    $mainProcessId = $PID
    $windowTitleToWatch = "Secure Exam"

    $monitorJob = Start-Job -ScriptBlock {
        param($parentProcessId, $windowTitle)

        # Phase 1: Wait for the exam window to appear.
        # We'll wait up to 20 seconds. If it doesn't appear, something is wrong.
        Write-Host "[Watchdog] Waiting for window '$windowTitle'..."
        $examProcess = $null
        $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        while ($stopwatch.Elapsed.TotalSeconds -lt 30) {
            $examProcess = Get-Process | Where-Object { $_.MainWindowTitle -eq $windowTitle } | Select-Object -First 1
            if ($examProcess) { break }
            Start-Sleep -Milliseconds 500
        }

        # If the window was never found, exit the job silently.
        if (-not $examProcess) {
            Write-Warning "[Watchdog] Window '$windowTitle' not found. Watchdog is exiting."
            return
        }

        Write-Host "[Watchdog] Window found with ID $($examProcess.Id). Monitoring for closure..."

        # Phase 2: Now that we've found it, monitor it until it disappears.
        while ($true) {
            # Check if the process with that specific ID still exists.
            # Using -ErrorAction SilentlyContinue is key here. If the process is gone, it returns $null instead of an error.
            $processCheck = Get-Process -Id $examProcess.Id -ErrorAction SilentlyContinue
            
            if (-not $processCheck) {
				Write-Host "Closing Secure Exam Environment..." -ForegroundColor Green
				Start-Sleep -Milliseconds 200
                Stop-Process -Id $parentProcessId -Force
                break # Exit the watchdog loop.
            }
            
            # Wait a second before checking again.
            Start-Sleep -Seconds 1
        }
    } -ArgumentList $mainProcessId, $windowTitleToWatch
    # --- END: New Watchdog Job ---

    $listener.Start()
    Write-Host "Preparing Secure Exam Environment..." -ForegroundColor Green

    # Launch the browser to the exam URL
    Start-Process msedge.exe -ArgumentList "--app=`"$url`" --window-size=1280,800 --disable-dev-tools"
    Write-Host "Launching Secure Exam Environment..." -ForegroundColor Green
	Write-Host "Opening Exam. Do not close this window manually." -ForegroundColor Cyan
    # The server loop. It will run until the console is closed.
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request; $response = $context.Response
        $localPath = $request.Url.LocalPath

        try {
            switch ($localPath) {
                '/' {
                    $buffer = [System.Text.Encoding]::UTF8.GetBytes($examHTML); $response.ContentType = 'text/html'
                    $response.ContentLength64 = $buffer.Length; $response.OutputStream.Write($buffer, 0, $buffer.Length)
                }
                '/load-progress' {
                    $progressJson = '{}' # Default empty state
                    if (Test-Path $progressFilePath) {
                        try {
                            $cryptoKeys = Get-ProgressCryptoKeys -salt $integrityVector -keyMaterial $examId
                            $encryptedContent = Get-Content $progressFilePath -Raw
                            if (-not [string]::IsNullOrWhiteSpace($encryptedContent)) {
                                $progressJson = Decrypt-Progress -base64String $encryptedContent -key $cryptoKeys.Key -iv $cryptoKeys.IV
                            }
                        } catch { Write-Warning "Could not decrypt progress file. Starting fresh. Error: $($_.Exception.Message)" }
                    }
                    $buffer = [System.Text.Encoding]::UTF8.GetBytes($progressJson); $response.ContentType = 'application/json'
                    $response.ContentLength64 = $buffer.Length; $response.OutputStream.Write($buffer, 0, $buffer.Length)
                }
                '/save-progress' {
                    $reader = New-Object System.IO.StreamReader($request.InputStream, $request.ContentEncoding)
                    $jsonPayload = $reader.ReadToEnd(); $reader.Dispose()
                    try {
                        $cryptoKeys = Get-ProgressCryptoKeys -salt $integrityVector -keyMaterial $examId
                        $encryptedPayload = Encrypt-Progress -stringData $jsonPayload -key $cryptoKeys.Key -iv $cryptoKeys.IV
                        Set-Content -Path $progressFilePath -Value $encryptedPayload -Encoding ASCII
                        $response.StatusCode = 200
                    } catch { $response.StatusCode = 500; Write-Warning "Failed to save progress: $($_.Exception.Message)" }
                }
                default { $response.StatusCode = 404 }
            }
        } catch {
            Write-Warning "Error processing request: $($_.Exception.Message)"; $response.StatusCode = 500
        } finally {
            if ($response.OutputStream.CanWrite) { $response.OutputStream.Close() }
        }
    }
} catch {
    Write-Host "A fatal server error occurred: $($_.Exception.Message)" -ForegroundColor Red
} finally {
    # Delete the lock file on exit to prevent stale locks. This is a critical step.
    if (Test-Path $lockFilePath) { Remove-Item $lockFilePath -Force -ErrorAction SilentlyContinue }

    if ($listener -and $listener.IsListening) { $listener.Stop() }
    
    # Clean up the background job if the script exits for any other reason (e.g., Ctrl+C)
    if ($monitorJob) {
        Stop-Job -Job $monitorJob      # Corrected: -Force is not a valid parameter here.
        Remove-Job -Job $monitorJob -Force
    }
    
    Write-Host "Exam environment has been shut down." -ForegroundColor Green
    # This Read-Host will only be reached if the script exits manually, not when killed by the watchdog.
    Read-Host "Press ENTER to exit."
}