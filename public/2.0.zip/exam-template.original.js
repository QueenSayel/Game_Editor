<#
.SYNOPSIS
    Secure Exam App Launcher with a persistent 90-minute timer.
.DESCRIPTION
    This script is a template for generating self-contained PowerShell exam launchers.
#>

# --- 1. DATA BLOCK: The exam content is embedded here ---
$examHTML = @'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Secure Exam</title>
	<link id="font-awesome-stylesheet" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" onerror="activateFallbackStyles()" />
    <style>
        body { font-family: 'Segoe UI', sans-serif; margin: 0; background-color: #f0f2f5; }
        .container { margin: 40px; background: white; padding: 40px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); display: flex; flex-direction: column; min-height: 80vh; }
        .header { display: flex; justify-content: space-between; align-items: center; padding-bottom: 20px; border-bottom: 1px solid #eee; margin-bottom: 20px; }
        .header h1 { margin: 0; text-align: left; }
        #timerDisplay { font-size: 24px; font-weight: 600; color: #333; font-family: 'Consolas', monospace; }
        #timerDisplay.low-time { color: #d13438; animation: pulse 1s infinite; }
        @keyframes pulse { 0% { transform: scale(1); } 50% { transform: scale(1.05); } 100% { transform: scale(1); } }
        .content-area { flex-grow: 1; }
        .exam-question { display: none; }
        .exam-question.active { display: block; animation: fadeIn 0.5s; }
        @keyframes fadeIn { from { opacity: 0; } to { { opacity: 1; } } }
        h3 { text-align: center; }
        .controls-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0; }
        .control-group { display: flex; flex-direction: column; }
        label { margin-bottom: 5px; font-weight: 500; color: #333; text-align: left; }
        select, textarea { width: 100%; padding: 8px; font-size: 14px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        select:disabled, textarea:disabled { background-color: #e9ecef; cursor: not-allowed; }
        textarea { resize: vertical; min-height: 120px; }
        .footer { text-align: center; padding-top: 20px; border-top: 1px solid #eee; }
        .pagination button { width: 35px; height: 35px; margin: 0 5px; border: 1px solid #ccc; background-color: white; cursor: pointer; border-radius: 50%; transition: all 0.2s; font-size: 14px; }
        .pagination button:hover { background-color: #f0f0f0; }
        .pagination button.active { background-color: #0078d4; color: white; border-color: #0078d4; font-weight: bold; }
        #finishBtn, #startBtn { padding: 12px 24px; font-size: 16px; cursor: pointer; color: white; border: none; border-radius: 4px; margin-top: 20px; }
        #finishBtn { background-color: #28a745; }
        #startBtn { background-color: #0078d4; }
        #resultContainer { position: relative; margin-top: 20px; padding: 20px; border: 1px dashed #ccc; text-align: left; word-break: break-all; background: #f5f5f5; font-family: 'Consolas', monospace; }
        #welcomeScreen { text-align: center; max-width: 600px; margin: 100px auto; padding: 40px; background: white; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
		#overrideBtn { padding: 6px 10px; font-size: 18px; cursor: pointer; background-color: transparent; border: none; }
		#overrideBtn:hover { background-color: transparent; transform: scale(1.2); }
	        .icon-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 38px;
            height: 38px;
            font-size: 16px;
            border-radius: 50%;
            border: 1px solid #ccc;
            background-color: #f0f0f0;
            cursor: pointer;
            transition: background-color 0.2s;
            color: #333;
        }
        .icon-button:hover {
            background-color: #e0e0e0;
        }
        .icon-button .btn-text {
            display: none;
        }
        .icon-button.fallback {
            width: auto;
            height: auto;
            border-radius: 4px;
            padding: 8px 14px;
            font-size: 14px;
        }
        .icon-button.fallback .btn-icon {
            display: none;
        }
        .icon-button.fallback .btn-text {
            display: inline;
            font-weight: 500;
        }
        #copyBtn {
            position: absolute;
            top: 15px;
            right: 15px;
            width: 32px;
            height: 32px;
            font-size: 14px;
			border: none;
            background-color: transparent;
        }
        #copyBtn:hover {
            background-color: transparent;
			transform: scale(1.2);
        }
        #copy-feedback {
            position: absolute;
            top: 23px;
            right: 55px;
            font-size: 12px;
            color: #28a745;
            font-weight: bold;
            opacity: 0;
            transition: opacity 0.3s;
        }
	</style>
</head>
<body oncontextmenu="return false;">

    <div id="welcomeScreen">
        <h2>Certification Exam</h2>
        <p>You will have 90 minutes to complete this exam. The timer will start as soon as you click the button below and will continue even if you close the browser window.</p>
        <p>Please do not close the window until you are finished.</p>
        <button id="startBtn" onclick="startExam()">Start Exam</button>
    </div>

    <div id="examContainer" style="display: none;">
        <div class="container">
			<div class="header">
				<h1>Certification Exam</h1>
				<div style="display: flex; align-items: center; gap: 15px;">
					<div id="timerDisplay">90:00</div>
					<button id="overrideBtn" class="icon-button" title="Single-use Code" onclick="promptForOverrideCode()">
						<span class="btn-icon"><i class="fa-solid fa-gear"></i></span>
						<span class="btn-text">Help</span>
					</button>
				</div>
			</div>
            <div class="content-area">
                <!-- QUESTION_CONTENT_HERE -->
            </div>
            <div class="footer">
                <div class="pagination" id="pagination"></div>
                <button id="finishBtn" onclick="finishExam()">Finish Exam</button>
			<div id="resultContainer" style="display: none;">
				<span id="copy-feedback">Copied</span>
				<button id="copyBtn" class="icon-button" title="Copy to Clipboard" onclick="copyResultToClipboard()">
					<span class="btn-icon"><i class="fa-solid fa-copy"></i></span>
					<span class="btn-text">Copy</span>
				</button>
				<div class="result-text-content">
					<h4>Exam Completed</h4>
					<p>Please copy this entire string and e-mail it to your examiner:</p>
					<code id="resultString"></code>
				</div>
			</div>
            </div>
        </div>
    </div>
    
<!-- SCRIPT_HERE -->
<script>
	/**
	 * Minified by jsDelivr using Terser v5.19.2.
	 * Original file: /npm/js-sha256@0.11.0/src/sha256.js
	 *
	 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
	 */
	/**
	 * [js-sha256]{@link https://github.com/emn178/js-sha256}
	 *
	 * @version 0.11.0
	 * @author Chen, Yi-Cyuan [emn178@gmail.com]
	 * @copyright Chen, Yi-Cyuan 2014-2024
	 * @license MIT
	 */
	!function(){"use strict";var t="input is invalid type",i="object"==typeof window,h=i?window:{};h.JS_SHA256_NO_WINDOW&&(i=!1);var r=!i&&"object"==typeof self,s=!h.JS_SHA256_NO_NODE_JS&&"object"==typeof process&&process.versions&&process.versions.node;s?h=global:r&&(h=self);var e=!h.JS_SHA256_NO_COMMON_JS&&"object"==typeof module&&module.exports,n="function"==typeof define&&define.amd,o=!h.JS_SHA256_NO_ARRAY_BUFFER&&"undefined"!=typeof ArrayBuffer,a="0123456789abcdef".split(""),f=[-2147483648,8388608,32768,128],u=[24,16,8,0],c=[1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298],y=["hex","array","digest","arrayBuffer"],p=[];!h.JS_SHA256_NO_NODE_JS&&Array.isArray||(Array.isArray=function(t){return"[object Array]"===Object.prototype.toString.call(t)}),!o||!h.JS_SHA256_NO_ARRAY_BUFFER_IS_VIEW&&ArrayBuffer.isView||(ArrayBuffer.isView=function(t){return"object"==typeof t&&t.buffer&&t.buffer.constructor===ArrayBuffer});var l=function(t,i){return function(h){return new _(i,!0).update(h)[t]()}},d=function(t){var i=l("hex",t);s&&(i=A(i,t)),i.create=function(){return new _(t)},i.update=function(t){return i.create().update(t)};for(var h=0;h<y.length;++h){var r=y[h];i[r]=l(r,t)}return i},A=function(i,r){var s,e=require("crypto"),n=require("buffer").Buffer,o=r?"sha224":"sha256";s=n.from&&!h.JS_SHA256_NO_BUFFER_FROM?n.from:function(t){return new n(t)};return function(h){if("string"==typeof h)return e.createHash(o).update(h,"utf8").digest("hex");if(null==h)throw new Error(t);return h.constructor===ArrayBuffer&&(h=new Uint8Array(h)),Array.isArray(h)||ArrayBuffer.isView(h)||h.constructor===n?e.createHash(o).update(s(h)).digest("hex"):i(h)}},w=function(t,i){return function(h,r){return new v(h,i,!0).update(r)[t]()}},b=function(t){var i=w("hex",t);i.create=function(i){return new v(i,t)},i.update=function(t,h){return i.create(t).update(h)};for(var h=0;h<y.length;++h){var r=y[h];i[r]=w(r,t)}return i};function _(t,i){i?(p[0]=p[16]=p[1]=p[2]=p[3]=p[4]=p[5]=p[6]=p[7]=p[8]=p[9]=p[10]=p[11]=p[12]=p[13]=p[14]=p[15]=0,this.blocks=p):this.blocks=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],t?(this.h0=3238371032,this.h1=914150663,this.h2=812702999,this.h3=4144912697,this.h4=4290775857,this.h5=1750603025,this.h6=1694076839,this.h7=3204075428):(this.h0=1779033703,this.h1=3144134277,this.h2=1013904242,this.h3=2773480762,this.h4=1359893119,this.h5=2600822924,this.h6=528734635,this.h7=1541459225),this.block=this.start=this.bytes=this.hBytes=0,this.finalized=this.hashed=!1,this.first=!0,this.is224=t}function v(i,h,r){var s,e=typeof i;if("string"===e){var n,a=[],f=i.length,u=0;for(s=0;s<f;++s)(n=i.charCodeAt(s))<128?a[u++]=n:n<2048?(a[u++]=192|n>>>6,a[u++]=128|63&n):n<55296||n>=57344?(a[u++]=224|n>>>12,a[u++]=128|n>>>6&63,a[u++]=128|63&n):(n=65536+((1023&n)<<10|1023&i.charCodeAt(++s)),a[u++]=240|n>>>18,a[u++]=128|n>>>12&63,a[u++]=128|n>>>6&63,a[u++]=128|63&n);i=a}else{if("object"!==e)throw new Error(t);if(null===i)throw new Error(t);if(o&&i.constructor===ArrayBuffer)i=new Uint8Array(i);else if(!(Array.isArray(i)||o&&ArrayBuffer.isView(i)))throw new Error(t)}i.length>64&&(i=new _(h,!0).update(i).array());var c=[],y=[];for(s=0;s<64;++s){var p=i[s]||0;c[s]=92^p,y[s]=54^p}_.call(this,h,r),this.update(y),this.oKeyPad=c,this.inner=!0,this.sharedMemory=r}_.prototype.update=function(i){if(!this.finalized){var h,r=typeof i;if("string"!==r){if("object"!==r)throw new Error(t);if(null===i)throw new Error(t);if(o&&i.constructor===ArrayBuffer)i=new Uint8Array(i);else if(!(Array.isArray(i)||o&&ArrayBuffer.isView(i)))throw new Error(t);h=!0}for(var s,e,n=0,a=i.length,f=this.blocks;n<a;){if(this.hashed&&(this.hashed=!1,f[0]=this.block,this.block=f[16]=f[1]=f[2]=f[3]=f[4]=f[5]=f[6]=f[7]=f[8]=f[9]=f[10]=f[11]=f[12]=f[13]=f[14]=f[15]=0),h)for(e=this.start;n<a&&e<64;++n)f[e>>>2]|=i[n]<<u[3&e++];else for(e=this.start;n<a&&e<64;++n)(s=i.charCodeAt(n))<128?f[e>>>2]|=s<<u[3&e++]:s<2048?(f[e>>>2]|=(192|s>>>6)<<u[3&e++],f[e>>>2]|=(128|63&s)<<u[3&e++]):s<55296||s>=57344?(f[e>>>2]|=(224|s>>>12)<<u[3&e++],f[e>>>2]|=(128|s>>>6&63)<<u[3&e++],f[e>>>2]|=(128|63&s)<<u[3&e++]):(s=65536+((1023&s)<<10|1023&i.charCodeAt(++n)),f[e>>>2]|=(240|s>>>18)<<u[3&e++],f[e>>>2]|=(128|s>>>12&63)<<u[3&e++],f[e>>>2]|=(128|s>>>6&63)<<u[3&e++],f[e>>>2]|=(128|63&s)<<u[3&e++]);this.lastByteIndex=e,this.bytes+=e-this.start,e>=64?(this.block=f[16],this.start=e-64,this.hash(),this.hashed=!0):this.start=e}return this.bytes>4294967295&&(this.hBytes+=this.bytes/4294967296<<0,this.bytes=this.bytes%4294967296),this}},_.prototype.finalize=function(){if(!this.finalized){this.finalized=!0;var t=this.blocks,i=this.lastByteIndex;t[16]=this.block,t[i>>>2]|=f[3&i],this.block=t[16],i>=56&&(this.hashed||this.hash(),t[0]=this.block,t[16]=t[1]=t[2]=t[3]=t[4]=t[5]=t[6]=t[7]=t[8]=t[9]=t[10]=t[11]=t[12]=t[13]=t[14]=t[15]=0),t[14]=this.hBytes<<3|this.bytes>>>29,t[15]=this.bytes<<3,this.hash()}},_.prototype.hash=function(){var t,i,h,r,s,e,n,o,a,f=this.h0,u=this.h1,y=this.h2,p=this.h3,l=this.h4,d=this.h5,A=this.h6,w=this.h7,b=this.blocks;for(t=16;t<64;++t)i=((s=b[t-15])>>>7|s<<25)^(s>>>18|s<<14)^s>>>3,h=((s=b[t-2])>>>17|s<<15)^(s>>>19|s<<13)^s>>>10,b[t]=b[t-16]+i+b[t-7]+h<<0;for(a=u&y,t=0;t<64;t+=4)this.first?(this.is224?(e=300032,w=(s=b[0]-1413257819)-150054599<<0,p=s+24177077<<0):(e=704751109,w=(s=b[0]-210244248)-1521486534<<0,p=s+143694565<<0),this.first=!1):(i=(f>>>2|f<<30)^(f>>>13|f<<19)^(f>>>22|f<<10),r=(e=f&u)^f&y^a,w=p+(s=w+(h=(l>>>6|l<<26)^(l>>>11|l<<21)^(l>>>25|l<<7))+(l&d^~l&A)+c[t]+b[t])<<0,p=s+(i+r)<<0),i=(p>>>2|p<<30)^(p>>>13|p<<19)^(p>>>22|p<<10),r=(n=p&f)^p&u^e,A=y+(s=A+(h=(w>>>6|w<<26)^(w>>>11|w<<21)^(w>>>25|w<<7))+(w&l^~w&d)+c[t+1]+b[t+1])<<0,i=((y=s+(i+r)<<0)>>>2|y<<30)^(y>>>13|y<<19)^(y>>>22|y<<10),r=(o=y&p)^y&f^n,d=u+(s=d+(h=(A>>>6|A<<26)^(A>>>11|A<<21)^(A>>>25|A<<7))+(A&w^~A&l)+c[t+2]+b[t+2])<<0,i=((u=s+(i+r)<<0)>>>2|u<<30)^(u>>>13|u<<19)^(u>>>22|u<<10),r=(a=u&y)^u&p^o,l=f+(s=l+(h=(d>>>6|d<<26)^(d>>>11|d<<21)^(d>>>25|d<<7))+(d&A^~d&w)+c[t+3]+b[t+3])<<0,f=s+(i+r)<<0,this.chromeBugWorkAround=!0;this.h0=this.h0+f<<0,this.h1=this.h1+u<<0,this.h2=this.h2+y<<0,this.h3=this.h3+p<<0,this.h4=this.h4+l<<0,this.h5=this.h5+d<<0,this.h6=this.h6+A<<0,this.h7=this.h7+w<<0},_.prototype.hex=function(){this.finalize();var t=this.h0,i=this.h1,h=this.h2,r=this.h3,s=this.h4,e=this.h5,n=this.h6,o=this.h7,f=a[t>>>28&15]+a[t>>>24&15]+a[t>>>20&15]+a[t>>>16&15]+a[t>>>12&15]+a[t>>>8&15]+a[t>>>4&15]+a[15&t]+a[i>>>28&15]+a[i>>>24&15]+a[i>>>20&15]+a[i>>>16&15]+a[i>>>12&15]+a[i>>>8&15]+a[i>>>4&15]+a[15&i]+a[h>>>28&15]+a[h>>>24&15]+a[h>>>20&15]+a[h>>>16&15]+a[h>>>12&15]+a[h>>>8&15]+a[h>>>4&15]+a[15&h]+a[r>>>28&15]+a[r>>>24&15]+a[r>>>20&15]+a[r>>>16&15]+a[r>>>12&15]+a[r>>>8&15]+a[r>>>4&15]+a[15&r]+a[s>>>28&15]+a[s>>>24&15]+a[s>>>20&15]+a[s>>>16&15]+a[s>>>12&15]+a[s>>>8&15]+a[s>>>4&15]+a[15&s]+a[e>>>28&15]+a[e>>>24&15]+a[e>>>20&15]+a[e>>>16&15]+a[e>>>12&15]+a[e>>>8&15]+a[e>>>4&15]+a[15&e]+a[n>>>28&15]+a[n>>>24&15]+a[n>>>20&15]+a[n>>>16&15]+a[n>>>12&15]+a[n>>>8&15]+a[n>>>4&15]+a[15&n];return this.is224||(f+=a[o>>>28&15]+a[o>>>24&15]+a[o>>>20&15]+a[o>>>16&15]+a[o>>>12&15]+a[o>>>8&15]+a[o>>>4&15]+a[15&o]),f},_.prototype.toString=_.prototype.hex,_.prototype.digest=function(){this.finalize();var t=this.h0,i=this.h1,h=this.h2,r=this.h3,s=this.h4,e=this.h5,n=this.h6,o=this.h7,a=[t>>>24&255,t>>>16&255,t>>>8&255,255&t,i>>>24&255,i>>>16&255,i>>>8&255,255&i,h>>>24&255,h>>>16&255,h>>>8&255,255&h,r>>>24&255,r>>>16&255,r>>>8&255,255&r,s>>>24&255,s>>>16&255,s>>>8&255,255&s,e>>>24&255,e>>>16&255,e>>>8&255,255&e,n>>>24&255,n>>>16&255,n>>>8&255,255&n];return this.is224||a.push(o>>>24&255,o>>>16&255,o>>>8&255,255&o),a},_.prototype.array=_.prototype.digest,_.prototype.arrayBuffer=function(){this.finalize();var t=new ArrayBuffer(this.is224?28:32),i=new DataView(t);return i.setUint32(0,this.h0),i.setUint32(4,this.h1),i.setUint32(8,this.h2),i.setUint32(12,this.h3),i.setUint32(16,this.h4),i.setUint32(20,this.h5),i.setUint32(24,this.h6),this.is224||i.setUint32(28,this.h7),t},v.prototype=new _,v.prototype.finalize=function(){if(_.prototype.finalize.call(this),this.inner){this.inner=!1;var t=this.array();_.call(this,this.is224,this.sharedMemory),this.update(this.oKeyPad),this.update(t),_.prototype.finalize.call(this)}};var B=d();B.sha256=B,B.sha224=d(!0),B.sha256.hmac=b(),B.sha224.hmac=b(!0),e?module.exports=B:(h.sha256=B.sha256,h.sha224=B.sha224,n&&define((function(){return B})))}();
	//# sourceMappingURL=/sm/47eef3eea27a0ec014f5ff25b997de581c3ce412a0f825bfd3ea80a3a439a248.map

	function bytesToBase64(bytes) {
		const B64_MAP = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
		let str = '';
		for (let i = 0; i < bytes.length; i += 3) {
			const byte1 = bytes[i];
			const byte2 = i + 1 < bytes.length ? bytes[i + 1] : NaN;
			const byte3 = i + 2 < bytes.length ? bytes[i + 2] : NaN;

			const enc1 = byte1 >> 2;
			const enc2 = ((byte1 & 3) << 4) | (byte2 >> 4);
			const enc3 = ((byte2 & 15) << 2) | (byte3 >> 6);
			const enc4 = byte3 & 63;
			
			str += B64_MAP.charAt(enc1);
			str += B64_MAP.charAt(enc2);
			str += isNaN(byte2) ? '=' : B64_MAP.charAt(enc3);
			str += isNaN(byte3) ? '=' : B64_MAP.charAt(enc4);
		}
		return str;
	}

	function promptForOverrideCode() {
		 const code = prompt("Single-use code:");
		 if (!code) return; // User cancelled

		 try {
			 // 1. SPLIT THE CODE
			 const parts = code.split('.');
			 if (parts.length !== 2) throw new Error("Invalid code format.");
			 const base64Payload = parts[0];
			 const externalSignature = parts[1];

			 // 2. DECODE THE PAYLOAD
			 const payloadStr = atob(base64Payload);
			 const payload = JSON.parse(payloadStr);

			 // 3. CHECK EXPIRATION
			 if (payload.exp < (Date.now() / 1000)) {
				 throw new Error("This code has expired.");
			 }

			 // 4. CHECK NONCE REUSE (Client-side)
			 const usedNoncesKey = 'usedNonces_' + examId;
			 let usedNonces = JSON.parse(localStorage.getItem(usedNoncesKey) || '[]');
			 if (usedNonces.includes(payload.nonce)) {
				 throw new Error("This code has already been used.");
			 }

			 // 5. RECREATE THE SIGNATURE
			 // Key is created from the known examId and the hardcoded salt
			 const signingKey = sha256.hmac.array(serverSalt, examId);
			 // Get the signature as a raw byte array from the crypto library
			 const signatureBytes = sha256.hmac.array(signingKey, base64Payload);
			 const localSignature = bytesToBase64(signatureBytes);
			 // 6. VALIDATE SIGNATURE (Remove URL-unsafe characters for comparison)
			 if (localSignature !== externalSignature) {
			 	throw new Error("Invalid signature. The code is not authentic.");
			 }

			 // --- ALL CHECKS PASSED ---
			 // 7. EXECUTE THE ACTION
			 if (payload.action === 'add_time') {
				 let startTime = parseInt(localStorage.getItem(timerStorageKey), 10);
				 // Subtract minutes from start time to effectively add them to the end
				 startTime += payload.value * 60 * 1000;
				 localStorage.setItem(timerStorageKey, startTime);
				 startExam();
				 alert(`${payload.value} minutes have been added to your exam time.`);
			 } else if (payload.action === 're_enable') {
				 if (examState.status !== 'completed') {
					 alert('This code can only be used on a completed exam.');
					 return;
				 }
				 // Reset status and re-enable inputs
				 examState.status = 'in-progress';
				 const allInputs = document.querySelectorAll('.exam-question textarea, .exam-question select');
				 allInputs.forEach(input => { input.disabled = false; });
				 document.getElementById('finishBtn').style.display = 'block';
				 document.getElementById('timerDisplay').style.display = 'block';

				 // Set a new timer for the specified duration
				 const newEndTime = Date.now() + (payload.value * 60 * 1000);
				 const newStartTime = newEndTime - (EXAM_DURATION_MINUTES * 60 * 1000);
				 localStorage.setItem(timerStorageKey, newStartTime);
				 startExam();
				 alert(`The exam has been re-enabled with ${payload.value} minutes remaining.`);
			 }

			 // 8. MARK NONCE AS USED
			 usedNonces.push(payload.nonce);
			 localStorage.setItem(usedNoncesKey, JSON.stringify(usedNonces));

		 } catch (error) {
			 alert(`Error applying code: ${error.message}`);
		 }
	 }

    function copyResultToClipboard() {
        const resultString = document.getElementById('resultString').textContent;
        const feedbackEl = document.getElementById('copy-feedback');
        
        navigator.clipboard.writeText(resultString).then(() => {
            feedbackEl.style.opacity = '1';
            setTimeout(() => { feedbackEl.style.opacity = '0'; }, 2000);
        }).catch(err => {
            console.error('Failed to copy text: ', err);
            alert('Could not copy text automatically. Please select it manually.');
        });
    }

    function activateFallbackStyles() {
        console.log("Font Awesome failed to load. Activating fallback styles.");
        document.querySelectorAll('.icon-button').forEach(button => {
            button.classList.add('fallback');
        });
    }

    // --- CONFIGURATION ---
    const examId = "<!-- EXAM_ID_HERE -->";
    const examinee = "<!-- EXAMINEE_HERE -->";
    const EXAM_DURATION_MINUTES = 90;
    const progressStorageKey = 'examProgress_' + examId;
	const serverSalt = "a9d8f7b2c3e4a5b6d7c8e9f0a1b2c3d4e5f6a7b8c9d0e1f2";
    const timerStorageKey = 'examStartTime_' + examId;

    // --- GLOBAL STATE ---
    let currentQuestion = 0;
    const questions = document.querySelectorAll('.exam-question');
    const paginationContainer = document.getElementById('pagination');
    let examState = { answers: {}, status: 'in-progress' };
    let timerInterval = null;
	const usedNonces = new Set();

    // --- TIMER FUNCTIONS ---
    function formatTime(seconds) { const mins = Math.floor(seconds / 60); const secs = seconds % 60; return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`; }
    function updateTimer(endTime) { const remainingSeconds = Math.round((endTime - Date.now()) / 1000); const timerDisplay = document.getElementById('timerDisplay'); if (remainingSeconds <= 0) { timerDisplay.textContent = "00:00"; finishExam(); } else { timerDisplay.textContent = formatTime(remainingSeconds); if (remainingSeconds < 300) { timerDisplay.classList.add('low-time'); } } }
    function startExam() { document.getElementById('welcomeScreen').style.display = 'none'; document.getElementById('examContainer').style.display = 'block'; let startTime = localStorage.getItem(timerStorageKey); if (!startTime) { startTime = Date.now(); localStorage.setItem(timerStorageKey, startTime); } const examDurationMs = EXAM_DURATION_MINUTES * 60 * 1000; const endTime = parseInt(startTime, 10) + examDurationMs; updateTimer(endTime); if (timerInterval) clearInterval(timerInterval); timerInterval = setInterval(() => updateTimer(endTime), 1000); }

    // --- CORE EXAM FUNCTIONS ---
    function setupPagination() { questions.forEach((_, index) => { const pageBtn = document.createElement('button'); pageBtn.innerText = index + 1; pageBtn.onclick = () => showQuestion(index); paginationContainer.appendChild(pageBtn); }); }
    function showQuestion(index) { currentQuestion = index; questions.forEach((q, i) => { q.classList.toggle('active', i === index); }); const pageButtons = paginationContainer.querySelectorAll('button'); pageButtons.forEach((btn, i) => { btn.classList.toggle('active', i === index); }); }
    function updateDataObjectFromUI() { questions.forEach(q => { const id = q.dataset.id; if (!id) return; examState.answers[id] = { rationale: q.querySelector('textarea').value, inputType: q.querySelector('.input-type-select').value, listEntryType: q.querySelector('.list-entry-select').value, disposition: q.querySelector('.disposition-select').value }; }); }

    // --- LOCALSTORAGE PERSISTENCE ---
    function saveProgress() { if (examState.status === 'completed') return; updateDataObjectFromUI(); localStorage.setItem(progressStorageKey, JSON.stringify(examState)); }
    function loadProgress() { const savedData = localStorage.getItem(progressStorageKey); if (savedData) { examState = JSON.parse(savedData); const answers = examState.answers || {}; questions.forEach(q => { const id = q.dataset.id; if (answers[id]) { q.querySelector('textarea').value = answers[id].rationale || ''; q.querySelector('.input-type-select').value = answers[id].inputType || ''; q.querySelector('.list-entry-select').value = answers[id].listEntryType || ''; q.querySelector('.disposition-select').value = answers[id].disposition || ''; } }); } }
    function setupEventListeners() { const allInputs = document.querySelectorAll('.exam-question textarea, .exam-question select'); allInputs.forEach(input => { input.addEventListener('change', saveProgress); }); }

    // --- FINALIZATION ---
    function simpleHash(str) { let hash = 0; for (let i = 0; i < str.length; i++) { const char = str.charCodeAt(i); hash = ((hash << 5) - hash) + char; hash |= 0; } return 'h' + Math.abs(hash); }
    function setCompletedState(isReloading = false) { if (isReloading) { document.getElementById('welcomeScreen').style.display = 'none'; document.getElementById('examContainer').style.display = 'block'; } const integrityCheck = simpleHash(examId + JSON.stringify(examState.answers)); const results = { examId: examId, examinee: examinee, timestamp: new Date().toISOString(), answers: examState.answers, integrity: integrityCheck }; document.getElementById('resultString').textContent = JSON.stringify(results); document.getElementById('resultContainer').style.display = 'block'; document.getElementById('finishBtn').style.display = 'none'; document.getElementById('timerDisplay').style.display = 'none'; const allInputs = document.querySelectorAll('.exam-question textarea, .exam-question select'); allInputs.forEach(input => { input.disabled = true; }); }
    function finishExam() { if (examState.status === 'completed') return; if (confirm("Are you sure you want to finish the exam? This action is final and cannot be undone.")) { clearInterval(timerInterval); updateDataObjectFromUI(); examState.status = 'completed'; localStorage.setItem(progressStorageKey, JSON.stringify(examState)); setCompletedState(); } }

    // --- INITIALIZATION ---
    document.addEventListener('DOMContentLoaded', () => { loadProgress(); if (questions.length > 0) { setupEventListeners(); setupPagination(); showQuestion(0); } if (examState.status === 'completed') { setCompletedState(true); } else if (localStorage.getItem(timerStorageKey)) { startExam(); } });
</script>
</body>
</html>
'@

# --- 2. SCRIPT LOGIC: Start a ONE-SHOT server, launch Edge, and exit ---
$port = 8089 
$url = "http://localhost:$port/"
$webServerJob = $null
try {
    Write-Host "Preparing secure exam environment..." -ForegroundColor Green
    $webServerJob = Start-Job -ScriptBlock { param($localUrl, $htmlContent)
        $listener = New-Object System.Net.HttpListener; $listener.Prefixes.Add($localUrl)
        try {
            $listener.Start(); Write-Output "SERVER_READY"
            $context = $listener.GetContext()
            $response = $context.Response
            if ($context.Request.RawUrl -eq "/favicon.ico") { $response.StatusCode = 404 } 
            else { $buffer = [System.Text.Encoding]::UTF8.GetBytes($htmlContent); $response.ContentLength64 = $buffer.Length; $response.OutputStream.Write($buffer, 0, $buffer.Length) }
            $response.OutputStream.Close()
        } finally { if ($listener -and $listener.IsListening) { $listener.Stop() } }
    } -ArgumentList $url, $examHTML
    Write-Host "Waiting for secure exam environment to start..." -ForegroundColor Green
    $serverReady = $false; $timeout = New-TimeSpan -Seconds 10; $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    while (-not $serverReady -and $stopwatch.Elapsed -lt $timeout) {
        if ((Receive-Job -Job $webServerJob) -contains "SERVER_READY") { Write-Host "Server is ready!" -ForegroundColor Green; $serverReady = $true } 
        else { Start-Sleep -Milliseconds 250 }
    }
    if (-not $serverReady) { throw "Background server failed to start within the timeout period." }
    Write-Host "Preparing exam content..." -ForegroundColor Green
    Start-Process msedge.exe -ArgumentList "--app=`"$url`" --disable-dev-tools"
    Write-Host "Waiting for browser to load Exam content..." -ForegroundColor Green
    $webServerJob | Wait-Job -Timeout 20 | Out-Null
    if ($webServerJob.State -ne 'Completed') { throw "Server job failed to complete. Browser may not have loaded the exam. Status: $($webServerJob.State)" }
    Write-Host "Exam content delivered." -ForegroundColor Green
} catch {
    Write-Host "An error occurred: $($_.Exception.Message)" -ForegroundColor Red
    if ($webServerJob) { Receive-Job $webServerJob }
    Read-Host "Press ENTER to close this window."
} finally {
    if ($webServerJob) {
        Write-Host "Post-process cleanup..." -ForegroundColor Green
        Stop-Job -Job $webServerJob -PassThru | Remove-Job -Force
    }
    Write-Host "Secure exam environment ready." -ForegroundColor Green
    Start-Sleep -Seconds 3
}
