// theoretical.js

// --- DOM References ---
const newQuestionBtn = document.getElementById('new-question-btn');
const builderContainer = document.getElementById('question-builder-container');

// --- State ---
let initialHtml = builderContainer.innerHTML;
let radioGroupCounter = 0; // To ensure radio buttons in different groups are independent

// --- Event Listeners ---
newQuestionBtn.addEventListener('click', showQuestionEditor);

/**
 * Injects the main question editor UI into the page.
 */
function showQuestionEditor() {
    builderContainer.innerHTML = `
        <h3>New Theoretical Question</h3>
        <div class="form-group">
            <label for="main-question-text">Question Text:</label>
            <textarea id="main-question-text" rows="3" placeholder="Enter the main question here..."></textarea>
        </div>
        
        <div class="builder-toolbar">
            <button id="add-tf-btn" title="Add a True/False question"><i class="fas fa-check-double"></i> True/False</button>
            <button id="add-radio-btn" title="Add a multiple-choice question"><i class="fas fa-dot-circle"></i> Radio Group</button>
            <button id="add-dropdown-btn" title="Add a dropdown question"><i class="fas fa-caret-square-down"></i> Dropdown</button>
            <button id="add-text-input-btn" title="Add an open-ended answer box"><i class="fas fa-paragraph"></i> Text Input</button>
        </div>
        
        <label>Question Components:</label>
        <div id="builder-canvas">
            <!-- Dynamically added controls will appear here -->
        </div>

        <div style="text-align: right; margin-top: 20px;">
            <button id="save-question-btn">Save (Prototype)</button>
            <button id="cancel-question-btn" style="background-color: #6c757d;">Cancel</button>
        </div>
    `;

    // Add event listeners for the new editor controls
    document.getElementById('add-tf-btn').addEventListener('click', addTrueFalse);
    document.getElementById('add-radio-btn').addEventListener('click', addRadioGroup);
    document.getElementById('add-dropdown-btn').addEventListener('click', addDropdown);
    document.getElementById('add-text-input-btn').addEventListener('click', addTextInput);

    document.getElementById('cancel-question-btn').addEventListener('click', () => {
        builderContainer.innerHTML = initialHtml;
    });
    
    document.getElementById('save-question-btn').addEventListener('click', () => {
        alert("Saving is not implemented in this prototype. Check the console (F12) for the generated question structure.");
        // TODO: In a real scenario, you would serialize the content of the builder canvas into JSON.
        console.log("--- Question Structure (Prototype) ---");
        console.log("Main Text:", document.getElementById('main-question-text').value);
        console.log("Components:", document.getElementById('builder-canvas').innerHTML);
    });

    // Use event delegation for dynamically added elements
    document.getElementById('builder-canvas').addEventListener('click', handleCanvasClick);
}

/**
 * Handles all clicks inside the builder canvas to manage dynamic buttons.
 * @param {Event} e - The click event.
 */
function handleCanvasClick(e) {
    const target = e.target;
    if (target.classList.contains('remove-control-btn')) {
        target.closest('.form-group').remove();
    }
    if (target.classList.contains('add-option-btn')) {
        const type = target.dataset.type;
        const parentGroup = target.closest('.form-group');
        const optionText = prompt('Enter the text for the new option:');
        if (optionText) {
            if (type === 'radio') {
                addRadioOption(parentGroup, optionText);
            } else if (type === 'dropdown') {
                addDropdownOption(parentGroup, optionText);
            }
        }
    }
    if (target.classList.contains('remove-option-btn')) {
        target.parentElement.remove();
    }
}

/** Helper to create an editable label */
const createEditableLabel = (text) => `<label class="editable-label" contenteditable="true">${text}</label>`;

/**
 * Appends a control to the canvas.
 * @param {string} html - The HTML string of the control to add.
 */
function appendToCanvas(html) {
    document.getElementById('builder-canvas').insertAdjacentHTML('beforeend', html);
}

// --- Control Creation Functions ---

function addTrueFalse() {
    const groupId = `tf-group-${radioGroupCounter++}`;
    const html = `
        <div class="form-group radio-group">
            <button class="remove-control-btn">×</button>
            ${createEditableLabel('True/False Statement:')}
            <div class="radio-option">
                <input type="radio" name="${groupId}" value="True" /> <label>True</label>
            </div>
            <div class="radio-option">
                <input type="radio" name="${groupId}" value="False" /> <label>False</label>
            </div>
        </div>
    `;
    appendToCanvas(html);
}

function addRadioGroup() {
    const groupId = `radio-group-${radioGroupCounter++}`;
    const html = `
        <div class="form-group radio-group" data-group-id="${groupId}">
            <button class="remove-control-btn">×</button>
            ${createEditableLabel('Multiple Choice Question:')}
            <div class="options-container">
                <!-- Radio options will be added here -->
            </div>
            <button class="add-option-btn" data-type="radio">Add Radio Option</button>
        </div>
    `;
    appendToCanvas(html);
}

function addRadioOption(parentGroup, text) {
    const container = parentGroup.querySelector('.options-container');
    const groupId = parentGroup.dataset.groupId;
    const optionHtml = `
        <div class="radio-option">
            <input type="radio" name="${groupId}" value="${text}" />
            <span class="editable-label" contenteditable="true">${text}</span>
            <button class="remove-option-btn" style="position: static; margin-left: auto;">×</button>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', optionHtml);
}

function addDropdown() {
    const html = `
        <div class="form-group dropdown-group">
            <button class="remove-control-btn">×</button>
            ${createEditableLabel('Dropdown Question:')}
            <select>
                <!-- Dropdown options will be added here -->
            </select>
            <button class="add-option-btn" data-type="dropdown">Add Dropdown Option</button>
        </div>
    `;
    appendToCanvas(html);
}

function addDropdownOption(parentGroup, text) {
    const select = parentGroup.querySelector('select');
    const optionHtml = `<option value="${text}">${text}</option>`;
    select.insertAdjacentHTML('beforeend', optionHtml);
}

function addTextInput() {
    const html = `
        <div class="form-group">
            <button class="remove-control-btn">×</button>
            ${createEditableLabel('Open-ended Question:')}
            <textarea placeholder="Examinee will type their answer here..."></textarea>
        </div>
    `;
    appendToCanvas(html);
}