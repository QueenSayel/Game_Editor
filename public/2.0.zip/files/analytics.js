// analytics.js

let chartInstance = null;

// Custom legend plugin for Chart.js v3+
const legendMarginPlugin = {
    id: 'legendMargin',
    beforeInit(chart) {
        const originalFit = chart.legend.fit;
        chart.legend.fit = function() {
            originalFit.bind(chart.legend)();
            this.height += 30; // Add 30px margin below the legend
        };
    }
};

// Register the plugin
Chart.register(legendMarginPlugin);

export function closeAnalyticsModal() {
    document.getElementById('analytics-modal').style.display = 'none';
    if (chartInstance) {
        chartInstance.destroy();
        chartInstance = null;
    }
}

export function showAnalytics() {
    const modal = document.getElementById('analytics-modal');
    modal.style.display = 'block';
    renderAnalyticsChart('category');
    
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            renderAnalyticsChart(this.dataset.chart);
        });
    });
}

function renderAnalyticsChart(type = 'category') {
    if (chartInstance) {
        chartInstance.destroy();
    }

    const selectedData = Array.from(selectedPages).map(page => 
        metadataStore[page - 1]
    );

    const counts = selectedData.reduce((acc, curr) => {
        const key = curr[type] || 'Unknown';
        acc[key] = (acc[key] || 0) + 1;
        return acc;
    }, {});

    const ctx = document.getElementById('analytics-chart').getContext('2d');
    
    chartInstance = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: Object.keys(counts),
            datasets: [{
                data: Object.values(counts),
                backgroundColor: [
                    '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0',
                    '#9966FF', '#FF9F40', '#E7E9ED', '#8C564B'
                ],
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        padding: 20
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = selectedData.length;
                            const value = context.raw || 0;
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${context.label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

// Add close button handler
document.querySelector('#analytics-modal .close')?.addEventListener('click', closeAnalyticsModal);

// Initialize analytics button
document.querySelector('.analytics-btn')?.addEventListener('click', showAnalytics);

// Make function available globally
window.closeAnalyticsModal = closeAnalyticsModal;
document.querySelector('#analytics-modal .btn-back')?.addEventListener('click', closeAnalyticsModal);
document.querySelector('#analytics-modal .btn-revalidate')?.addEventListener('click', (e) => {
  // Get fresh validation data
  const questionCount = parseInt(document.getElementById('question-count').value, 10);
  const conditions = Array.from(document.querySelectorAll('.condition-row')).map(row => {
    const typeSelect = row.querySelector('select:first-child');
    const operator = row.querySelector('select:nth-child(2)').value;
    const value = parseInt(row.querySelector('input').value, 10);
    
    return {
      type: typeSelect.className.includes('category') ? 'category' : 'difficulty',
      field: typeSelect.value,
      operator,
      required: value
    };
  });

  // Create a validation event object
  const validationEvent = {
    preventDefault: () => {}, // Mock preventDefault
    target: document.querySelector('.validate-btn') // Original validate button
  };

  // Run validation
  handleValidation(validationEvent);

  // Only refresh analytics if validation succeeded
  if (!document.querySelector('#randomise-status-container .alert-error')) {
    const activeTab = document.querySelector('.tab-btn.active').dataset.chart;
    renderAnalyticsChart(activeTab);
    
    // Update analytics button state
    document.querySelector('.analytics-btn').disabled = false;
  }
});

document.querySelector('.preset-btn').addEventListener('click', async function () {
    const presetName = prompt("Enter a name for this preset:");
    if (!presetName) return;

    const questionCount = parseInt(document.getElementById('question-count').value);
    const conditions = Array.from(document.querySelectorAll('.condition-row')).map(row => {
        const firstSelect = row.querySelector('select:first-child');
        const type = firstSelect.classList.contains('condition-category-select') ? 'category' : 'difficulty';
        const field = firstSelect.value;
        const operator = row.querySelector('select:nth-child(2)').value;
        const required = parseInt(row.querySelector('input').value, 10);

        return { type, field, operator, required };
    });

    // *** LOGGING ADDED HERE ***
    const presetPayload = { presetName, questionCount, conditions };
    console.log("Sending preset data to /save-preset:", JSON.stringify(presetPayload, null, 2));
    // **************************

    try {
        const response = await fetch('/save-preset', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ presetName, questionCount, conditions })
        });

        if (!response.ok) throw new Error('Failed to save preset');
        loadPresets();
        alert('Preset saved successfully');
    } catch (error) {
        alert(`Error saving preset: ${error.message}`);
    }
});

// Load presets on page load
document.addEventListener('DOMContentLoaded', loadPresets);

async function loadPresets() {
    try {
        const response = await fetch('/list-presets');
        if (!response.ok) {
            throw new Error(`Server error: ${response.status}`);
        }

        let presets = await response.json();

        if (!Array.isArray(presets)) {
            presets = [presets];
        }

        const dropdown = document.getElementById('preset-dropdown');
        dropdown.innerHTML = '<option value="">-- Select Preset --</option>';

        presets.forEach(preset => {
            const option = document.createElement('option');
            option.value = preset.PresetID;
            option.textContent = preset.Name;
            dropdown.appendChild(option);
        });
    } catch (error) {
        console.error('Error loading presets:', error);
        alert('Failed to load presets. Check console for details.');
    }
}

// Modified load preset handler
document.querySelector('.load-preset').addEventListener('click', async function() {
    const presetId = document.getElementById('preset-dropdown').value;
    if (!presetId) return;

    const loadButton = this;
    const spinner = document.querySelector('.loading-spinner');
    
    try {
        // Show loading state
        loadButton.disabled = true;
        spinner.classList.remove('hidden');

        // Ensure options are populated
        if (!window.randomiseCategories || !window.randomiseDifficulties) {
            populateConditionOptions();
        }

        const response = await fetch(`/get-preset?id=${presetId}`);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const preset = await response.json();
        
        // Update UI
        document.getElementById('question-count').value = preset.QuestionCount;
        
        const container = document.getElementById('conditions-container');
        container.innerHTML = '';
        
        // Handle different response formats
        const rawConditions = preset.Conditions.value || preset.Conditions;
        const conditions = Array.isArray(rawConditions) ? rawConditions : [rawConditions];

        // Create condition rows
        conditions.forEach(condition => {
            const row = document.createElement('div');
            row.className = 'condition-row';
            
            // Create type select
            const typeSelect = document.createElement('select');
            typeSelect.className = `condition-${condition.type}-select`;
            typeSelect.innerHTML = condition.type === 'category' 
                ? window.randomiseCategories.innerHTML
                : window.randomiseDifficulties.innerHTML;

            // Create operator select
            const operatorSelect = document.createElement('select');
            operatorSelect.innerHTML = `
                <option value=">">More Than</option>
                <option value="=">Exactly</option>
                <option value="<">Less Than</option>
            `;

            // Create value input
            const valueInput = document.createElement('input');
            valueInput.type = 'number';
            valueInput.min = '1';
            valueInput.value = condition.required;

            // Create remove button
            const removeBtn = document.createElement('button');
            removeBtn.textContent = '×';
            removeBtn.className = 'remove-condition';
            removeBtn.onclick = () => row.remove();

            // Handle different operator formats
            const cleanOperator = condition.operator
                .replace(/\\u003e/g, '>')
                .replace(/\\u003c/g, '<');

            // Set initial values
            typeSelect.value = condition.field;
            operatorSelect.value = cleanOperator;

            // Assemble row
            row.append(typeSelect, operatorSelect, valueInput, removeBtn);
            container.appendChild(row);
        });

        // Update remove button handlers
        document.querySelectorAll('.remove-condition').forEach(btn => {
            btn.addEventListener('click', () => btn.closest('.condition-row').remove());
        });

    } catch (error) {
        console.error('Preset load failed:', error);
        alert(`Error loading preset: ${error.message}`);
    } finally {
        // Restore UI state
        loadButton.disabled = false;
        spinner.classList.add('hidden');
    }
});

document.getElementById('preset-dropdown').addEventListener('change', function() {
    const loadButton = document.querySelector('.load-preset');
    if (this.value === '') {
        loadButton.classList.add('disabled-button');
        loadButton.disabled = true;
    } else {
        loadButton.classList.remove('disabled-button');
        loadButton.disabled = false;
    }
});

// Initialize button state on page load
document.addEventListener('DOMContentLoaded', () => {
    const loadButton = document.querySelector('.load-preset');
    loadButton.classList.add('disabled-button');
    loadButton.disabled = true;
});