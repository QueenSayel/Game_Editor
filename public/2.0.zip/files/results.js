// results.js

document.addEventListener('click', async function(e) {
    if (e.target.classList.contains('answers-option')) {
        e.preventDefault();
        if (e.target.hasAttribute('disabled')) return;

        const examItem = e.target.closest('.exam-item');
		const uniqueExamId = examItem.dataset.examId; 
		const examDetail = window.examDetails.find(d => d.ExamID === uniqueExamId);

        if (examDetail?.Questions) {
            // Get question IDs
            let questionIDs = [];
            if (Array.isArray(examDetail.Questions)) {
                questionIDs = examDetail.Questions;
            } else {
                try {
                    questionIDs = JSON.parse(examDetail.Questions || '[]');
                } catch {
                    questionIDs = (examDetail.Questions || '').split(',').map(q => q.trim());
                }
            }
            
            // Fetch assessment data and create tab
            const assessmentData = await fetchAssessmentData(examDetail);
            createHistoricalAssessmentTab(examDetail, questionIDs, assessmentData);
        }
        e.target.closest('.dropdown-menu').classList.remove('show');
    }
});

async function fetchAssessmentData(examDetail) {
    try {
        console.log('[DEBUG] Fetching analytics data from /get-analytics-data');
        
        const response = await fetch('/get-analytics-data');
        
        console.log(`[DEBUG] Server response status: ${response.status} ${response.statusText}`);
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error('[DEBUG] Server returned error:', errorText);
            throw new Error('Failed to fetch analytics data');
        }

        // Log raw response before parsing
        const rawResponse = await response.text();
        console.log('[DEBUG] Raw server response:', rawResponse);
        
        try {
            const analyticsData = JSON.parse(rawResponse);
            console.log('[DEBUG] Parsed analytics data:', analyticsData);
            
            // Extract question IDs from examDetail
            let questionIDs = [];
            if (Array.isArray(examDetail.Questions)) {
                questionIDs = examDetail.Questions;
            } else {
                try {
                    questionIDs = JSON.parse(examDetail.Questions || '[]');
                } catch {
                    questionIDs = (examDetail.Questions || '').split(',').map(q => q.trim());
                }
            }
            
            console.log('[DEBUG] Filtering criteria:', {
                examExaminee: examDetail.Examinee,
                examQuestionIDs: questionIDs,
                analyticsCount: analyticsData.length
            });
            
            // Filter analytics data for this specific exam
            const filteredData = analyticsData.filter(row => {
                // Check if any question ID in this exam matches the analytics row
                const hasMatchingQuestion = questionIDs.includes(row.QuestionID);
                
                // Check if examinee matches (case-insensitive)
                const examineeMatches = row.ExamineeID.toLowerCase() === examDetail.Examinee.toLowerCase();
                
                return hasMatchingQuestion && examineeMatches;
            });
            
            console.log(`[DEBUG] Found ${filteredData.length} matching records`);
            return filteredData;
        } catch (parseError) {
            console.error('[DEBUG] JSON parse error:', parseError);
            console.error('[DEBUG] Problematic response:', rawResponse);
            return [];
        }
    } catch (err) {
        console.error('[DEBUG] Fetch error:', err);
        return [];
    }
}

async function createHistoricalAssessmentTab(examDetail, questionIDs, assessmentData) {
    console.group('[Historical Assessment] Creating tab');
    const formatDate = (timestamp) => {
        if (!timestamp) return 'Unknown Date';
        try {
            if (typeof timestamp === 'string' && timestamp.includes('.')) {
                const [datePart, timePart] = timestamp.split(' ');
                const [day, month, year] = datePart.split('.').map(Number);
                return `${day.toString().padStart(2, '0')}.${month.toString().padStart(2, '0')}.${year.toString().slice(-2)}`;
            } else {
                const date = new Date(timestamp);
                return isNaN(date) ? 'Unknown Date' : 
                    `${date.getDate().toString().padStart(2, '0')}.${(date.getMonth()+1).toString().padStart(2, '0')}.${(date.getFullYear() % 100).toString().padStart(2, '0')}`;
            }
        } catch { return 'Unknown Date'; }
    };

    const examinee = examDetail.Examinee || 'Unknown Examinee';
    const date = formatDate(examDetail.Timestamp);
    const tabName = `${examinee} | ${date} (Archival)`;
    const sanitizedTabName = tabName.replace(/[^a-z0-9]/gi, '-').toLowerCase();
    const uniqueTabId = `${sanitizedTabName}-${Date.now()}`;

    const pageNumbers = questionIDs.map(id => {
        const index = window.metadataStore.findIndex(meta => meta.id === id);
        return index !== -1 ? index + 1 : null;
    }).filter(page => page !== null);

    // 1. Initialize State for this Tab
    window.assessmentTabStates[uniqueTabId] = {
        examDetail: examDetail,
        questionIDs: questionIDs,
        pageNumbers: pageNumbers,
        currentQuestionIndex: 0,
        isFinalized: true, // This is a historical tab
        assessmentData: assessmentData.reduce((acc, item) => {
            acc[item.QuestionID] = {
                inputType: item.InputType,
                listEntry: item.ListEntry,
                rationale: item.Rationale,
                disposition: item.Disposition,
                mishandle: item.Mishandle,
                comment: item.Comments || '',
                isChecked: true // Historical data is always "checked"
            };
            return acc;
        }, {})
    };

    try {
        const response = await fetch(`/get-exam-response?examId=${examDetail.ExamID}`);
        if (response.ok) {
            const savedData = await response.json();
            // Check if the server returned a non-empty object with our string
            if (savedData && savedData.ResponseString) {
                const parsedResponse = JSON.parse(savedData.ResponseString);
                // Store the parsed answers in the state for this tab
                window.assessmentTabStates[uniqueTabId].examineeResponses = parsedResponse.answers;
            }
        }
    } catch (error) {
        console.error("Could not fetch saved examinee response for historical view:", error);
    }

    // 2. Create the Tab Shell
    const tabButton = document.createElement('button');
    tabButton.className = 'tab-button';
    tabButton.innerHTML = `${tabName}<span class="close-tab" onclick="removeTab('${uniqueTabId}')">×</span>`;
    tabButton.dataset.tab = uniqueTabId;

    const tabContent = document.createElement('div');
    tabContent.id = `${uniqueTabId}-tab`;
    tabContent.className = 'content-tab assess-tab historical-tab';

    const viewerContainer = document.createElement('div');
    viewerContainer.className = 'viewer-container';
    viewerContainer.style.cssText = 'background-color: #fff; padding: 20px; border: 1px solid #ccc; box-shadow: 0 2px 5px rgba(0,0,0,0.1);';

    const statusDiv = document.createElement('div');
    statusDiv.id = `status-${uniqueTabId}`;
    statusDiv.className = 'assessment-status';

    const docxContainer = document.createElement('div');
    docxContainer.className = 'docx-container';
    docxContainer.style.cssText = 'background-color: #fff; min-height: 400px; line-height: 1.6;';

    // 3. Create the Pagination Footer
    const footer = document.createElement('div');
    footer.className = 'assessment-footer';
    const paginationControls = document.createElement('div');
    paginationControls.className = 'pagination-controls';
    
    pageNumbers.forEach((pn, index) => {
        const btn = document.createElement('button');
        btn.className = 'page-jump-btn';
        btn.textContent = index + 1;
        btn.onclick = () => {
            window.assessmentTabStates[uniqueTabId].currentQuestionIndex = index;
            renderHistoricalQuestion(uniqueTabId);
        };
        paginationControls.appendChild(btn);
    });

    const resultsBtn = document.createElement('button');
    resultsBtn.className = 'results-btn';
    resultsBtn.textContent = 'Results';
    resultsBtn.onclick = () => checkAllAssessmentsComplete(examDetail, uniqueTabId);
    
    footer.append(paginationControls, resultsBtn);
    
    // 4. Assemble and Add Listeners
    viewerContainer.append(statusDiv, docxContainer);
    tabContent.append(viewerContainer, footer);
    
    viewerContainer.addEventListener('wheel', (event) => {
        if (!event.shiftKey) return;
        event.preventDefault();
        const state = window.assessmentTabStates[uniqueTabId];
        if (!state) return;

        if (event.deltaY > 0 && state.currentQuestionIndex < state.pageNumbers.length - 1) {
            state.currentQuestionIndex++;
            renderHistoricalQuestion(uniqueTabId);
        } else if (event.deltaY < 0 && state.currentQuestionIndex > 0) {
            state.currentQuestionIndex--;
            renderHistoricalQuestion(uniqueTabId);
        }
    });

    // 5. Add to DOM and Activate
    const tabsContainer = document.getElementById('tabs');
    const mainContentArea = document.querySelector('#alerts-tab').parentNode;
    tabsContainer.appendChild(tabButton);
    mainContentArea.appendChild(tabContent);

    document.querySelectorAll('.tab-button').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.content-tab').forEach(t => t.style.display = 'none');
    tabButton.classList.add('active');
    tabContent.style.display = 'block';

    // 6. Initial Render
    renderHistoricalQuestion(uniqueTabId);
    console.groupEnd();
}

// In results.js

function renderHistoricalQuestion(tabId) {
    const state = window.assessmentTabStates[tabId];
    if (!state) return;

    const { currentQuestionIndex, pageNumbers, questionIDs, assessmentData } = state;
    const pageNumber = pageNumbers[currentQuestionIndex];
    const questionId = questionIDs[currentQuestionIndex];

    const alertData = window.metadataStore.find(meta => meta.id === questionId);
    const questionData = assessmentData[questionId];

    const docxContainer = document.querySelector(`#${tabId}-tab .docx-container`);
    if (!docxContainer) return;
    docxContainer.innerHTML = '';

    if (!alertData) {
        docxContainer.innerHTML += `<p style="color: red; padding: 20px;">Error: Could not find content for Alert ID: ${questionId}. It may have been deleted.</p>`;
        return;
    }

    const sectionClone = document.createElement('section');
    sectionClone.className = 'docx';
    sectionClone.style.position = 'relative';

    const questionArticle = document.createElement('article');
    questionArticle.innerHTML = alertData.content;

    const answerContainer = document.createElement('div');
    answerContainer.className = 'answer-container';
    answerContainer.style.display = 'none';
    const savedAnswerHtml = window.unsavedAnswers[questionId]
        ? window.unsavedAnswers[questionId]
        : '<p><i>No answer/rationale was saved for this alert.</i></p>';
    answerContainer.innerHTML = `<h4 style="margin-top:0;">Saved Answer/Rationale</h4><div>${savedAnswerHtml}</div>`;

    sectionClone.appendChild(questionArticle);
    
    const assessmentControls = document.createElement('div');
    assessmentControls.className = 'assessment-controls';
    assessmentControls.style.display = 'block';

    const checkboxGrid = document.createElement('div');
    checkboxGrid.style.cssText = `display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 10px; margin-bottom: 15px;`;

    const controlIdPrefix = `${tabId}-q${currentQuestionIndex}`;

    ['Input Type', 'List Entry', 'Rationale', 'Disposition', 'Mishandle'].forEach(label => {
        const camelCaseKey = label.split(' ').map((word, index) =>
            index === 0 ? word.toLowerCase() : word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
        ).join('');
        
        const controlGroup = document.createElement('div');
        controlGroup.className = 'control-group';
        const switchContainer = document.createElement('label');
        switchContainer.className = 'switch';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';

        // <<< THE FIX IS HERE >>>
        const labelId = label.toLowerCase().replace(' ', '-');
        checkbox.id = `${controlIdPrefix}-${labelId}`;
        // <<< END OF FIX >>>

        checkbox.checked = questionData[camelCaseKey] || false;
        checkbox.disabled = true;

        const slider = document.createElement('span');
        slider.className = 'slider';
        if (label === 'Mishandle') slider.classList.add('slider-mishandle');
        const labelElement = document.createElement('span');
        labelElement.className = 'control-label';
        labelElement.textContent = label;

        switchContainer.append(checkbox, slider);
        controlGroup.append(switchContainer, labelElement);
        checkboxGrid.appendChild(controlGroup);
    });

    const commentContainer = document.createElement('div');
    const commentLabel = document.createElement('label');
    commentLabel.textContent = 'Comments:';
    commentLabel.className = 'comment-label';
    const commentTextarea = document.createElement('textarea');
    commentTextarea.className = 'assessment-comments';
    commentTextarea.value = questionData.comment || '';
    commentTextarea.disabled = true;
    commentContainer.append(commentLabel, commentTextarea);
    
    assessmentControls.append(checkboxGrid, commentContainer);

    const buttonGroup = document.createElement('div');
    buttonGroup.style.cssText = `position: absolute; top: 10px; left: 10px; z-index: 900; display: flex; gap: 6px; align-items: center;`;

    const showBtn = document.createElement('button');
    showBtn.className = 'show-btn';
    showBtn.textContent = 'Hide';
    showBtn.style.cssText = `padding: 4px 8px; min-width: 60px; color: white; border: none; border-radius: 4px; cursor: pointer; background-color: #6c757d;`;
    showBtn.onclick = () => {
        const isVisible = questionArticle.style.display !== 'none';
        questionArticle.style.display = isVisible ? 'none' : 'block';
        showBtn.textContent = isVisible ? 'Show' : 'Hide';
        showBtn.style.backgroundColor = isVisible ? '#007bff' : '#6c757d';
    };

    const gradeBtn = document.createElement('button');
    gradeBtn.className = 'grade-btn';
    gradeBtn.textContent = 'Hide';
    gradeBtn.style.cssText = `padding: 4px 8px; min-width: 60px; background-color: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer;`;
    gradeBtn.onclick = () => {
        const isVisible = assessmentControls.style.display === 'block';
        assessmentControls.style.display = isVisible ? 'none' : 'block';
        gradeBtn.textContent = isVisible ? 'Grade' : 'Hide';
        gradeBtn.style.backgroundColor = isVisible ? '#17a2b8' : '#6c757d';
    };

    const metaSpan = document.createElement('span');
    metaSpan.style.cssText = `font-size: 0.9em; color: #666; margin-left: 10px; vertical-align: middle;`;
    const questionMeta = alertData;
    metaSpan.textContent = `#${currentQuestionIndex + 1} [${questionMeta.category} | ${questionMeta.difficulty} | ID: ${questionMeta.id}]`;

    buttonGroup.append(showBtn, gradeBtn, metaSpan);
    sectionClone.prepend(buttonGroup);
    
    const answerBtn = document.createElement('button');
    answerBtn.className = 'answer-btn';
    answerBtn.textContent = 'Answer';
    answerBtn.style.cssText = `position: absolute; top: 10px; right: 10px; padding: 4px 8px; min-width: 60px; background-color: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; z-index: 900;`;
    sectionClone.appendChild(answerBtn);

    if (answerBtn && answerContainer) {
        answerBtn.onclick = () => {
            const isVisible = answerContainer.style.display === 'block';
            answerContainer.style.display = isVisible ? 'none' : 'block';
            answerBtn.textContent = isVisible ? 'Answer' : 'Hide';
            answerBtn.style.backgroundColor = isVisible ? '#007bff' : '#6c757d';
        };
    }
    
    docxContainer.append(sectionClone, answerContainer);

    // --- START MODIFICATION: Render the examinee's response if it exists ---
    if (state.examineeResponses) {
        const questionId = questionIDs[currentQuestionIndex];
        const examineeAnswer = state.examineeResponses[questionId];

        const examineeResponseContainer = document.createElement('div');
        // We reuse the same class, so it will get the same styling
        examineeResponseContainer.className = 'examinee-response-container';

        if (examineeAnswer) {
            examineeResponseContainer.innerHTML = `
                <h4>Examinee's Response</h4>
                <div class="response-grid">
                    <div><strong>Input Type:</strong> ${examineeAnswer.inputType || 'N/A'}</div>
                    <div><strong>List Entry:</strong> ${examineeAnswer.listEntryType || 'N/A'}</div>
                    <div><strong>Disposition:</strong> ${examineeAnswer.disposition || 'N/A'}</div>
                </div>
                <div class="response-rationale">
                    <strong>Rationale:</strong>
                    <pre>${examineeAnswer.rationale || 'No rationale provided.'}</pre>
                </div>
            `;
        } else {
            examineeResponseContainer.innerHTML = `<h4>Examinee's Response</h4><p>No response was recorded for this specific question.</p>`;
        }
        // Add the new container to the view
        docxContainer.appendChild(examineeResponseContainer);
    }
    // --- END MODIFICATION ---

    docxContainer.appendChild(assessmentControls);
    
    const statusDiv = document.querySelector(`#status-${tabId}`);
    if(statusDiv) statusDiv.innerHTML = `Viewing archived question ${currentQuestionIndex + 1} of ${pageNumbers.length} <span class="status-badge finalized">Read-only</span>`;

    const paginationControls = document.querySelector(`#${tabId}-tab .pagination-controls`);
    if(paginationControls) {
        Array.from(paginationControls.children).forEach((btn, index) => {
            btn.classList.toggle('active', index === currentQuestionIndex);
        });
    }
	updatePopOutContent(tabId);
}