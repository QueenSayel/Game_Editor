// download-report.js

let fullAnalyticsData = null; // Cache for analytics data

document.addEventListener('click', async function(e) {
    if (e.target.classList.contains('download-option') && 
        !e.target.classList.contains('disabled')) {
        e.preventDefault();
        
        const examItem = e.target.closest('.exam-item');
		const uniqueExamId = examItem.dataset.examId;
        const examDetail = examDetails.find(d => d.ExamID === uniqueExamId);

        if (!examDetail) {
            alert('Exam details not found');
            return;
        }
		const originalText = e.target.textContent;
        try {
            // Show loading indicator
            e.target.textContent = 'Loading...';
            
            // Load analytics data if not cached
            if (!fullAnalyticsData) {
                fullAnalyticsData = await fetchAnalyticsData();
            }
            
            // Filter data for this specific exam
            const examAnalytics = fullAnalyticsData.filter(item => 
                item.ExamID.trim().toLowerCase() === uniqueExamId.trim().toLowerCase()
            );
            
            if (!examAnalytics || examAnalytics.length === 0) {
                alert('No analytics data found for this exam');
                e.target.textContent = originalText;
                return;
            }
            
            // Generate PDF report
            await generateReportPDF(examAnalytics, examDetail);
        } catch (error) {
            console.error('Failed to generate report:', error);
            alert('Failed to generate report: ' + error.message);
        } finally {
            e.target.textContent = originalText;
        }
    }
});

async function fetchAnalyticsData() {
    try {
        const response = await fetch('/get-analytics-data');
        if (!response.ok) {
            throw new Error('Failed to fetch analytics data');
        }
        return await response.json();
    } catch (error) {
        console.error('Error fetching analytics:', error);
        throw new Error('Could not retrieve analytics data');
    }
}

function generateReportPDF(analyticsData, examDetail) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('p', 'mm', 'a4');
    const pageMargins = { left: 15, right: 15 };

    // Load font
    doc.addFont('/files/DejaVuSans.ttf', 'DejaVuSans', 'normal');
    doc.setFont('DejaVuSans');

    // Title
    doc.setFontSize(18);
    doc.text('Certification Exam Results', 15, 20);
    doc.setFontSize(14);
    const subtitleY = 28;
    doc.text('Practical Module', 15, subtitleY);

    doc.setDrawColor(200, 200, 200);
    doc.line(15, subtitleY + 4, 195, subtitleY + 4);

    // Summary info
    const examinee = examDetail.Examinee || 'N/A';
    const examiner = examDetail.Examiner || 'N/A';

    const totalPoints = analyticsData.reduce((sum, item) => sum + item.Points, 0);
    const totalPossible = analyticsData.length * 4;
    const percentage = Math.round((totalPoints / totalPossible) * 100);
    const hasMishandle = analyticsData.some(item => item.Mishandle);
    const passed = !hasMishandle && percentage >= 80;

    const statusText = passed 
        ? `PASSED (${percentage}%)` 
        : `FAILED (${percentage}%)`;

    const scoreText = hasMishandle
        ? 'Test failed due to a mishandle'
        : `Total Points: ${totalPoints} out of ${totalPossible} (${percentage}%)`;

    // Info block
    let currentY = subtitleY + 14;
    const lineHeight = 7;
    doc.setFontSize(12);

    const infoLines = [
        `Examinee: ${examinee}`,
        `Examiner: ${examiner}`,
        `Status: ${statusText}`,
        scoreText
    ];
    infoLines.forEach((line, index) => {
        doc.text(line, 15, currentY + (index * lineHeight));
    });
    currentY += (infoLines.length * lineHeight) + 5;

    // Category metrics
    const categoryData = calculateCategoryMetrics(analyticsData);
    if (Object.keys(categoryData).length > 0) {
		const categoryRows = Object.entries(categoryData).map(([label, values]) => [
			label,
			`${values.obtained}/${values.total} (${values.percentage}%)`
		]);
        doc.autoTable({
            startY: currentY,
            head: [['Category', 'Score']],
            body: categoryRows,
            theme: 'grid',
            styles: { fontSize: 10, font: 'DejaVuSans' },
            margin: pageMargins
        });
    } else {
        doc.text("Category performance data not available.", 15, currentY);
        currentY += 10;
    }

    // Detailed questions
    const detailedBody = analyticsData.flatMap((item, index) => [
        [
            `${index + 1}, ID: ${item.QuestionID}`,
            item.InputType ? '✓' : '✗',
            item.ListEntry ? '✓' : '✗',
            item.Rationale ? '✓' : '✗',
            item.Disposition ? '✓' : '✗',
            {
                content: item.Mishandle ? 'Yes' : '-',
                styles: item.Mishandle ? { textColor: [255, 0, 0] } : {}
            },
            `${item.Points}/4`
        ],
        [{
            content: `Comment: ${item.Comments || 'None'}`,
            colSpan: 7,
            styles: {
                fontStyle: 'italic',
                textColor: [100, 100, 100],
                cellPadding: { top: 2, right: 5, bottom: 2, left: 5 }
            }
        }, '', '', '', '', '', '']
    ]);

    doc.autoTable({
        startY: doc.lastAutoTable ? doc.lastAutoTable.finalY + 10 : currentY,
        head: [['Question # and ID', 'Input type', 'List Entry type', 'Rationale', 'Disposition', 'Mishandle', 'Points']],
        body: detailedBody,
        theme: 'grid',
        styles: {
            fontSize: 8,
            font: 'DejaVuSans'
        },
        margin: pageMargins,
        didDrawCell: (data) => {
            if (data.row.index % 2 !== 0) {
                data.cell.styles.fillColor = [245, 245, 245];
            }
            if (data.section === 'body' && data.column.index > 0) {
                data.cell.styles.halign = 'center';
            }
            if (data.column.index === 5 && data.cell.raw?.content === 'Yes') {
                data.cell.styles.textColor = [255, 0, 0];
            }
        }
    });

    // Save
    const today = new Date();
    const formattedDate = [
        String(today.getDate()).padStart(2, '0'),
        String(today.getMonth() + 1).padStart(2, '0'),
        String(today.getFullYear()).slice(-2)
    ].join('.');

    const safeExaminee = examinee === "N/A" 
        ? "unknown_user" 
        : examinee.replace(/[^a-zA-Z0-9]/g, '');

	const generatedAt = new Date();
	const timestampStr = `Report generated on ${generatedAt.toLocaleDateString()} at ${generatedAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

	doc.setFontSize(8);
	doc.setTextColor(120);
	doc.text(timestampStr, 15, 290);

    doc.save(`cert.practical_${safeExaminee}_${formattedDate}.pdf`);
}
function calculateCategoryMetrics(analyticsData) {
    const categories = {
        'Input type': { obtained: 0, total: 0 },
        'List Entry type': { obtained: 0, total: 0 },
        'Rationale': { obtained: 0, total: 0 },
        'Disposition': { obtained: 0, total: 0 }
    };

    analyticsData.forEach(item => {
        if (item.InputType !== null) {
            categories['Input type'].obtained += item.InputType ? 1 : 0;
            categories['Input type'].total += 1;
        }
        if (item.ListEntry !== null) {
            categories['List Entry type'].obtained += item.ListEntry ? 1 : 0;
            categories['List Entry type'].total += 1;
        }
        if (item.Rationale !== null) {
            categories['Rationale'].obtained += item.Rationale ? 1 : 0;
            categories['Rationale'].total += 1;
        }
        if (item.Disposition !== null) {
            categories['Disposition'].obtained += item.Disposition ? 1 : 0;
            categories['Disposition'].total += 1;
        }
    });

    // Add percentage
    Object.keys(categories).forEach(key => {
        const entry = categories[key];
        entry.percentage = entry.total > 0
            ? Math.round((entry.obtained / entry.total) * 100)
            : 0;
    });

    return categories;
}

