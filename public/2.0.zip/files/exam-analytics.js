//exam-analytics.js

let analyticsChartInstances = [];

let analyticsTabHandler = null;
let abortController = null;

export function showExamAnalytics() {
    const modal = document.getElementById('exam-analytics-modal');
    
    // Cleanup previous instances
    if (abortController) {
        abortController.abort();
    }
    abortController = new AbortController();
    
    // Remove existing tab handler if any
    if (analyticsTabHandler) {
        modal.removeEventListener('click', analyticsTabHandler);
    }

    modal.style.display = 'block';
    
    // Load data with abort capability
    loadAnalyticsData(abortController.signal).then(data => {
        window.originalAnalyticsData = data;
		window.analyticsData = [...data];
        renderAnalyticsView('category');
    }).catch(err => {
        if (err.name !== 'AbortError') {
            console.error('Analytics load failed:', err);
        }
    });

    // Single event handler using delegation
	analyticsTabHandler = (e) => {
		const tab = e.target.closest('.analytics-tab');
		if (!tab || !window.analyticsData) return; // Add data check
		
		document.querySelectorAll('.analytics-tab').forEach(b => b.classList.remove('active'));
		tab.classList.add('active');
		renderAnalyticsView(tab.dataset.view);
	};

    modal.addEventListener('click', analyticsTabHandler, {
        signal: abortController.signal
    });
}

async function loadAnalyticsData(signal) {
    try {
        console.log('[Analytics] Starting data fetch...');
        const startTime = Date.now();
        const response = await fetch('/get-analytics-data', { signal });
        const endTime = Date.now();
        
        console.log(`[Analytics] Received response in ${endTime - startTime}ms`, {
            status: response.status,
            ok: response.ok,
            headers: [...response.headers].map(([k,v]) => `${k}: ${v}`)
        });

        if (!response.ok) {
            const errorBody = await response.text();
            console.error('[Analytics] Server response body:', errorBody);
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        console.log('[Analytics] Received data:', data);
        return data;
    } catch (error) {
        console.error('[Analytics] Full error:', error);
        alert('Failed to load analytics data. Check console for details.');
        return [];
    }
}

function renderAnalyticsView(viewType) {
    clearAllCharts();
    
    const container = document.getElementById('analytics-view-container');
    container.innerHTML = '';
    
	    if (!window.analyticsData?.length) {
        container.innerHTML = `<div class="no-data">No data available for selected filters</div>`;
        return;
    }
	
    switch(viewType) {
        case 'category':
            renderCategoryAnalysis(container);
            break;
        case 'question-type':
            renderQuestionTypeAnalysis(container);
            break;
        case 'trends':
            renderTrendAnalysis(container);
            break;
    }
}

function renderCategoryAnalysis(container) {
    // Category Distribution
    const categoryData = calculateCategoryMetrics();
    createChart(container, 'Category Distribution', 'pie', {
        labels: Object.keys(categoryData),
        datasets: [{
            label: 'Questions by Category',
            data: Object.values(categoryData).map(d => d.count),
            backgroundColor: getChartColors()
        }]
    });

    // Category Performance
    createChart(container, 'Category Performance', 'bar', {
        labels: Object.keys(categoryData),
        datasets: [{
            label: 'Correct Answers',
            data: Object.values(categoryData).map(d => d.correct),
            backgroundColor: '#4BC0C0'
        }, {
            label: 'Incorrect Answers',
            data: Object.values(categoryData).map(d => d.incorrect),
            backgroundColor: '#FF6384'
        }]
    });
}

function calculateCategoryMetrics() {
    return window.analyticsData.reduce((acc, entry) => {
        if (!acc[entry.Category]) {
            acc[entry.Category] = {
                count: 0,
                correct: 0,
                incorrect: 0,
                mishandles: 0
            };
        }
        
        acc[entry.Category].count++;
        if (entry.Mishandle) acc[entry.Category].mishandles++;
        
        const totalPossible = 4; // Input + List + Rationale + Disposition
        const score = [entry.InputType, entry.ListEntry, entry.Rationale, entry.Disposition]
            .filter(v => v).length;
            
        if (score === totalPossible) {
            acc[entry.Category].correct++;
        } else {
            acc[entry.Category].incorrect++;
        }
        
        return acc;
    }, {});
}

function renderQuestionTypeAnalysis(container) {
    const typeData = calculateQuestionTypeMetrics();
    
    createChart(container, 'Error Distribution by Question Type', 'bar', {
        labels: ['Input Type', 'List Entry', 'Rationale', 'Disposition'],
        datasets: [{
            label: 'Errors',
            data: [
                typeData.inputErrors,
                typeData.listErrors,
                typeData.rationaleErrors,
                typeData.dispositionErrors
            ],
            backgroundColor: '#FF6384'
        }]
    });
}

function calculateQuestionTypeMetrics() {
    return window.analyticsData.reduce((acc, entry) => {
        if (!entry.InputType) acc.inputErrors++;
        if (!entry.ListEntry) acc.listErrors++;
        if (!entry.Rationale) acc.rationaleErrors++;
        if (!entry.Disposition) acc.dispositionErrors++;
        return acc;
    }, { inputErrors: 0, listErrors: 0, rationaleErrors: 0, dispositionErrors: 0 });
}

function renderTrendAnalysis(container) {
    const trendData = calculateTrendMetrics();
    
    createChart(container, 'Performance Over Time', 'line', {
        labels: trendData.dates,
        datasets: [{
            label: 'Average Score (%)',
            data: trendData.avgScores,
            borderColor: '#36A2EB',
            fill: false
        }, {
            label: 'Mishandles',
            data: trendData.mishandles,
            borderColor: '#FF6384',
            fill: false
        }]
    });
}

function calculateTrendMetrics() {
    const dateMap = window.analyticsData.reduce((acc, entry) => {
        const dateObj = parseCustomDate(entry.ExamDate);
		const date = dateObj.toISOString().split('T')[0];
        if (!acc[date]) {
            acc[date] = {
                total: 0,
                correct: 0,
                mishandles: 0
            };
        }
        
        acc[date].total++;
        if (entry.Mishandle) acc[date].mishandles++;
        if ([entry.InputType, entry.ListEntry, entry.Rationale, entry.Disposition]
            .every(v => v)) {
            acc[date].correct++;
        }
        
        return acc;
    }, {});
    
    return {
        dates: Object.keys(dateMap),
        avgScores: Object.values(dateMap).map(d => (d.correct / d.total) * 100),
        mishandles: Object.values(dateMap).map(d => d.mishandles)
    };
}

function createChart(container, title, type, data) {
    const canvasContainer = document.createElement('div');
    canvasContainer.className = 'chart-container';
    canvasContainer.innerHTML = `<h3>${title}</h3><canvas></canvas>`;
    container.appendChild(canvasContainer);
    
    const ctx = canvasContainer.querySelector('canvas').getContext('2d');
    const chart = new Chart(ctx, {
        type: type,
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'top' },
                tooltip: {
                    callbacks: {
                        label: (context) => {
                            const label = context.dataset.label || '';
                            const value = context.raw || 0;
                            const total = context.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    
    analyticsChartInstances.push({ chart, container: canvasContainer });
}

function getChartColors() {
    return [
        '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0',
        '#9966FF', '#FF9F40', '#E7E9ED', '#E6194B',
        '#3CB44B', '#FFE119', '#4363D8', '#F58231',
        '#911EB4', '#46F0F0', '#F032E6', '#BCF60C',
        '#FABEBE', '#008080', '#E6BEFF', '#9A6324'
    ];
}

function clearAllCharts() {
    analyticsChartInstances.forEach(({ chart, container }) => {
        try {
            if (chart) chart.destroy();
            if (container) container.remove();
        } catch (error) {
            console.warn('Error cleaning chart:', error);
        }
    });
    analyticsChartInstances = [];
}

export function closeExamAnalytics() {
    try {
        // Abort any pending requests
        if (abortController) {
            abortController.abort();
            abortController = null;
        }
        
        // Hide modal
        const modal = document.getElementById('exam-analytics-modal');
        if (modal) modal.style.display = 'none';
        
        // Clear charts and data
        clearAllCharts();
        window.analyticsData = null;
    } catch (error) {
        console.error('Error closing analytics:', error);
    }
}

// Initialize
document.getElementById('close-exam-analytics')?.addEventListener('click', closeExamAnalytics);
document.getElementById('view-exam-analytics')?.addEventListener('click', showExamAnalytics);
document.getElementById('apply-date-filter')?.addEventListener('click', applyDateFilter);

window.addEventListener('beforeunload', () => {
    closeExamAnalytics();
    analyticsChartInstances = [];
});

export function applyDateFilter() {
    try {
        const startDate = document.getElementById('start-date').value;
        const endDate = document.getElementById('end-date').value;

        if (!startDate || !endDate) {
            alert('Please select both start and end dates');
            return;
        }

        const start = new Date(startDate);
        const end = new Date(endDate);
        start.setHours(0, 0, 0, 0);
        end.setHours(23, 59, 59, 999);

        const filteredData = window.originalAnalyticsData.filter(entry => {
            const entryDate = parseCustomDate(entry.ExamDate);
            return entryDate >= start && entryDate <= end;
        });

        window.analyticsData = filteredData;

        const activeTab = document.querySelector('.analytics-tab.active');
        if (activeTab) {
            renderAnalyticsView(activeTab.dataset.view);
        }
    } catch (error) {
        console.error('Date filter error:', error);
        alert('Error applying date filter');
    }
}

function parseCustomDate(dateString) {
    // Handle null or empty string input gracefully.
    if (!dateString) return new Date(NaN);

    // Check for the specific "DD.MM.YYYY" format which is not parsed reliably by default.
    // This makes the function backward-compatible if that format exists anywhere.
    if (dateString.includes('.')) {
        const parts = dateString.split(' ');
        const dateParts = parts[0].split('.');
        if (dateParts.length === 3) {
            const [day, month, year] = dateParts.map(Number);
            const timeParts = parts.length > 1 ? parts[1].split(':').map(Number) : [0, 0];
            
            // Create date: new Date(year, monthIndex, day, hours, minutes)
            const d = new Date(year, month - 1, day, timeParts[0] || 0, timeParts[1] || 0, timeParts[2] || 0);
            if (!isNaN(d)) return d;
        }
    }
    
    // For all other standard formats (like "YYYY-MM-DD HH:mm:ss" or full ISO 8601),
    // the modern JavaScript Date constructor is very effective and reliable.
    // This will now correctly handle the format saved in your analytics data.
    const d = new Date(dateString);
    return d;
}

