// print-results.js

document.getElementById('print-results-btn').addEventListener('click', async function() {
    const isConfirmed = confirm("The results will be permanently saved. This action cannot be reverted.\n\nProceed?");
    
    if (isConfirmed) {
        // Immediately disable the button and assessment controls
        this.style.display = 'none';
        
        const resultsModal = document.getElementById('results-modal');
        const tabId = resultsModal.dataset.assessmentTabId;

		if (tabId) {
			// **NEW: Mark the tab content as finalized IN THE STATE OBJECT**
			if (window.assessmentTabStates && window.assessmentTabStates[tabId]) {
				window.assessmentTabStates[tabId].isFinalized = true;
			}

			const tabContent = document.getElementById(`${tabId}-tab`);
			if (tabContent) {
				tabContent.dataset.finalized = 'true';
			}
			disableAssessmentTab(tabId);
		}
        
        // Then process PDF and analytics
        try {
            await generateResultsPDF();
            await sendAnalyticsData();
        } catch (error) {
            console.error("Error during print process:", error);
            alert("Error during printing process. Assessment has been finalized but data may not have been saved. Please contact support.");
        }
    } else {
        console.log("Print results action cancelled by user");
    }
});

function generateResultsPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('p', 'mm', 'a4');
    const content = document.getElementById('results-content');
	const pageMargins = { left: 15, right: 15 };

    // Load self-hosted DejaVu Sans font
    doc.addFont(
        '/files/DejaVuSans.ttf',
        'DejaVuSans',
        'normal'
    );
    doc.setFont('DejaVuSans');

    // Add title and subtitle
    doc.setFontSize(18);
    doc.text('Certification Exam Results', 15, 20);
    doc.setFontSize(14);
    const subtitleY = 20 + 8;
    doc.text('Practical Module', 15, subtitleY);
	
	// Horizontal line under subtitle
    doc.setDrawColor(200, 200, 200);
    doc.line(15, subtitleY + 4, 195, subtitleY + 4);

    // Add summary information
    const summary = content.querySelector('.result-summary');
    let examinee = "N/A", examiner = "N/A", statusText = "N/A", scoreText = "N/A";

    if (summary) {
        const examineeInfoDiv = summary.querySelector('div > div:last-child');
        if (examineeInfoDiv) {
            const examineeInfoText = examineeInfoDiv.innerText;
            const examinerMatch = examineeInfoText.match(/Examiner:\s*(.*)/);
            const examineeMatch = examineeInfoText.match(/Examinee:\s*(.*)/);
            examiner = examinerMatch ? examinerMatch[1].trim() : "N/A";
            examinee = examineeMatch ? examineeMatch[1].trim() : "N/A";
        }

        const statusH4 = summary.querySelector('h4');
        statusText = statusH4 ? statusH4.innerText : "N/A";
        
        const scoreP = summary.querySelector('p');
        scoreText = scoreP ? scoreP.innerText : "N/A";
    }

    // Add examinee information
    let currentY = subtitleY + 14;
    const lineHeight = 7;
    doc.setFontSize(12);
    
    const infoLines = [
        `Examinee: ${examinee}`,
        `Examiner: ${examiner}`,
        `Status: ${statusText}`,
        scoreText
    ];

    infoLines.forEach((line, index) => {
        doc.text(line, 15, currentY + (index * lineHeight));
    });

    // Update currentY for category table
    currentY += (infoLines.length * lineHeight) + 5;

    // Add category performance table
    const categoryData = [];
    if (summary) {
        const categoryGridContainer = summary.querySelector('div[style*="grid-template-columns"]');
        if (categoryGridContainer) {
            const categoryBlocks = categoryGridContainer.querySelectorAll('div[style*="text-align: center"]');
			Array.from(categoryBlocks).forEach(block => {
				const categoryNameElement = block.children[0];
				const scoreElement = block.children[1];

				if (categoryNameElement && scoreElement) {
					const scoreText = scoreElement.innerText;
					// Extract points from text like "3/4"
					const [obtained, total] = scoreText.split('/').map(Number);
					const percentage = total > 0 
						? Math.round((obtained / total) * 100)
						: 0;
						
					categoryData.push({
						category: categoryNameElement.innerText.trim(),
						score: `${scoreText.replace(/\n/g, ' ').trim()} (${percentage}%)`
					});
				}
			});
        }
    }
    
    if (categoryData.length > 0) {
        doc.autoTable({
            startY: currentY,
            head: [['Category', 'Score']],
            body: categoryData.map(c => [c.category, c.score]),
            theme: 'grid',
            styles: {
                fontSize: 10,
                font: 'DejaVuSans'
            },
			margin: pageMargins
        });
    } else {
        doc.text("Category performance data not available.", 15, currentY);
        currentY += 10;
    }

    // Prepare detailed results data
    const tableRows = content.querySelectorAll('tbody tr');
    const questionData = [];

    for (let i = 0; i < tableRows.length; i += 2) {
    const dataRow = tableRows[i].querySelectorAll('td');
    const commentRow = tableRows[i + 1].querySelector('td');

    if (dataRow.length === 7 && commentRow) { // Changed to 7 columns
        const dispositionCell = dataRow[4].innerText.trim();
        const mishandleCell = dataRow[5].innerText.trim(); // Mishandle moved to index 5
        const isMishandle = mishandleCell === '✓';
        
        questionData.push({
            question: dataRow[0].innerText,
            input: dataRow[1].innerText,
            list: dataRow[2].innerText,
            rationale: dataRow[3].innerText,
            disposition: dispositionCell, // Added disposition
            mishandle: {
                content: isMishandle ? 'Yes' : '-',
                styles: isMishandle ? { textColor: [255, 0, 0] } : {}
            },
            points: dataRow[6].innerText, // Points now at index 6
            comments: commentRow.innerText.replace('Comments:', '').trim()
        });
    }
}

    const detailedBody = questionData.flatMap(q => [
        [
            q.question,
            q.input,
            q.list,
            q.rationale,
			q.disposition,
            q.mishandle,
            q.points
        ],
        [{
            content: `Comment: ${q.comments}`,
            colSpan: 7,
            styles: {
                fontStyle: 'italic',
                textColor: [100, 100, 100],
                cellPadding: { top: 2, right: 5, bottom: 2, left: 5 }
            }
        }, '', '', '', '', '', '']
    ]);

    // Add detailed results table
	doc.autoTable({
		startY: doc.lastAutoTable ? doc.lastAutoTable.finalY + 10 : currentY,
		head: [['Question # and ID', 'Input type', 'List Entry type', 'Rationale', 'Disposition', 'Mishandle', 'Points']],
		body: detailedBody,
		theme: 'grid',
		styles: {
			fontSize: 8, // Slightly smaller font for denser data
			font: 'DejaVuSans'
		},
		tableWidth: 'auto', // Let the library calculate width
		margin: pageMargins,
		didDrawCell: (data) => {
			if (data.row.index % 2 !== 0 && data.cell.raw.colSpan === 6) {
				data.cell.styles.fillColor = [245, 245, 245];
			}
			if (data.section === 'body' && data.column.index !== 0) {
				data.cell.styles.halign = 'center';
			}
		}
	});

    // Generate filename
    const today = new Date();
    const formattedDate = [
        String(today.getDate()).padStart(2, '0'),
        String(today.getMonth() + 1).padStart(2, '0'),
        String(today.getFullYear()).slice(-2)
    ].join('.');
    
    const safeExaminee = examinee === "N/A" 
        ? "unknown_user" 
        : examinee.replace(/[^a-zA-Z0-9]/g, '');
    
    doc.save(`cert.practical_${safeExaminee}_${formattedDate}.pdf`);
}

async function sendAnalyticsData() {
    try {
        // 1. Validate core elements
        const resultsContent = document.getElementById('results-content');
        if (!resultsContent) throw new Error('Results content container missing');
        
        // 2. Validate and normalize exam details
        const currentExamDetail = window.currentExamDetail || {};
        console.log('Raw Exam Detail:', JSON.parse(JSON.stringify(currentExamDetail)));

        // Normalize questions array format
        const questionsArray = Array.isArray(currentExamDetail.Questions) 
            ? currentExamDetail.Questions 
            : typeof currentExamDetail.Questions === 'string'
                ? currentExamDetail.Questions.split(',').map(q => q.trim())
                : [];
        
        if (questionsArray.length === 0) {
            throw new Error('No questions found in exam details');
        }

        console.log('Normalized Questions:', questionsArray);

        // 3. Get DOM references
        const results = Array.from(resultsContent.querySelectorAll('tbody tr'))
		.filter(tr => {
			// Exclude rows with comment cells (colspan="7")
			return !tr.querySelector('td[colspan="7"]');
		});
        const commentRows = Array.from(resultsContent.querySelectorAll('tbody tr'))
		.filter(tr => tr.querySelector('td[colspan="7"]'));
        const totalPointsElement = resultsContent.querySelector('.result-summary p');

        console.log('DOM Elements:', {
            resultsCount: results.length,
            commentRowsCount: commentRows.length,
            totalPointsElementExists: !!totalPointsElement,
            metadataStoreCount: metadataStore.length
        });

        // 4. Construct payload with validation
        const payload = {
            examId: currentExamDetail.ExamID || 'unknown-exam-id',
            examineeId: currentExamDetail.Examinee || 'unknown-examinee',
            examiner: currentExamDetail.Examiner || 'unknown-examiner',
            examDate: currentExamDetail.Timestamp || new Date().toISOString(),
            totalPoints: parseInt(totalPointsElement?.textContent?.match(/\d+/)?.[0]) || 0,
            questions: questionsArray.map((questionId, index) => {
                const resultRow = results[index];
                if (!resultRow) {
                    throw new Error(`Missing result row for question ${index + 1} (ID: ${questionId})`);
                }

                const cells = resultRow.querySelectorAll('td');
                if (cells.length < 7) {
                    console.error('Malformed row:', {
                        index,
                        questionId,
                        cellCount: cells.length,
                        rowHTML: resultRow.outerHTML
                    });
                    throw new Error(`Question ${index + 1} (${questionId}) has incomplete data`);
                }

                // Get metadata with fallbacks
                const meta = metadataStore.find(m => m.id === questionId) || {};
                
                return {
                    id: questionId,
                    inputType: cells[1].textContent.trim() === '✓',
                    listEntry: cells[2].textContent.trim() === '✓',
                    rationale: cells[3].textContent.trim() === '✓',
                    disposition: cells[4].textContent.trim() === '✓',
                    mishandle: cells[5].textContent.trim() === '✓',
                    points: parseInt(cells[6].textContent) || 0,
                    comments: commentRows[index]?.querySelector('td')?.textContent
						.replace('Comments:', '')
						.trim() || '',
                    category: meta.category || 'Unknown',
                    difficulty: meta.difficulty || 'Unknown'
                };
            })
        };

        // 5. Final validation and logging
        console.log('Analytics Payload:', JSON.parse(JSON.stringify(payload)));
        
        if (payload.questions.length !== questionsArray.length) {
            throw new Error(`Question count mismatch (${payload.questions.length} vs ${questionsArray.length})`);
        }

        const response = await fetch('/save-analytics', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('Server Response:', errorText);
            throw new Error(`Server error: ${errorText}`);
        }
        
        console.log('Analytics successfully saved');
    } catch (err) {
        console.error('Analytics Failed:', {
            error: err,
            currentExamDetail: window.currentExamDetail,
            metadataStoreSample: metadataStore.slice(0, 3),
            domSnapshot: document.getElementById('results-content')?.outerHTML?.slice(0, 1000)
        });
        alert(`Failed to save analytics: ${err.message}`);
    }
}