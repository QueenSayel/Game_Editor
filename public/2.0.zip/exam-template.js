<#
.SYNOPSIS
    Secure Exam App Launcher with a persistent 90-minute timer.
.DESCRIPTION
    This script is a template for generating self-contained PowerShell exam launchers.
    The exam content is encrypted and decrypted at runtime to prevent casual inspection.
#>

# --- 1. DECRYPTION BLOCK: Decrypts the exam payload at runtime ---
# These variables contain the encrypted exam and the necessary keys for decryption.
# They are intentionally given innocuous names.
$payload = @'
<!-- ENCRYPTED_HTML_HERE -->
'@
$integrityVector = "<!-- IV_HERE -->"
$systemEntropy = "<!-- KEY_HERE -->"

$examHTML = '' # This variable will hold the decrypted HTML content.

try {
    # Create an AES cryptography object
    $aes = New-Object System.Security.Cryptography.AesManaged
    $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7

    # Convert the Base64 key and IV back to byte arrays
    $aes.Key = [System.Convert]::FromBase64String($systemEntropy)
    $aes.IV = [System.Convert]::FromBase64String($integrityVector)

    # Create a decryptor
    $decryptor = $aes.CreateDecryptor($aes.Key, $aes.IV)

    # Convert the Base64 payload string to a byte array
    $encryptedBytes = [System.Convert]::FromBase64String($payload)

    # Decrypt the bytes
    $decryptedBytes = $decryptor.TransformFinalBlock($encryptedBytes, 0, $encryptedBytes.Length)
    
    # Dispose of the crypto objects
    $decryptor.Dispose()
    $aes.Dispose()

    # Convert the decrypted bytes back into a readable HTML string
    $examHTML = [System.Text.Encoding]::UTF8.GetString($decryptedBytes)

} catch {
    Write-Host "FATAL ERROR: Could not decrypt the exam payload. The file may be corrupt." -ForegroundColor Red
    Write-Host "Error details: $($_.Exception.Message)"
    Read-Host "Press ENTER to exit."
    exit 1
}

# If decryption fails, $examHTML will be empty, and the server will fail to start correctly.

# --- 2. SCRIPT LOGIC: Start a ONE-SHOT server, launch Edge, and exit ---
$port = 8089 
$url = "http://localhost:$port/"
$webServerJob = $null
try {
    Write-Host "Preparing secure exam environment..." -ForegroundColor Green
    $webServerJob = Start-Job -ScriptBlock { param($localUrl, $htmlContent)
        $listener = New-Object System.Net.HttpListener; $listener.Prefixes.Add($localUrl)
        try {
            $listener.Start(); Write-Output "SERVER_READY"
            $context = $listener.GetContext()
            $response = $context.Response
            if ($context.Request.RawUrl -eq "/favicon.ico") { $response.StatusCode = 404 } 
            else { $buffer = [System.Text.Encoding]::UTF8.GetBytes($htmlContent); $response.ContentLength64 = $buffer.Length; $response.OutputStream.Write($buffer, 0, $buffer.Length) }
            $response.OutputStream.Close()
        } finally { if ($listener -and $listener.IsListening) { $listener.Stop() } }
    } -ArgumentList $url, $examHTML
    Write-Host "Waiting for secure exam environment to start..." -ForegroundColor Green
    $serverReady = $false; $timeout = New-TimeSpan -Seconds 10; $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    while (-not $serverReady -and $stopwatch.Elapsed -lt $timeout) {
        if ((Receive-Job -Job $webServerJob) -contains "SERVER_READY") { Write-Host "Ready." -ForegroundColor Green; $serverReady = $true } 
        else { Start-Sleep -Milliseconds 250 }
    }
    if (-not $serverReady) { throw "Background server failed to start within the timeout period." }
    Write-Host "Preparing exam content..." -ForegroundColor Cyan
    Start-Process msedge.exe -ArgumentList "--app=`"$url`" --disable-dev-tools"
    Write-Host "Waiting for browser to load Exam content..." -ForegroundColor Cyan
    $webServerJob | Wait-Job -Timeout 20 | Out-Null
    if ($webServerJob.State -ne 'Completed') { throw "Server job failed to complete. Browser may not have loaded the exam. Status: $($webServerJob.State)" }
    Write-Host "Exam content delivered." -ForegroundColor Cyan
} catch {
    Write-Host "An error occurred: $($_.Exception.Message)" -ForegroundColor Red
    if ($webServerJob) { Receive-Job $webServerJob }
    Read-Host "Press ENTER to close this window."
} finally {
    if ($webServerJob) {
        Write-Host "Post-process cleanup..."
        Stop-Job -Job $webServerJob -PassThru | Remove-Job -Force
    }
    Write-Host "Secure exam environment ready." -ForegroundColor Green
    Start-Sleep -Seconds 3
}