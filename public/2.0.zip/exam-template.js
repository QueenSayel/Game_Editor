<#
.SYNOPSIS
    Secure Exam App Launcher with a persistent 90-minute timer.
.DESCRIPTION
    This script is a template for generating self-contained PowerShell exam launchers.
    The exam content is encrypted and decrypted at runtime to prevent casual inspection.
#>

# --- 1. DECRYPTION BLOCK: Decrypts the exam payload at runtime ---
# These variables contain the encrypted exam and the necessary keys for decryption.
# They are intentionally given innocuous names.
$payload = @'
<!-- ENCRYPTED_HTML_HERE -->
'@
$integrityVector = "<!-- IV_HERE -->"
$systemEntropy = "<!-- KEY_HERE -->"

$examHTML = '' # This variable will hold the decrypted HTML content.

try {
    # Create an AES cryptography object
    $aes = New-Object System.Security.Cryptography.AesManaged
    $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7

    # Convert the Base64 key and IV back to byte arrays
    $aes.Key = [System.Convert]::FromBase64String($systemEntropy)
    $aes.IV = [System.Convert]::FromBase64String($integrityVector)

    # Create a decryptor
    $decryptor = $aes.CreateDecryptor($aes.Key, $aes.IV)

    # Convert the Base64 payload string to a byte array
    $encryptedBytes = [System.Convert]::FromBase64String($payload)

    # Decrypt the bytes
    $decryptedBytes = $decryptor.TransformFinalBlock($encryptedBytes, 0, $encryptedBytes.Length)
    
    # Dispose of the crypto objects
    $decryptor.Dispose()
    $aes.Dispose()

    # Convert the decrypted bytes back into a readable HTML string
    $examHTML = [System.Text.Encoding]::UTF8.GetString($decryptedBytes)

} catch {
    Write-Host "FATAL ERROR: Could not decrypt the exam payload. The file may be corrupt." -ForegroundColor Red
    Write-Host "Error details: $($_.Exception.Message)"
    Read-Host "Press ENTER to exit."
    exit 1
}

# If decryption fails, $examHTML will be empty, and the server will fail to start correctly.

# --- 2. SCRIPT LOGIC: Start a PERSISTENT server, launch Edge, and manage state ---
$port = 8089 
$url = "http://localhost:$port/"
# Extract the examId from the decrypted HTML to use in file paths and keys.
# This avoids having to pass it around as a separate variable.
$examId = "<!-- EXAM_ID_RAW_HERE -->"

# Define a secure, non-obvious path for the progress file.
$progressDir = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) "CertOSExam"
if (-not (Test-Path $progressDir)) { New-Item -ItemType Directory -Path $progressDir | Out-Null }
$progressFilePath = Join-Path $progressDir "$($examId).dat"

# --- Helper functions for encryption/decryption of the progress file ---
# We use one of the existing unique values (the original IV) as a salt to derive a key,
# ensuring the progress file's encryption is unique to this specific exam instance.
function Get-ProgressCryptoKeys {
    param($salt, $keyMaterial)
    $hmac = New-Object System.Security.Cryptography.HMACSHA256
    $hmac.Key = [System.Text.Encoding]::UTF8.GetBytes($salt)
    $hashBytes = $hmac.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($keyMaterial))
    # Split the 32-byte hash into a 16-byte key and a 16-byte IV for AES-128.
    $key = $hashBytes[0..15]; $iv = $hashBytes[16..31]
    $hmac.Dispose()
    return @{ Key = $key; IV = $iv }
}

function Encrypt-Progress {
    param($stringData, [byte[]]$key, [byte[]]$iv)
    $aes = New-Object System.Security.Cryptography.AesManaged; $aes.Mode = 'CBC'; $aes.Padding = 'PKCS7'; $aes.Key = $key; $aes.IV = $iv
    $encryptor = $aes.CreateEncryptor()
    $clearTextBytes = [System.Text.Encoding]::UTF8.GetBytes($stringData)
    $encryptedBytes = $encryptor.TransformFinalBlock($clearTextBytes, 0, $clearTextBytes.Length)
    $aes.Dispose()
    return [System.Convert]::ToBase64String($encryptedBytes)
}

function Decrypt-Progress {
    param($base64String, [byte[]]$key, [byte[]]$iv)
    $aes = New-Object System.Security.Cryptography.AesManaged; $aes.Mode = 'CBC'; $aes.Padding = 'PKCS7'; $aes.Key = $key; $aes.IV = $iv
    $decryptor = $aes.CreateDecryptor()
    $encryptedBytes = [System.Convert]::FromBase64String($base64String)
    $decryptedBytes = $decryptor.TransformFinalBlock($encryptedBytes, 0, $encryptedBytes.Length)
    $aes.Dispose()
    return [System.Text.Encoding]::UTF8.GetString($decryptedBytes)
}


# --- Main Server ---
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($url)

$lastHeartbeatTime = [datetime]::UtcNow
$heartbeatLock = New-Object System.Object

try {
    $listener.Start()
    Write-Host "Secure Exam Environment is now running." -ForegroundColor Green
	Write-Host "Do not close this window manually." -ForegroundColor Cyan
    # Launch the browser to the exam URL
    Start-Process msedge.exe -ArgumentList "--app=`"$url`" --disable-dev-tools"

    # Start listening for the first request asynchronously.
    $getContextTask = $listener.GetContextAsync()
    # Give the browser time to launch and send its first ping.
    $initialGracePeriodEnd = (Get-Date).AddSeconds(15)

    # This loop is non-blocking. It checks for requests and for timeouts.
    while ($listener.IsListening) {
        
        # Check for heartbeat timeout
        $isTimedOut = $false
        if ((Get-Date) -gt $initialGracePeriodEnd) {
            [System.Threading.Monitor]::Enter($heartbeatLock)
            try {
                if (([datetime]::UtcNow - $lastHeartbeatTime).TotalSeconds -gt 4) {
                    $isTimedOut = $true
                }
            } finally {
                [System.Threading.Monitor]::Exit($heartbeatLock)
            }
        }

        if ($isTimedOut) {
            Write-Host "Shutting down Secure Exam Environment..." -ForegroundColor Cyan
            $listener.Stop()
            break # Exit the while loop
        }

        # Check if a web request has arrived
        if ($getContextTask.IsCompleted) {
            $context = $getContextTask.GetAwaiter().GetResult()
            $request = $context.Request; $response = $context.Response
            $localPath = $request.Url.LocalPath

            try {
                switch ($localPath) {
                    '/' {
                        $buffer = [System.Text.Encoding]::UTF8.GetBytes($examHTML); $response.ContentType = 'text/html'
                        $response.ContentLength64 = $buffer.Length; $response.OutputStream.Write($buffer, 0, $buffer.Length)
                    }
                    '/heartbeat' {
                        [System.Threading.Monitor]::Enter($heartbeatLock)
                        try {
                            $lastHeartbeatTime = [datetime]::UtcNow
                        } finally {
                            [System.Threading.Monitor]::Exit($heartbeatLock)
                        }
                        $response.StatusCode = 204
                    }
                    '/load-progress' {
                        $progressJson = '{}'
                        if (Test-Path $progressFilePath) {
                            try {
                                $cryptoKeys = Get-ProgressCryptoKeys -salt $integrityVector -keyMaterial $examId
                                $encryptedContent = Get-Content $progressFilePath -Raw
                                if (-not [string]::IsNullOrWhiteSpace($encryptedContent)) {
                                    $progressJson = Decrypt-Progress -base64String $encryptedContent -key $cryptoKeys.Key -iv $cryptoKeys.IV
                                }
                            } catch { Write-Warning "Could not decrypt progress file. Error: $($_.Exception.Message)" }
                        }
                        $buffer = [System.Text.Encoding]::UTF8.GetBytes($progressJson); $response.ContentType = 'application/json'
                        $response.ContentLength64 = $buffer.Length; $response.OutputStream.Write($buffer, 0, $buffer.Length)
                    }
                    '/save-progress' {
                        $reader = New-Object System.IO.StreamReader($request.InputStream, $request.ContentEncoding)
                        $jsonPayload = $reader.ReadToEnd(); $reader.Dispose()
                        try {
                            $cryptoKeys = Get-ProgressCryptoKeys -salt $integrityVector -keyMaterial $examId
                            $encryptedPayload = Encrypt-Progress -stringData $jsonPayload -key $cryptoKeys.Key -iv $cryptoKeys.IV
                            Set-Content -Path $progressFilePath -Value $encryptedPayload -Encoding ASCII
                            $response.StatusCode = 200
                        } catch { $response.StatusCode = 500; Write-Warning "Failed to save progress: $($_.Exception.Message)" }
                    }
                    default { $response.StatusCode = 404 }
                }
            } catch {
                Write-Warning "Error processing request: $($_.Exception.Message)"; $response.StatusCode = 500
            } finally {
                if ($response.OutputStream.CanWrite) { $response.OutputStream.Close() }
            }
            
            # Start listening for the NEXT request.
            if ($listener.IsListening) {
                $getContextTask = $listener.GetContextAsync()
            }
        }

        # Sleep for a tiny amount of time to prevent the loop from using 100% CPU.
        Start-Sleep -Milliseconds 50
    }

} catch {
    # This block will catch any unexpected fatal errors.
    Write-Host "A fatal server error occurred: $($_.Exception.Message)" -ForegroundColor Red
} finally {
    # Simplified cleanup.
    if ($listener -and $listener.IsListening) { $listener.Stop() }
    Write-Host "Secure Exam Environment has been shut down." -ForegroundColor Green
}