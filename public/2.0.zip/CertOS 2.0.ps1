# =================================================================================
# CertOS Server with JSON Backend - v2.0
#
# This script is a complete replacement for the original Excel-based backend.
# It uses a fast, native JSON file-based database for all data storage.
#
# --- FEATURES ---
# - NO EXCEL: Completely removes the dependency on slow and unreliable Excel COM automation for data storage.
# - SELF-INITIALIZING: Automatically creates the 'data' directory and required empty JSON files on first run.
# - THREAD-SAFE: Uses a file lock to prevent data corruption from simultaneous web requests.
# - API COMPATIBLE: All API endpoints are identical to the original, requiring ZERO frontend changes.
# - HIGH PERFORMANCE: Reading/writing JSON files is significantly faster than automating Excel.
# - ROBUST: Eliminates errors related to hung EXCEL.EXE processes.
#
# --- HOW TO DEPLOY ---
# 1. Save this entire code as 'server.ps1'.
# 2. Ensure all other required files ('index.html', 'Questions_Practical.docm', etc.) are in the same directory.
# 3. Run the script. It will handle the rest.
# =================================================================================

# --- Core Configuration ---
$rootPath = $PSScriptRoot
$url = 'http://localhost:3030/'
$tempDir = Join-Path $env:TEMP "docxserver"
$serverSalt = "a9d8f7b2c3e4a5b6d7c8e9f0a1b2c3d4e5f6a7b8c9d0e1f2"
# --- JSON Database Configuration ---
$dataPath = Join-Path $rootPath "data"
$examsPath = Join-Path $dataPath "exams.json"
$presetsPath = Join-Path $dataPath "presets.json"
$answersPath = Join-Path $dataPath "answers.json"
$analyticsPath = Join-Path $dataPath "analytics.json"
$alertsPath = Join-Path $dataPath "alerts.json"
$responsesPath = Join-Path $dataPath "responses.json"
$jsonFiles = @($examsPath, $presetsPath, $answersPath, $analyticsPath, $alertsPath, $responsesPath)

# Global lock object for thread-safe file access
$fileLock = New-Object System.Object

# --- Self-Initialization: Ensure directories and database files exist ---
if (-not (Test-Path $tempDir)) { New-Item -ItemType Directory -Path $tempDir | Out-Null }
if (-not (Test-Path $dataPath)) {
    Write-Host "Creating 'data' directory for JSON database..."
    New-Item -ItemType Directory -Path $dataPath | Out-Null
}
foreach ($file in $jsonFiles) {
    if (-not (Test-Path $file)) {
        Write-Host "Creating empty database file: $(Split-Path $file -Leaf)"
        '[]' | Set-Content -Path $file -Encoding UTF8
    }
}

# --- Start HTTP Listener ---
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($url)
$listener.Start()

Write-Host "Serving at $url..."
Write-Host "Using native JSON database from '$dataPath'."
Write-Host "Press CTRL+C to stop..."

# --- Helper Functions ---
function Send-ErrorResponse {
    param([System.Net.HttpListenerResponse]$Response, [int]$StatusCode, [string]$Message)
    $response.StatusCode = $StatusCode
    $buffer = [System.Text.Encoding]::UTF8.GetBytes($Message)
    $response.ContentLength64 = $buffer.Length
    $response.OutputStream.Write($buffer, 0, $buffer.Length)
}

function Send-JsonResponse {
    param([System.Net.HttpListenerResponse]$Response, [object]$Data, [int]$Depth = 10)
    $json = $Data | ConvertTo-Json -Compress -Depth $Depth
    $buffer = [System.Text.Encoding]::UTF8.GetBytes($json)
    $response.ContentType = 'application/json'
    $response.ContentLength64 = $buffer.Length
    $response.OutputStream.Write($buffer, 0, $buffer.Length)
}

function Get-ShortId {
    param([int]$Length = 6)
    # Using a character set that avoids ambiguous characters like I, O, 1, 0
    $charSet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    # Generate and join random characters by first converting the string to a character array
    $id = -join (0..($Length - 1) | ForEach-Object { Get-Random -InputObject ([char[]]$charSet) })
    return $id
}

# --- Main Server Loop ---
try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        try {
            $localPath = $request.Url.LocalPath.TrimStart('/')
            $filePath = Join-Path $rootPath $localPath

            if ($localPath -eq '') {
                $content = [System.IO.File]::ReadAllText((Join-Path $rootPath 'index.html'))
                $buffer = [System.Text.Encoding]::UTF8.GetBytes($content)
                $response.ContentType = 'text/html'
            }
            elseif ($localPath -eq 'Questions_Practical.docm') {
                $sourceFile = Join-Path $rootPath $localPath
                if (-not (Test-Path $sourceFile)) { Send-ErrorResponse $response 404 "File not found"; continue }

                $tempFileName = "Questions_Practical_temp_$([System.Guid]::NewGuid().ToString()).docm"
                $tempFilePath = Join-Path $tempDir $tempFileName
                try {
                    Copy-Item -Path $sourceFile -Destination $tempFilePath -Force
                    $buffer = [System.IO.File]::ReadAllBytes($tempFilePath)
                    $response.ContentType = 'application/vnd.ms-word.document.macroEnabled.12'
                }
                catch { Send-ErrorResponse $response 503 "Unable to read or copy the document: $($_.Exception.Message)"; continue }
                finally {
                    Start-Sleep -Milliseconds 500
                    if (Test-Path $tempFilePath) { Remove-Item $tempFilePath -ErrorAction SilentlyContinue }
                }
            }
			elseif ($localPath -eq 'generate-exam' -and $request.HttpMethod -eq 'POST') {
				try {
					$reader = New-Object System.IO.StreamReader($request.InputStream)
					$data = $reader.ReadToEnd() | ConvertFrom-Json
					
					if (-not $data.alertIDs -or $data.alertIDs.Count -eq 0) { Send-ErrorResponse $response 400 "No alerts specified"; continue }
					if (-not $data.examiner -or -not $data.examinee) { Send-ErrorResponse $response 400 "Missing required fields"; continue }

					$examId = [Guid]::NewGuid().ToString()
					$safeExaminee = $data.examinee -replace '[^a-zA-Z0-9]', ''
					if (-not $safeExaminee) { $safeExaminee = "unknown_user" }
					$formattedDate = Get-Date -Format 'dd.MM.yy'

					$newExamFileName = "cert.practical.exam_${safeExaminee}_${formattedDate}.bat"
					$targetDir = Join-Path $rootPath "Exams\$safeExaminee"
					if (-not (Test-Path $targetDir)) { New-Item -ItemType Directory -Path $targetDir -Force | Out-Null }
					
					$pdfPath = Join-Path $targetDir $newExamFileName
					$webPathForLog = "Exams/$safeExaminee/$newExamFileName"
					
					# --- START: New PowerShell Exam Generation Logic (Replaces Word COM Automation) ---
					try {
					# 1. Read the new exam-template.js which contains the decryption logic
					$templateContent = Get-Content (Join-Path $rootPath "exam-template.js") -Raw
					
					# 2. Get the alerts data
					$allAlerts = Get-Content $alertsPath -Raw | ConvertFrom-Json
					$alertsLookup = $allAlerts | Group-Object -Property id -AsHashTable
					$selectedAlerts = foreach ($id in $data.alertIDs) {
                        $alertsLookup[$id]
                    }

					# 3. Build the HTML body for the exam questions
					$htmlBody = [System.Text.StringBuilder]::new()
					$questionCounter = 1
					
					# Define dropdown options once
					$placeholderOption = '<option value="" selected disabled>Select an option...</option>'
					$dropdownOptions = "$placeholderOption<option>Individual</option><option>Entity</option><option>Vessel/Aircraft</option><option>Place</option><option>Other</option><option>Unknown</option>"
					$dispositionOptions = "$placeholderOption<option>False Match</option><option>Positive Match - Out of Scope</option><option>Positive Match - License or Exempt</option>"

					foreach ($alert in $selectedAlerts) {
						[void]$htmlBody.AppendLine("<div class='exam-question' id='question-$($questionCounter)' data-id='$($alert.id)'>")
						[void]$htmlBody.AppendLine("<h3>Alert #$($questionCounter) [ID: $($alert.id)]</h3>")
						[void]$htmlBody.AppendLine("<div class='alert-content' style='padding:15px; display: table; margin-left: auto; margin-right: auto; margin-bottom: 20px; text-align: left;'>$($alert.content)</div>")
						[void]$htmlBody.AppendLine("<div class='controls-grid' style='grid-template-columns: 1fr 1fr 1fr; gap: 15px;'>")
						[void]$htmlBody.AppendLine("<div class='control-group'><label>Input Type:</label><select class='input-type-select'>$($dropdownOptions)</select></div>")
						[void]$htmlBody.AppendLine("<div class='control-group'><label>List Entry Type:</label><select class='list-entry-select'>$($dropdownOptions)</select></div>")
						[void]$htmlBody.AppendLine("<div class='control-group'><label>Disposition:</label><select class='disposition-select'>$($dispositionOptions)</select></div>")
						[void]$htmlBody.AppendLine("</div>")
						[void]$htmlBody.AppendLine("<div class='control-group' style='margin-top: 20px;'><label>Rationale:</label><textarea placeholder='Rationale...'></textarea></div>")
						[void]$htmlBody.AppendLine("</div>")
						$questionCounter++
					}

					# 4. Construct the FULL cleartext HTML document from the .original template file
					$originalTemplateContent = Get-Content (Join-Path $rootPath "exam-template.js.original") -Raw
					# Extract just the HTML part from the PowerShell here-string, which preserves the <head>
					$htmlShell = ($originalTemplateContent -split "'@")[0] -split "@'", 2 | Select-Object -Last 1

					$clearTextHtml = $htmlShell.Replace("<!-- QUESTION_CONTENT_HERE -->", $htmlBody.ToString())
					$clearTextHtml = $clearTextHtml.Replace("<!-- EXAM_ID_HERE -->", $examId)
					$clearTextHtml = $clearTextHtml.Replace("<!-- EXAMINEE_HERE -->", $data.examinee)


					# 5. --- ENCRYPTION LOGIC ---
					$aes = New-Object System.Security.Cryptography.AesManaged
					$aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
					$aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
					$aes.GenerateKey()
					$aes.GenerateIV()
					
					$encryptor = $aes.CreateEncryptor($aes.Key, $aes.IV)
					$clearTextBytes = [System.Text.Encoding]::UTF8.GetBytes($clearTextHtml)
					$encryptedBytes = $encryptor.TransformFinalBlock($clearTextBytes, 0, $clearTextBytes.Length)
					
					# Convert the encrypted data and keys to Base64 strings for embedding
					$encryptedPayload_Base64 = [System.Convert]::ToBase64String($encryptedBytes)
					$key_Base64 = [System.Convert]::ToBase64String($aes.Key)
					$iv_Base64 = [System.Convert]::ToBase64String($aes.IV)
					
					$encryptor.Dispose()
					$aes.Dispose()

					# 6. Inject the encrypted data and keys into the new template
					$finalScriptContent = $templateContent.Replace('<!-- ENCRYPTED_HTML_HERE -->', $encryptedPayload_Base64)
					$finalScriptContent = $finalScriptContent.Replace('<!-- KEY_HERE -->', $key_Base64)
					$finalScriptContent = $finalScriptContent.Replace('<!-- IV_HERE -->', $iv_Base64)
					$finalScriptContent = $finalScriptContent.Replace('<!-- EXAM_ID_RAW_HERE -->', $examId)
					# 7. --- CLEAN HYBRID BATCH/POWERSHELL PACKAGING ---
					# This header is a clean batch script. It executes a PowerShell command
					# that reads this very file, skips the batch header, and runs the rest.
					$batchHeader = @"
@echo off
title Secure Exam Environment
powershell.exe -ExecutionPolicy Bypass -NoProfile -Command "Invoke-Expression (Get-Content -Path '%~f0' | Select-Object -Skip 4 | Out-String)"
exit /b
"@

					# Combine the clean batch header with the actual PowerShell script content.
					# The PowerShell script content will start on line 5 of the file.
					$hybridScriptContent = $batchHeader + "`r`n" + $finalScriptContent

					# Save the final hybrid .bat file using ASCII encoding. This prevents the
					# UTF-8 BOM that confuses cmd.exe.
					$hybridScriptContent | Set-Content -Path $pdfPath -Encoding ASCII
					
					Write-Host "Clean hybrid exam batch file successfully generated: $pdfPath"

				} catch {
					Write-Host "ERROR generating PowerShell script: $($_.Exception.Message)" -ForegroundColor Red
					Send-ErrorResponse $response 500 "Exam script generation failed: $($_.Exception.Message)"
					continue
				}
					# --- END: New PowerShell Exam Generation Logic ---

					# --- JSON Logging ---
					[System.Threading.Monitor]::Enter($fileLock)
					try {
						$parsedData = $null
						if (Test-Path $examsPath -PathType Leaf) {
							$fileContent = Get-Content $examsPath -Raw
							if (-not [string]::IsNullOrWhiteSpace($fileContent)) {
								$parsedData = $fileContent | ConvertFrom-Json
							}
						}
						$exams = @($parsedData)

						$newExamEntry = [PSCustomObject]@{
							ExamID     = $examId
							Timestamp  = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
							Examiner   = $data.examiner
							Examinee   = $data.examinee
							Comment    = $data.comment
							Questions  = ($data.alertIDs -join ', ') 
							PDFFile    = $webPathForLog
						}
						
						$exams += $newExamEntry
						
						ConvertTo-Json -InputObject $exams -Depth 5 | Set-Content -Path $examsPath -Encoding UTF8
						
						Write-Host "Exam record saved to exams.json"
					} finally { 
						[System.Threading.Monitor]::Exit($fileLock) 
					}

					$response.StatusCode = 200
					$response.StatusDescription = "OK"
				}
				catch {
					Write-Host "ERROR: $($_.Exception.Message)"
					Send-ErrorResponse $response 500 "Exam generation failed: $($_.Exception.Message)"
					if ($pdfPath -and (Test-Path $pdfPath)) { Remove-Item $pdfPath -Force }
				}
				continue
			}
            # --- Serve files ---
            elseif ($localPath -match '^Exams/.+?/.+\.(?:pdf|bat)$') {
                if (Test-Path $filePath -PathType Leaf) {
                    # This logic now runs for both GET and HEAD requests.
                    $buffer = [System.IO.File]::ReadAllBytes($filePath)
                    $response.ContentLength64 = $buffer.Length # Set the length header

                    $response.ContentType = switch -Wildcard ($localPath) {
                        "*.svg" { "image/svg+xml" } "*.png" { "image/png" } "*.jpg" { "image/jpeg" }
                        "*.css" { "text/css" }      "*.js"  { "text/javascript" }
                        "*.bat" { "application/octet-stream" }
                        default { "application/octet-stream" }
                    }

                    # --- START OF THE FIX ---
                    # Only write the file's content if the request is NOT a HEAD request.
                    if ($request.HttpMethod -ne 'HEAD') {
                        $response.OutputStream.Write($buffer, 0, $buffer.Length)
                    }
                    # --- END OF THE FIX ---

                } else { Send-ErrorResponse $response 404 "File not found."; continue }
				continue
            }
            # --- Get All Exam Details ---
            elseif ($localPath -eq 'list-exam-details' -and $request.HttpMethod -eq 'GET') {
                try {
                    [System.Threading.Monitor]::Enter($fileLock)
                    $examData = Get-Content $examsPath -Raw | ConvertFrom-Json
                    Send-JsonResponse $response $examData
                } catch { Send-ErrorResponse $response 500 "Failed to read exam details: $($_.Exception.Message)" }
                finally { if ([System.Threading.Monitor]::IsEntered($fileLock)) { [System.Threading.Monitor]::Exit($fileLock) } }
                continue
            }
			# --- Save Preset ---
			elseif ($localPath -eq 'save-preset' -and $request.HttpMethod -eq 'POST') {
				# LOG: Indicate that the endpoint has been hit.
				Write-Host "--- [$(Get-Date)] Received POST request for /save-preset ---"
				try {
					# LOG: Show the raw incoming data from the request body.
					$rawRequestData = (New-Object System.IO.StreamReader($request.InputStream)).ReadToEnd()
					Write-Host "[LOG] Raw request body: $rawRequestData"

					$data = $rawRequestData | ConvertFrom-Json
					# LOG: Show the data after it has been parsed into a PowerShell object.
					Write-Host "[LOG] Parsed data object: $($data | ConvertTo-Json -Depth 5)"

					$presetId = [Guid]::NewGuid().ToString()
					Write-Host "[LOG] Generated new PresetID: $presetId"

					[System.Threading.Monitor]::Enter($fileLock)
					try {
						# Initialize presets as an empty array
						$presets = @()
						
						# Read existing presets if the file exists and has content
						if (Test-Path $presetsPath -PathType Leaf) {
							Write-Host "[LOG] Presets file found at: $presetsPath"
							$fileContent = Get-Content $presetsPath -Raw
							if (-not [string]::IsNullOrWhiteSpace($fileContent)) {
								Write-Host "[LOG] Reading existing file content: $fileContent"
								$parsedData = $fileContent | ConvertFrom-Json
								$presets = @($parsedData)  # Ensure it's an array
								Write-Host "[LOG] Loaded $($presets.Count) existing presets into array."
							} else {
								Write-Host "[LOG] Presets file is empty. Starting with an empty array."
							}
						} else {
							Write-Host "[LOG] Presets file not found. Starting with an empty array."
						}
						
						# Create and append the new preset
						$newPreset = [PSCustomObject]@{
							PresetID      = $presetId
							Name          = $data.presetName
							Timestamp     = (Get-Date -Format "o")
							QuestionCount = $data.questionCount
							Conditions    = $data.conditions
						}
						Write-Host "[LOG] Created new preset object: $($newPreset | ConvertTo-Json -Depth 5)"
						
						$presets += $newPreset
						Write-Host "[LOG] Appended new preset. Array now contains $($presets.Count) items."
						
						# LOG: CRITICAL - Log the exact JSON that is about to be written to the file.
						# This will confirm if your -AsArray fix is working as expected.
						$jsonToWrite = ConvertTo-Json -InputObject $presets -Depth 5
						Write-Host "[LOG] JSON to be written to file: $jsonToWrite"

						# Save the updated array
						$jsonToWrite | Set-Content -Path $presetsPath -Encoding UTF8
						Write-Host "[LOG] Successfully wrote to $presetsPath"

						$response.StatusCode = 200
						$buffer = [System.Text.Encoding]::UTF8.GetBytes($presetId)
						Write-Host "[LOG] Responding with 200 OK and PresetID: $presetId"

					} finally { 
						[System.Threading.Monitor]::Exit($fileLock) 
						Write-Host "[LOG] Released file lock."
					}
				} catch { 
					# LOG: CRITICAL - This logs the full exception details if something goes wrong.
					Write-Host "[ERROR] An exception occurred in the save-preset endpoint!" -ForegroundColor Red
					Write-Host "[ERROR] Exception Message: $($_.Exception.Message)" -ForegroundColor Red
					Write-Host "[ERROR] Full Exception Details: $($_ | Out-String)" -ForegroundColor Red
					
					Send-ErrorResponse $response 500 "Failed to save preset: $($_.Exception.Message)" 
				}
				Write-Host "--- [$(Get-Date)] Finished processing /save-preset request ---`n"
				continue
			}
            # --- List Presets ---
            elseif ($localPath -eq 'list-presets' -and $request.HttpMethod -eq 'GET') {
                try {
                    [System.Threading.Monitor]::Enter($fileLock)
                    $allPresets = Get-Content $presetsPath -Raw | ConvertFrom-Json
                    $presetsList = $allPresets | Select-Object PresetID, Name, Timestamp
                    Send-JsonResponse $response $presetsList
                } catch { Send-ErrorResponse $response 500 "Failed to list presets: $($_.Exception.Message)" }
                finally { if ([System.Threading.Monitor]::IsEntered($fileLock)) { [System.Threading.Monitor]::Exit($fileLock) } }
                continue
            }
            # --- Get a Specific Preset ---
            elseif ($localPath -eq 'get-preset' -and $request.HttpMethod -eq 'GET') {
                try {
                    $presetId = $request.QueryString.Get("id")
                    [System.Threading.Monitor]::Enter($fileLock)
                    $presetData = (Get-Content $presetsPath -Raw | ConvertFrom-Json) | Where-Object { $_.PresetID -eq $presetId } | Select-Object -First 1
                    
                    if ($presetData) {
                        $responseData = @{ QuestionCount = $presetData.QuestionCount; Conditions = $presetData.Conditions }
                        Send-JsonResponse $response $responseData
                    } else { Send-ErrorResponse $response 404 "Preset not found" }
                } catch { Send-ErrorResponse $response 500 "Failed to get preset: $($_.Exception.Message)" }
                finally { if ([System.Threading.Monitor]::IsEntered($fileLock)) { [System.Threading.Monitor]::Exit($fileLock) } }
                continue
            }
            # --- Save/Update an Answer (Upsert) ---
			elseif ($localPath -eq 'save-answer' -and $request.HttpMethod -eq 'POST') {
				try {
					$data = (New-Object System.IO.StreamReader($request.InputStream)).ReadToEnd() | ConvertFrom-Json
					[System.Threading.Monitor]::Enter($fileLock)
					try {
						# FIX 1: Robustly read the file to guarantee an array.
						$parsedData = $null
						if (Test-Path $answersPath -PathType Leaf) {
							$fileContent = Get-Content $answersPath -Raw
							if (-not [string]::IsNullOrWhiteSpace($fileContent)) { 
								$parsedData = $fileContent | ConvertFrom-Json 
							}
						}
						$answers = @($parsedData) # Ensure $answers is always an array.

						$existingAnswer = $answers | Where-Object { $_.QuestionID -eq $data.questionId }

						if ($existingAnswer) {
							$existingAnswer.AnswerText = $data.answerText; $existingAnswer.Timestamp = (Get-Date -Format "o")
						} else {
							# Add the new answer to our array
							$answers += [PSCustomObject]@{
								AnswerID   = [Guid]::NewGuid().ToString(); QuestionID = $data.questionId
								AnswerText = $data.answerText; Timestamp  = (Get-Date -Format "o")
							}
						}
						
						# FIX 2: Reliably serialize the array back to JSON using -InputObject.
						ConvertTo-Json -InputObject $answers -Depth 5 | Set-Content -Path $answersPath -Encoding UTF8

						Send-JsonResponse $response @{status="success"}
					} finally { [System.Threading.Monitor]::Exit($fileLock) }
				} catch { Send-ErrorResponse $response 500 "Failed to save answer: $($_.Exception.Message)" }
				continue
			}
            # --- Get All Answers ---
			elseif ($localPath -eq 'get-answers' -and $request.HttpMethod -eq 'GET') {
				try {
					[System.Threading.Monitor]::Enter($fileLock)
					
					# FIX 1: Robustly read and parse the file.
					$parsedData = $null
					if (Test-Path $answersPath -PathType Leaf) {
						$fileContent = Get-Content $answersPath -Raw
						if (-not [string]::IsNullOrWhiteSpace($fileContent)) {
							$parsedData = $fileContent | ConvertFrom-Json
						}
					}
					$answers = @($parsedData) # Ensures we always have an array.

					$answerData = $answers | Select-Object QuestionID, AnswerText
					
					# FIX 2: Use -InputObject to ensure it's always sent as a JSON array.
					# We manually build the response instead of using the helper to be safe.
					$jsonResponse = ConvertTo-Json -InputObject $answerData -Depth 5
					$buffer = [System.Text.Encoding]::UTF8.GetBytes($jsonResponse)
					$response.ContentType = 'application/json'
					$response.ContentLength64 = $buffer.Length
					$response.OutputStream.Write($buffer, 0, $buffer.Length)

				} catch { Send-ErrorResponse $response 500 "Failed to get answers: $($_.Exception.Message)" }
				finally { if ([System.Threading.Monitor]::IsEntered($fileLock)) { [System.Threading.Monitor]::Exit($fileLock) } }
				continue
			}
            # --- Save Analytics ---
			elseif ($localPath -eq 'save-analytics' -and $request.HttpMethod -eq 'POST') {
				try {
					$data = (New-Object System.IO.StreamReader($request.InputStream)).ReadToEnd() | ConvertFrom-Json
					if (-not $data.examId -or -not $data.questions) { Send-ErrorResponse $response 400 "Missing analytics data"; continue }

					# This part is fine - it correctly creates an array of new log entries
					$newEntries = foreach ($q in $data.questions) {
						[PSCustomObject]@{
							Timestamp = (Get-Date -Format "o"); ExamID = $data.examId; ExamineeID = $data.examineeId; QuestionID = $q.id
							InputType = [bool]$q.inputType; ListEntry = [bool]$q.listEntry; Rationale = [bool]$q.rationale; Disposition = [bool]$q.disposition
							Mishandle = [bool]$q.mishandle; Points = [int]$q.points; TotalPoints = [int]$data.totalPoints; Comments = $q.comments
							Category = $q.category; Difficulty = $q.difficulty; Examiner = $data.examiner; ExamDate = $data.examDate
						}
					}

					[System.Threading.Monitor]::Enter($fileLock)
					try {
						# FIX 1: Robustly read and parse the existing analytics file.
						$parsedData = $null
						if (Test-Path $analyticsPath -PathType Leaf) {
							$fileContent = Get-Content $analyticsPath -Raw
							if (-not [string]::IsNullOrWhiteSpace($fileContent)) {
								$parsedData = $fileContent | ConvertFrom-Json
							}
						}
						# Ensure $analytics is always a proper, flat array.
						$analytics = @($parsedData)

						# Append the new block of entries to the existing array
						$analytics += $newEntries

						# FIX 2: Use -InputObject for reliable array serialization in PS 5.1
						ConvertTo-Json -InputObject $analytics -Depth 5 | Set-Content -Path $analyticsPath -Encoding UTF8
						
						Send-JsonResponse $response @{status="success"}
					} finally { 
						[System.Threading.Monitor]::Exit($fileLock) 
					}
				} catch { 
					Send-ErrorResponse $response 500 "Failed to save analytics: $($_.Exception.Message)" 
				}
				continue
			}
			# --- Get All Analytics Data ---
			elseif ($localPath -eq 'get-analytics-data' -and $request.HttpMethod -eq 'GET') {
				Write-Host "--- [$(Get-Date)] Received GET request for /get-analytics-data ---"
				try {
					[System.Threading.Monitor]::Enter($fileLock)
					try {
						# Step 1: Robustly read and parse the file.
						$fileContent = Get-Content $analyticsPath -Raw -ErrorAction SilentlyContinue
						Write-Host "[LOG] Raw content read from '$analyticsPath':`n$fileContent"
						
						$parsedData = $null
						if (-not [string]::IsNullOrWhiteSpace($fileContent)) {
							$parsedData = $fileContent | ConvertFrom-Json
						}

						# This ensures $analytics is always a proper, flat array.
						$analytics = @($parsedData)

						# FIX: Use -InputObject to force serialization as an array.
						# This is the key to fixing the bug.
						$jsonResponse = ConvertTo-Json -InputObject $analytics -Depth 5

						# LOG: This will now show the CORRECT JSON array string.
						Write-Host "[LOG] Final JSON string being sent to frontend:`n$jsonResponse" -ForegroundColor Green
						
						# Step 2: Manually build the response instead of using the buggy helper.
						$response.StatusCode = 200
						$response.ContentType = 'application/json'
						$buffer = [System.Text.Encoding]::UTF8.GetBytes($jsonResponse)

					} finally { 
						if ([System.Threading.Monitor]::IsEntered($fileLock)) { 
							[System.Threading.Monitor]::Exit($fileLock) 
						} 
						Write-Host "[LOG] Released file lock."
					}
				} catch { 
					Write-Host "[ERROR] An exception occurred in get-analytics-data: $($_.Exception.Message)" -ForegroundColor Red
					Send-ErrorResponse $response 500 "Error loading analytics data: $($_.Exception.Message)" 
				}
				Write-Host "--- [$(Get-Date)] Finished processing /get-analytics-data ---`n"
				# continue
			}
            # --- Get Analytics Status for Exams ---
            elseif ($localPath -eq 'get-analytics-exam-ids' -and $request.HttpMethod -eq 'GET') {
                try {
                    [System.Threading.Monitor]::Enter($fileLock)
                    $analytics = Get-Content $analyticsPath -Raw | ConvertFrom-Json
                    $result = @{}
                    if ($analytics.Count -gt 0) {
                        foreach ($examGroup in ($analytics | Group-Object ExamID)) {
                            $records = $examGroup.Group; $questionCount = $records.Count; $hasMishandle = $records | Where-Object { $_.Mishandle }
                            $totalPossible = $questionCount * 4
                            $percentage = if ($totalPossible -gt 0) { [math]::Round((($records | Measure-Object -Property Points -Sum).Sum / $totalPossible) * 100) } else { 0 }
                            $status = if ($hasMishandle) { "mishandle" } elseif ($percentage -ge 70) { "passed" } else { "failed" }
                            $result[$examGroup.Name.ToLower()] = $status
                        }
                    }
                    Send-JsonResponse $response $result
                } catch { Send-ErrorResponse $response 500 "Error loading analytics exam IDs: $($_.Exception.Message)" }
                finally { if ([System.Threading.Monitor]::IsEntered($fileLock)) { [System.Threading.Monitor]::Exit($fileLock) } }
                continue
            }
            # --- Clone an Exam Record ---
            elseif ($localPath -eq 'clone-exam' -and $request.HttpMethod -eq 'POST') {
                try {
                    $data = (New-Object System.IO.StreamReader($request.InputStream)).ReadToEnd() | ConvertFrom-Json
                    if (-not $data.sourcePdfFileName -or -not $data.examiner -or -not $data.examinee) { Send-ErrorResponse $response 400 "Missing required fields"; continue }

                    [System.Threading.Monitor]::Enter($fileLock)
                    try {
                        $exams = Get-Content $examsPath -Raw | ConvertFrom-Json
                        $sourceExam = $exams | Where-Object { $_.PDFFile -eq $data.sourcePdfFileName } | Select-Object -First 1
                        if (-not $sourceExam) { Send-ErrorResponse $response 404 "Source exam not found"; return }

                        $exams += [PSCustomObject]@{
                            ExamID = [Guid]::NewGuid().ToString(); Timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss"); Examiner = $data.examiner
                            Examinee = $data.examinee; Comment = $data.comment; Questions = $sourceExam.Questions; PDFFile = $sourceExam.PDFFile
                        }
                        $exams | ConvertTo-Json | Set-Content -Path $examsPath -Encoding UTF8
                        Send-JsonResponse $response @{status="success"}
                    } finally { [System.Threading.Monitor]::Exit($fileLock) }
                } catch { Send-ErrorResponse $response 500 "Failed to clone exam: $($_.Exception.Message)" }
                continue
            }
			# --- Delete Exam Data ---
			elseif ($localPath -eq 'delete-exam-data' -and $request.HttpMethod -eq 'POST') {
				try {
					$data = (New-Object System.IO.StreamReader($request.InputStream)).ReadToEnd() | ConvertFrom-Json
					if (-not $data.examId) { Send-ErrorResponse $response 400 "Exam ID is required"; continue }
					
					$messages = @()
					if ($data.deleteFile -and -not [string]::IsNullOrEmpty($data.pdfFile)) {
						$fileToDeletePath = Join-Path $rootPath $data.pdfFile
						if (Test-Path $fileToDeletePath) {
							try { Remove-Item $fileToDeletePath -Force; $messages += "PDF file '$($data.pdfFile)' deleted." }
							catch { $messages += "Error deleting PDF: $($_.Exception.Message)" }
						} else { $messages += "PDF file not found." }
					}

					[System.Threading.Monitor]::Enter($fileLock)
					try {
						# --- Deletion from exams.json ---
						if ($data.deleteExamRecord) {
							# Robustly read the file to guarantee a flat array.
							$parsedData = $null
							if (Test-Path $examsPath -PathType Leaf) {
								$fileContent = Get-Content $examsPath -Raw
								if (-not [string]::IsNullOrWhiteSpace($fileContent)) { 
									$parsedData = $fileContent | ConvertFrom-Json 
								}
							}
							$allExams = @($parsedData)
							
							$initialCount = $allExams.Count
							# THE KEY FIX: Wrap the filter result in @() to ensure the output is always an array.
							$remainingExams = @($allExams | Where-Object { $_.ExamID -ne $data.examId })

							# This will now correctly serialize an array of 1 item as `[{...}]` and an empty array as `[]`.
							$jsonToWrite = ConvertTo-Json -InputObject $remainingExams -Depth 5
							
							$jsonToWrite | Set-Content -Path $examsPath -Encoding UTF8
							
							$messages += "Deleted $($initialCount - $remainingExams.Count) record(s) from exams."
						}

						# --- Deletion from analytics.json ---
						if ($data.deleteAnalytics) {
							# Apply the same robust pattern here.
							$parsedData = $null
							if (Test-Path $analyticsPath -PathType Leaf) {
								$fileContent = Get-Content $analyticsPath -Raw
								if (-not [string]::IsNullOrWhiteSpace($fileContent)) { 
									$parsedData = $fileContent | ConvertFrom-Json 
								}
							}
							$allAnalytics = @($parsedData)

							$initialCount = $allAnalytics.Count
							# THE KEY FIX: Wrap the filter result in @()
							$remainingAnalytics = @($allAnalytics | Where-Object { $_.ExamID -ne $data.examId })
							
							$jsonToWrite = ConvertTo-Json -InputObject $remainingAnalytics -Depth 5

							$jsonToWrite | Set-Content -Path $analyticsPath -Encoding UTF8

							$messages += "Deleted $($initialCount - $remainingAnalytics.Count) record(s) from analytics."
						}
					} finally { [System.Threading.Monitor]::Exit($fileLock) }
					
					Send-JsonResponse $response @{ message = ($messages -join "`n") }
				} catch { Send-ErrorResponse $response 500 "Deletion failed: $($_.Exception.Message)" }
				continue
			}
			# --- Get All Alerts ---
			elseif ($localPath -eq 'list-alerts' -and $request.HttpMethod -eq 'GET') {
                try {
                    [System.Threading.Monitor]::Enter($fileLock)
                    $fileContent = Get-Content $alertsPath -Raw -ErrorAction SilentlyContinue
                    $alerts = if (-not [string]::IsNullOrWhiteSpace($fileContent)) { @($fileContent | ConvertFrom-Json) } else { @() }
                    Send-JsonResponse $response $alerts
                } catch { 
                    Send-ErrorResponse $response 500 "Failed to read alerts: $($_.Exception.Message)" 
                } finally { 
                    if ([System.Threading.Monitor]::IsEntered($fileLock)) { [System.Threading.Monitor]::Exit($fileLock) } 
                }
                continue
            }
			# --- Save/Update Alert ---
			elseif ($localPath -eq 'save-alert' -and $request.HttpMethod -eq 'POST') {
				try {
					$data = (New-Object System.IO.StreamReader($request.InputStream)).ReadToEnd() | ConvertFrom-Json
					[System.Threading.Monitor]::Enter($fileLock)
					try {
						$fileContent = Get-Content $alertsPath -Raw -ErrorAction SilentlyContinue
						$alerts = if (-not [string]::IsNullOrWhiteSpace($fileContent)) { @($fileContent | ConvertFrom-Json) } else { @() }

						$savedAlert = $null
						if ($data.id) {
							# --- UPDATE LOGIC ---
							# Find the existing alert by its ID and update its properties.
							for ($i = 0; $i -lt $alerts.Count; $i++) {
								if ($alerts[$i].id -eq $data.id) {
									$alerts[$i].content = $data.content
									$alerts[$i].category = $data.category
									$alerts[$i].difficulty = $data.difficulty
									$alerts[$i].user = $data.user
									$alerts[$i].updatedAt = (Get-Date -Format "o") # Update the timestamp
									$savedAlert = $alerts[$i]
									break
								}
							}
						}
						
						if (-not $savedAlert) {
							# --- CREATE NEW LOGIC (if no ID was provided or found) ---
							$newEntry = [PSCustomObject]@{
								id = Get-ShortId
								content = $data.content
								category = $data.category
								difficulty = $data.difficulty
								user = $data.user
								date = (Get-Date).ToString("dd.MM.yyyy")
								createdAt = (Get-Date -Format "o")
								updatedAt = (Get-Date -Format "o")
							}
							$alerts += $newEntry
							$savedAlert = $newEntry
						}

						ConvertTo-Json -InputObject @($alerts) -Depth 5 | Set-Content -Path $alertsPath -Encoding UTF8
						Send-JsonResponse $response $savedAlert
					} finally { [System.Threading.Monitor]::Exit($fileLock) }
				} catch { Send-ErrorResponse $response 500 "Failed to save alert: $($_.Exception.Message)" }
				continue
			}
			# --- Delete Alert ---
			elseif ($localPath -eq 'delete-alert' -and $request.HttpMethod -eq 'POST') {
				try {
					$data = (New-Object System.IO.StreamReader($request.InputStream)).ReadToEnd() | ConvertFrom-Json
					if (-not $data.id) { Send-ErrorResponse $response 400 "Alert ID is required"; continue }

					[System.Threading.Monitor]::Enter($fileLock)
					try {
						$fileContent = Get-Content $alertsPath -Raw -ErrorAction SilentlyContinue
						$alerts = if (-not [string]::IsNullOrWhiteSpace($fileContent)) { @($fileContent | ConvertFrom-Json) } else { @() }
						
						$initialCount = $alerts.Count
						# Filter out the alert with the matching ID
						$remainingAlerts = @($alerts | Where-Object { $_.id -ne $data.id })
						
						if ($remainingAlerts.Count -lt $initialCount) {
							ConvertTo-Json -InputObject $remainingAlerts -Depth 5 | Set-Content -Path $alertsPath -Encoding UTF8
							Send-JsonResponse $response @{ status = "success"; message = "Alert deleted." }
						} else {
							Send-JsonResponse $response @{ status = "not_found"; message = "Alert ID not found." }
						}
					} finally { [System.Threading.Monitor]::Exit($fileLock) }
				} catch { Send-ErrorResponse $response 500 "Failed to delete alert: $($_.Exception.Message)" }
				continue
			}
			# --- Save Exam Response ---
            elseif ($localPath -eq 'save-exam-response' -and $request.HttpMethod -eq 'POST') {
                try {
                    $data = (New-Object System.IO.StreamReader($request.InputStream)).ReadToEnd() | ConvertFrom-Json
                    if (-not $data.examId -or -not $data.responseString) { Send-ErrorResponse $response 400 "Missing examId or responseString"; continue }

                    [System.Threading.Monitor]::Enter($fileLock)
                    try {
                        # Robustly read the file to guarantee an array
                        $parsedData = $null
                        if (Test-Path $responsesPath -PathType Leaf) {
                            $fileContent = Get-Content $responsesPath -Raw
                            if (-not [string]::IsNullOrWhiteSpace($fileContent)) { 
                                $parsedData = $fileContent | ConvertFrom-Json 
                            }
                        }
                        $allResponses = @($parsedData)

                        # Check if a response for this exam already exists
                        $existingResponse = $allResponses | Where-Object { $_.ExamID -eq $data.examId }

                        if ($existingResponse) {
                            # Update the existing response
                            $existingResponse.ResponseString = $data.responseString
                            $existingResponse.Timestamp = (Get-Date -Format "o")
                        } else {
                            # Add a new response entry
                            $allResponses += [PSCustomObject]@{
                                ExamID         = $data.examId
                                ResponseString = $data.responseString
                                Timestamp      = (Get-Date -Format "o")
                            }
                        }
                        
                        # Save the updated array back to the file
                        ConvertTo-Json -InputObject $allResponses -Depth 5 | Set-Content -Path $responsesPath -Encoding UTF8
                        Send-JsonResponse $response @{status="success"}
                    } finally { 
                        [System.Threading.Monitor]::Exit($fileLock) 
                    }
                } catch { 
                    Send-ErrorResponse $response 500 "Failed to save exam response: $($_.Exception.Message)" 
                }
                continue
            }
			# --- Get Exam Response ---
            elseif ($localPath -eq 'get-exam-response' -and $request.HttpMethod -eq 'GET') {
                try {
                    $examId = $request.QueryString.Get("examId")
                    if (-not $examId) { Send-ErrorResponse $response 400 "Missing examId query parameter"; continue }

                    [System.Threading.Monitor]::Enter($fileLock)
                    try {
                        $parsedData = $null
                        if (Test-Path $responsesPath -PathType Leaf) {
                            $fileContent = Get-Content $responsesPath -Raw
                            if (-not [string]::IsNullOrWhiteSpace($fileContent)) {
                                $parsedData = $fileContent | ConvertFrom-Json
                            }
                        }
                        $allResponses = @($parsedData)

                        $foundResponse = $allResponses | Where-Object { $_.ExamID -eq $examId } | Select-Object -First 1
                        
                        if ($foundResponse) {
                            # Send back the specific response object
                            Send-JsonResponse $response $foundResponse
                        } else {
                            # Send an empty object if not found, which is easy for the frontend to handle
                            Send-JsonResponse $response @{}
                        }
                    } finally { 
                        [System.Threading.Monitor]::Exit($fileLock) 
                    }
                } catch { 
                    Send-ErrorResponse $response 500 "Failed to get exam response: $($_.Exception.Message)" 
                }
                continue
            }
         # --- Generate Override Code ---
         elseif ($localPath -eq 'generate-override-code' -and $request.HttpMethod -eq 'POST') {
             try {
                 $data = (New-Object System.IO.StreamReader($request.InputStream)).ReadToEnd() | ConvertFrom-Json
                 if (-not $data.examId -or -not $data.action -or -not $data.value) {
                     Send-ErrorResponse $response 400 "Missing required fields (examId, action, value)"
                     continue
                 }
                 
                 # 1. Create the signing key from the examId and the server salt
                 $hmac = New-Object System.Security.Cryptography.HMACSHA256
                 $hmac.Key = [System.Text.Encoding]::UTF8.GetBytes($serverSalt)
                 $signingKeyBytes = $hmac.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($data.examId))

                 # 2. Create the payload with a unique nonce and expiration (e.g., 10 minutes)
                 $payload = @{
                     action = $data.action
                     value  = $data.value
                     nonce  = [Guid]::NewGuid().ToString()
                     exp    = ([DateTimeOffset]::UtcNow.AddMinutes(10)).ToUnixTimeSeconds()
                 } | ConvertTo-Json -Compress

                 # 3. Base64-encode the payload
                 $base64Payload = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($payload))

                 # 4. Sign the Base64-encoded payload
                 $hmac.Key = $signingKeyBytes
                 $signatureBytes = $hmac.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($base64Payload))
                 $base64Signature = [System.Convert]::ToBase64String($signatureBytes)

                 # 5. Combine into the final code and send back
                 $finalCode = "$($base64Payload).$($base64Signature)"
                 Send-JsonResponse $response @{ code = $finalCode }
             }
             catch {
                 Send-ErrorResponse $response 500 "Failed to generate code: $($_.Exception.Message)"
             }
             continue
         }
            # --- Serve static files ---
            elseif (Test-Path $filePath -PathType Leaf) {
                $buffer = [System.IO.File]::ReadAllBytes($filePath)
                $response.ContentType = switch -Wildcard ($localPath) {
                    "*.svg" { "image/svg+xml" } "*.png" { "image/png" } "*.jpg" { "image/jpeg" }
                    "*.css" { "text/css" }      "*.js"  { "text/javascript" }
                    "*.bat" { "application/octet-stream" }
					default { "application/octet-stream" }
                }
            }
            else {
                Send-ErrorResponse $response 404 "Not Found"
                continue
            }

            $response.ContentLength64 = $buffer.Length
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
        }
        catch {
            Send-ErrorResponse $response 500 "Internal Server Error: $($_.Exception.Message)"
        }
        finally {
            $response.Close()
        }
    }
}
finally {
    $listener.Stop()
}