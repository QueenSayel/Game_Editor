// analytics.js

let chartInstance = null;

// Custom legend plugin for Chart.js v3+
const legendMarginPlugin = {
    id: 'legendMargin',
    beforeInit(chart) {
        const originalFit = chart.legend.fit;
        chart.legend.fit = function() {
            originalFit.bind(chart.legend)();
            this.height += 30; // Add 30px margin below the legend
        };
    }
};

// Register the plugin
Chart.register(legendMarginPlugin);

export function closeAnalyticsModal() {
    document.getElementById('analytics-modal').style.display = 'none';
    if (chartInstance) {
        chartInstance.destroy();
        chartInstance = null;
    }
}

export function showAnalytics() {
    const modal = document.getElementById('analytics-modal');
    modal.style.display = 'block';
    renderAnalyticsChart('category');
    
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            renderAnalyticsChart(this.dataset.chart);
        });
    });
}

function renderAnalyticsChart(type = 'category') {
    if (chartInstance) {
        chartInstance.destroy();
    }

    const selectedData = Array.from(selectedAlertIDs).map(alertId => 
        metadataStore.find(meta => meta.id === alertId)
    ).filter(Boolean);

    const counts = selectedData.reduce((acc, curr) => {
        const key = curr[type] || 'Unknown';
        acc[key] = (acc[key] || 0) + 1;
        return acc;
    }, {});

    const ctx = document.getElementById('analytics-chart').getContext('2d');
    
    chartInstance = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: Object.keys(counts),
            datasets: [{
                data: Object.values(counts),
                backgroundColor: [
                    '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0',
                    '#9966FF', '#FF9F40', '#E7E9ED', '#8C564B'
                ],
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        padding: 20
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = selectedData.length;
                            const value = context.raw || 0;
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${context.label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

// Add close button handler
document.querySelector('#analytics-modal .close')?.addEventListener('click', closeAnalyticsModal);

// Initialize analytics button
document.querySelector('.analytics-btn')?.addEventListener('click', showAnalytics);

// Make function available globally
window.closeAnalyticsModal = closeAnalyticsModal;
document.querySelector('#analytics-modal .btn-back')?.addEventListener('click', closeAnalyticsModal);
document.querySelector('#analytics-modal .btn-revalidate')?.addEventListener('click', (e) => {
  // Get fresh validation data
  const questionCount = parseInt(document.getElementById('question-count').value, 10);
  const conditions = Array.from(document.querySelectorAll('.condition-row')).map(row => {
    const typeSelect = row.querySelector('select:first-child');
    const operator = row.querySelector('select:nth-child(2)').value;
    const value = parseInt(row.querySelector('input').value, 10);
    
    return {
      type: typeSelect.className.includes('category') ? 'category' : 'difficulty',
      field: typeSelect.value,
      operator,
      required: value
    };
  });

  // Create a validation event object
  const validationEvent = {
    preventDefault: () => {}, // Mock preventDefault
    target: document.querySelector('.validate-btn') // Original validate button
  };

  // Run validation
  handleValidation(validationEvent);

  // Only refresh analytics if validation succeeded
  if (!document.querySelector('#randomise-status-container .alert-error')) {
    const activeTab = document.querySelector('.tab-btn.active').dataset.chart;
    renderAnalyticsChart(activeTab);
    
    // Update analytics button state
    document.querySelector('.analytics-btn').disabled = false;
  }
});